"""
Diabetes Status Classification for Generalized Dataset
Classifies patients from the generalized (overlapping) dataset as Diabetic or Non-Diabetic.

This script:
1. Loads the generalized synthetic diabetes dataset
2. Assigns Diabetic status (0/1) based on patient distribution
3. Saves updated dataset with Diabetic status column
4. Extracts and saves diabetic patients only for further processing
"""

import pandas as pd
import numpy as np
from pathlib import Path


class DiabetesClassifierGeneralized:
    """
    Classify patients from generalized dataset as diabetic or non-diabetic.
    """
    
    def __init__(self, dataset_path):
        """Initialize classifier with dataset path."""
        self.dataset_path = dataset_path
        self.df = None
        self.diabetic_patients = None
        
    def load_dataset(self):
        """Load the synthetic dataset."""
        print(f"Loading generalized dataset from: {self.dataset_path}")
        self.df = pd.read_csv(self.dataset_path)
        print(f"✓ Dataset loaded successfully")
        print(f"  Shape: {self.df.shape}")
        return self.df
    
    def assign_diabetic_status(self):
        """
        Assign diabetic status based on patient row indices.
        
        Classification Logic:
        - Rows 0-9,999: Non-Diabetic (0)
        - Rows 10,000-19,999: Diabetic (1) [includes both Type 1 and Type 2]
        """
        print("\nAssigning Diabetic Status...")
        
        n_rows = len(self.df)
        diabetic_status = np.zeros(n_rows, dtype=int)
        
        # Assign 1 (Diabetic) to rows 10,000 and beyond
        diabetic_status[10000:] = 1
        
        self.df['DIABETIC_STATUS'] = diabetic_status
        
        print(f"\nDiabetic Status Distribution:")
        print(f"  Non-Diabetic (0): {np.sum(diabetic_status == 0):,} patients")
        print(f"  Diabetic (1):     {np.sum(diabetic_status == 1):,} patients")
        
        return self.df
    
    def extract_diabetic_patients(self):
        """Extract only diabetic patients."""
        print("\nExtracting Diabetic Patients...")
        
        self.diabetic_patients = self.df[self.df['DIABETIC_STATUS'] == 1].copy()
        
        # Remove DIABETIC_STATUS column from diabetic-only dataset
        self.diabetic_patients = self.diabetic_patients.drop(columns=['DIABETIC_STATUS'])
        
        print(f"✓ Extracted {len(self.diabetic_patients):,} diabetic patients")
        print(f"  Features: {self.diabetic_patients.shape[1]}")
        
        return self.diabetic_patients
    
    def save_datasets(self, output_dir=None):
        """Save both datasets to CSV files."""
        if output_dir is None:
            output_dir = Path(self.dataset_path).parent
        else:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Save full dataset with DIABETIC_STATUS column
        full_dataset_path = output_dir / 'Bio_2_f_Data_Classified.csv'
        self.df.to_csv(full_dataset_path, index=False)
        print(f"\n✓ Full dataset saved:")
        print(f"  Path: {full_dataset_path}")
        print(f"  Rows: {len(self.df):,} | Columns: {len(self.df.columns)}")
        
        # Save diabetic patients only
        diabetic_dataset_path = output_dir / 'Bio_3_f_Diabetic.csv'
        self.diabetic_patients.to_csv(diabetic_dataset_path, index=False)
        print(f"\n✓ Diabetic-only dataset saved:")
        print(f"  Path: {diabetic_dataset_path}")
        print(f"  Rows: {len(self.diabetic_patients):,} | Columns: {len(self.diabetic_patients.columns)}")
        
        return str(full_dataset_path), str(diabetic_dataset_path)


def main():
    """Main function to classify generalized dataset."""
    
    # Initialize classifier with generalized dataset
    dataset_path = '/Users/nikitha21sree/Biology/Project/Dataset/Bio_1_f_dataset.csv'
    classifier = DiabetesClassifierGeneralized(dataset_path)
    
    # Execute classification pipeline
    classifier.load_dataset()
    classifier.assign_diabetic_status()
    classifier.extract_diabetic_patients()
    full_path, diabetic_path = classifier.save_datasets()
    
    # Print summary
    print("\n" + "="*70)
    print("GENERALIZED DATASET: CLASSIFICATION SUMMARY")
    print("="*70)
    
    total_patients = len(classifier.df)
    diabetic_count = np.sum(classifier.df['DIABETIC_STATUS'] == 1)
    non_diabetic_count = np.sum(classifier.df['DIABETIC_STATUS'] == 0)
    
    print(f"\nTotal Patients Classified: {total_patients:,}")
    print(f"\nNon-Diabetic Patients (Status=0):")
    print(f"  Count: {non_diabetic_count:,} ({(non_diabetic_count/total_patients)*100:.1f}%)")
    
    print(f"\nDiabetic Patients (Status=1):")
    print(f"  Count: {diabetic_count:,} ({(diabetic_count/total_patients)*100:.1f}%)")
    print(f"  [Note: includes overlapping Type 1 + Type 2 features]")
    
    print("\n" + "="*70)
    
    return classifier


if __name__ == "__main__":
    classifier = main()
