"""Train a small Tab-Transformer-like model for DIABETES_TYPE (Type2 vs Type1).
Defaults use Dataset/Bio_4_f_T1&2.csv and save outputs to Outputs/bio12.
This script maps DIABETES_TYPE==2 to label 1 (Type2) and others to 0.
Quick test defaults: 2 epochs, SHAP disabled. Use --shap to enable SHAP (slow).
"""
import argparse
import os
import random
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
# disable torch compile/dynamo to avoid heavy import-time overhead on macOS
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')
import torch
import torch.nn as nn
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support, roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from Bio_11_f_m_Diabetic import TabTransformer, load_and_prepare, seed_everything


def load_and_prepare_t12(path, target_col="DIABETES_TYPE"):
    """Load data for Type 1 vs Type 2 classification."""
    df = pd.read_csv(path)
    df = df.copy()
    if 'PATIENT_ID' in df.columns:
        df = df.drop(columns=['PATIENT_ID'])
    
    # Map Type2=2 to 1, all others (Type1=1, Non-diab=0) to 0
    y = ((df[target_col] == 2).astype(int)).values
    df = df.drop(columns=[target_col])
    
    potential_cat = []
    for c in df.columns:
        if df[c].dtype == object:
            potential_cat.append(c)
        elif pd.api.types.is_integer_dtype(df[c]) and df[c].nunique() <= 20:
            potential_cat.append(c)

    cont_cols = [c for c in df.columns if c not in potential_cat]

    for c in cont_cols:
        df[c] = df[c].fillna(df[c].median())
    for c in potential_cat:
        df[c] = df[c].fillna("__NA__").astype(str)

    cat_maps = {}
    cat_cardinalities = []
    for c in potential_cat:
        cats = sorted(df[c].unique())
        mapping = {v: i + 1 for i, v in enumerate(cats)}
        cat_maps[c] = mapping
        df[c] = df[c].map(mapping).fillna(0).astype(int)
        cat_cardinalities.append(len(cats))

    scaler = StandardScaler()
    if len(cont_cols) > 0:
        df[cont_cols] = scaler.fit_transform(df[cont_cols])

    X_cats = df[potential_cat].values.astype(int) if len(potential_cat) > 0 else np.zeros((len(df), 0), dtype=int)
    X_cont = df[cont_cols].values.astype(float) if len(cont_cols) > 0 else None

    meta = {
        'cat_cols': potential_cat,
        'cont_cols': cont_cols,
        'cat_maps': cat_maps,
        'scaler': scaler,
        'cat_cardinalities': cat_cardinalities
    }
    return X_cats, X_cont, y, meta


def train(args):
    seed_everything()
    os.makedirs(args.save_dir, exist_ok=True)

    X_cats, X_cont, y, meta = load_and_prepare_t12(args.input)

    # Create test split, then train/val split
    test_size = getattr(args, 'test_size', 0.2)
    val_size = getattr(args, 'val_size', 0.2)
    Xc_temp, Xc_test, Xn_temp, Xn_test, y_temp, y_test = train_test_split(
        X_cats, X_cont, y, test_size=test_size, random_state=42, stratify=y)

    if val_size > 0:
        val_frac = val_size / (1.0 - test_size)
        Xc_train, Xc_val, Xn_train, Xn_val, y_train, y_val = train_test_split(
            Xc_temp, Xn_temp, y_temp, test_size=val_frac, random_state=42, stratify=y_temp)
    else:
        Xc_train, Xc_val, Xn_train, Xn_val, y_train, y_val = Xc_temp, np.zeros((0, Xc_temp.shape[1]), dtype=int), Xn_temp, None, y_temp, np.array([])

    # Choose device
    if args.device == 'cuda' and torch.cuda.is_available():
        device = torch.device('cuda')
    elif args.device == 'mps' and getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
        device = torch.device('mps')
    else:
        device = torch.device('cpu')

    model = TabTransformer(
        n_cat=len(meta['cat_cols']),
        n_cont=len(meta['cont_cols']),
        cat_cardinalities=meta['cat_cardinalities'],
        d_model=args.d_model,
        n_heads=getattr(args, 'n_heads', 4),
        n_layers=getattr(args, 'n_layers', 2),
        dropout=getattr(args, 'dropout', 0.1)
    )
    model.to(device)

    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=getattr(args, 'weight_decay', 1e-4))
    criterion = nn.BCEWithLogitsLoss()
    batch_size = args.batch_size

    def batch_iter(Xc, Xn, y, bs):
        n = len(y)
        idx = np.arange(n)
        np.random.shuffle(idx)
        for i in range(0, n, bs):
            batch = idx[i:i+bs]
            Xc_b = torch.tensor(Xc[batch], dtype=torch.long, device=device)
            Xn_b = torch.tensor(Xn[batch].astype(np.float32), dtype=torch.float32, device=device) if Xn is not None else None
            y_b = torch.tensor(y[batch].astype(np.float32), dtype=torch.float32, device=device)
            yield Xc_b, Xn_b, y_b

    def evaluate(Xc, Xn, y_true):
        model.eval()
        losses = []
        probs_list = []
        with torch.no_grad():
            n = len(y_true)
            for i in range(0, n, batch_size):
                b = slice(i, i+batch_size)
                Xc_b = torch.tensor(Xc[b], dtype=torch.long, device=device)
                Xn_b = torch.tensor(Xn[b].astype(np.float32), dtype=torch.float32, device=device) if Xn is not None else None
                y_b = torch.tensor(y_true[b].astype(np.float32), dtype=torch.float32, device=device)
                logits = model(Xc_b, Xn_b)
                loss = criterion(logits, y_b)
                losses.append(loss.item() * len(y_b))
                probs = torch.sigmoid(logits).cpu().numpy()
                probs_list.append(probs)
        if len(probs_list) == 0:
            return None, None, None
        probs_all = np.concatenate(probs_list)
        loss_all = sum(losses) / len(y_true)
        preds_all = (probs_all >= 0.5).astype(int)
        try:
            auc = float(roc_auc_score(y_true, probs_all))
        except Exception:
            auc = float('nan')
        acc = float(accuracy_score(y_true, preds_all))
        return loss_all, auc, acc

    # training loop with val monitoring + early stopping
    best_val = -float('inf')
    best_model = None
    no_improve = 0
    val_losses = []
    train_losses = []
    val_aucs = []
    val_accs = []

    for epoch in range(args.epochs):
        model.train()
        total_loss = 0.0
        n_seen = 0
        for Xc_b, Xn_b, y_b in batch_iter(Xc_train, Xn_train, y_train, batch_size):
            opt.zero_grad()
            logits = model(Xc_b, Xn_b)
            loss = criterion(logits, y_b)
            loss.backward()
            opt.step()
            total_loss += loss.item() * Xc_b.size(0)
            n_seen += Xc_b.size(0)
        train_loss = total_loss / len(y_train)
        train_losses.append(train_loss)

        if len(y_val) > 0:
            val_loss, val_auc, val_acc = evaluate(Xc_val, Xn_val, y_val)
            val_losses.append(val_loss)
            val_aucs.append(val_auc)
            val_accs.append(val_acc)
            monitor = val_auc if not np.isnan(val_auc) else -val_loss
            if monitor > best_val:
                best_val = monitor
                best_model = model.state_dict()
                no_improve = 0
            else:
                no_improve += 1
            print(f"Epoch {epoch+1}/{args.epochs} train_loss={train_loss:.4f} val_loss={val_loss:.4f} val_auc={val_auc} val_acc={val_acc:.4f}")
            patience = getattr(args, 'patience', 5)
            if patience and no_improve >= patience:
                print('Early stopping triggered')
                break
        else:
            print(f"Epoch {epoch+1}/{args.epochs} train_loss={train_loss:.4f}")

    # load best model if available
    if best_model is not None:
        model.load_state_dict(best_model)

    # final evaluation on test set
    _, test_auc, test_acc = evaluate(Xc_test, Xn_test, y_test)
    # compute final probs and confusion matrix for saving
    model.eval()
    with torch.no_grad():
        Xc_t = torch.tensor(Xc_test, dtype=torch.long, device=device)
        Xn_t = torch.tensor(Xn_test.astype(np.float32), dtype=torch.float32, device=device) if Xn_test is not None else None
        logits = model(Xc_t, Xn_t).cpu().numpy()
        probs = 1 / (1 + np.exp(-logits))

    try:
        roc_auc = float(roc_auc_score(y_test, probs))
    except Exception:
        roc_auc = float('nan')
    fpr, tpr, _ = ([], []) if np.isnan(roc_auc) else roc_curve(y_test, probs)
    print(f"Test ROC AUC (Type2 vs others): {roc_auc:.4f if not np.isnan(roc_auc) else 'nan'}")

    # save ROC plot with improved formatting
    plt.figure(figsize=(8, 7))
    if len(fpr) > 0:
        plt.plot(fpr, tpr, linewidth=2.5, label=f'AUC={roc_auc:.3f}')
    else:
        plt.plot([0, 1], [0, 1], linestyle='--', color='gray', linewidth=2)
    plt.plot([0, 1], [0, 1], linestyle='--', color='gray', alpha=0.3, label='Random')
    plt.xlabel('False Positive Rate', fontsize=12, fontweight='bold')
    plt.ylabel('True Positive Rate', fontsize=12, fontweight='bold')
    plt.title('ROC Curve - Type 2 vs Others', fontsize=14, fontweight='bold')
    plt.legend(fontsize=11, loc='lower right')
    plt.grid(True, alpha=0.3)
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.savefig(os.path.join(args.save_dir, 'roc_bio12.png'), dpi=300, bbox_inches='tight')
    plt.close()

    preds = (probs >= 0.5).astype(int)
    cm = confusion_matrix(y_test, preds, labels=[0,1]) if len(np.unique(y_test))>1 else confusion_matrix(y_test, preds)
    acc = accuracy_score(y_test, preds)
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, preds, average='binary', zero_division=0)
    print('Confusion matrix:\n', cm)
    print(f"Accuracy: {acc:.4f}  Precision: {prec:.4f}  Recall: {rec:.4f}  F1: {f1:.4f}")
    print('Classification report:\n', classification_report(y_test, preds, zero_division=0))

    # save confusion matrix with visible numbers
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(cm, cmap='Blues', aspect='auto')
    plt.colorbar(im, ax=ax, label='Count')
    
    # Add text annotations (confusion matrix values)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            text = ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                          color="white" if cm[i, j] > cm.max() / 2 else "black",
                          fontsize=16, fontweight='bold')
    
    ax.set_xticks(range(cm.shape[1]))
    ax.set_yticks(range(cm.shape[0]))
    class_labels = ['Non-Type2 (0)', 'Type2 (1)'] if cm.shape[0] == 2 else [str(i) for i in range(cm.shape[0])]
    ax.set_xticklabels(class_labels, fontsize=11)
    ax.set_yticklabels(class_labels, fontsize=11)
    ax.set_xlabel('Predicted Label', fontsize=12, fontweight='bold')
    ax.set_ylabel('True Label', fontsize=12, fontweight='bold')
    ax.set_title('Confusion Matrix - Type 2 vs Others', fontsize=14, fontweight='bold')
    plt.savefig(os.path.join(args.save_dir, 'cm_bio12.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    torch.save(model.state_dict(), os.path.join(args.save_dir, 'bio12_model.pt'))
    metrics = {
        'roc_auc': roc_auc if not np.isnan(roc_auc) else None,
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1': float(f1),
        'confusion_matrix': cm.tolist()
    }
    import json
    with open(os.path.join(args.save_dir, 'metrics_bio12.json'), 'w') as fh:
        json.dump(metrics, fh, indent=2)

    # save epoch plots with improved formatting
    if len(train_losses) > 0 and len(val_losses) > 0:
        plt.figure(figsize=(10, 6))
        epochs_range = range(1, len(train_losses) + 1)
        plt.plot(epochs_range, train_losses, 'o-', linewidth=2.5, markersize=5, label='Training Loss', color='#1f77b4')
        plt.plot(epochs_range, val_losses, 's-', linewidth=2.5, markersize=5, label='Validation Loss', color='#ff7f0e')
        plt.xlabel('Epoch', fontsize=12, fontweight='bold')
        plt.ylabel('Loss (Binary Crossentropy)', fontsize=12, fontweight='bold')
        plt.title('Training and Validation Loss Curve', fontsize=14, fontweight='bold')
        plt.legend(fontsize=11, loc='best')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(args.save_dir, 'loss_curve_bio12.png'), dpi=300, bbox_inches='tight')
        plt.close()

    if len(val_aucs) > 0:
        plt.figure(figsize=(10, 6))
        epochs_range = range(1, len(val_aucs) + 1)
        auc_values = [x if not np.isnan(x) else 0.5 for x in val_aucs]
        plt.plot(epochs_range, auc_values, 'o-', linewidth=2.5, markersize=5, color='#2ca02c')
        plt.axhline(y=np.nanmean(val_aucs), color='r', linestyle='--', linewidth=2, label=f'Mean AUC: {np.nanmean([x for x in val_aucs if not np.isnan(x)]):.3f}' if any(not np.isnan(x) for x in val_aucs) else 'Mean AUC')
        plt.xlabel('Epoch', fontsize=12, fontweight='bold')
        plt.ylabel('AUC Score', fontsize=12, fontweight='bold')
        plt.title('Validation AUC per Epoch', fontsize=14, fontweight='bold')
        plt.legend(fontsize=11, loc='best')
        plt.grid(True, alpha=0.3)
        plt.ylim([0, 1.05])
        plt.tight_layout()
        plt.savefig(os.path.join(args.save_dir, 'val_auc_bio12.png'), dpi=300, bbox_inches='tight')
        plt.close()

    if len(val_accs) > 0:
        plt.figure(figsize=(10, 6))
        epochs_range = range(1, len(val_accs) + 1)
        plt.plot(epochs_range, val_accs, 'o-', linewidth=2.5, markersize=5, color='#d62728')
        plt.axhline(y=np.mean(val_accs), color='b', linestyle='--', linewidth=2, label=f'Mean Accuracy: {np.mean(val_accs):.3f}')
        plt.xlabel('Epoch', fontsize=12, fontweight='bold')
        plt.ylabel('Accuracy Score', fontsize=12, fontweight='bold')
        plt.title('Validation Accuracy per Epoch', fontsize=14, fontweight='bold')
        plt.legend(fontsize=11, loc='best')
        plt.grid(True, alpha=0.3)
        plt.ylim([0, 1.05])
        plt.tight_layout()
        plt.savefig(os.path.join(args.save_dir, 'val_acc_bio12.png'), dpi=300, bbox_inches='tight')
        plt.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default='Dataset/Bio_4_f_T1&2_Generalized.csv')
    parser.add_argument('--save-dir', default='Outputs/bio12')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--batch-size', type=int, default=256)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--device', default='cpu')
    parser.add_argument('--d-model', dest='d_model', type=int, default=64)
    parser.add_argument('--patience', type=int, default=5, help='early stopping patience (epochs)')
    parser.add_argument('--weight-decay', dest='weight_decay', type=float, default=1e-4)
    parser.add_argument('--dropout', type=float, default=0.1)
    parser.add_argument('--n-layers', dest='n_layers', type=int, default=2)
    parser.add_argument('--n-heads', dest='n_heads', type=int, default=4)
    parser.add_argument('--test-size', dest='test_size', type=float, default=0.2)
    parser.add_argument('--val-size', dest='val_size', type=float, default=0.2)
    parser.add_argument('--shap', action='store_true')
    args = parser.parse_args()
    train(args)
