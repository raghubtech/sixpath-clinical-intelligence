"""
SAINT: Selfish Attention via INTernetwork for Tabular Data
Optimized for 10k samples with Type1/Type2 diabetes classification.
"""
import argparse
import os
import random
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')
import torch
import torch.nn as nn
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix, 
                             precision_recall_fscore_support, roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class SAINT(nn.Module):
    """SAINT: Selfish Attention for Tabular Data
    
    Each feature attends independently (row/col attention).
    Optimal for 5k-100k samples with mixed categorical/continuous features.
    """
    def __init__(self, n_cat, n_cont, cat_cardinalities, dim=128, depth=4, heads=8, dropout=0.15):
        super().__init__()
        self.n_cat = n_cat
        self.n_cont = n_cont
        self.n_features = n_cat + (1 if n_cont > 0 else 0)  # n_cont projects to 1 feature
        self.dim = dim
        
        # Embeddings
        self.cat_embs = nn.ModuleList([nn.Embedding(c + 1, dim) for c in cat_cardinalities])
        self.cont_proj = nn.Linear(n_cont, dim) if n_cont > 0 else None
        
        # Learnable feature tokens
        self.feat_tokens = nn.Parameter(torch.randn(1, self.n_features, dim))
        nn.init.normal_(self.feat_tokens, std=0.02)
        
        # SAINT layers
        self.layers = nn.ModuleList([
            SAINTLayer(dim, heads=heads, dropout=dropout) for _ in range(depth)
        ])
        
        # Classification head
        self.ln = nn.LayerNorm(dim)
        self.head = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim, 1)
        )
    
    def forward(self, x_cats, x_cont):
        # Tokenize features
        tokens = []
        for i, emb in enumerate(self.cat_embs):
            tokens.append(emb(x_cats[:, i].long()))
        
        if self.cont_proj is not None and x_cont is not None:
            tokens.append(self.cont_proj(x_cont.float()))
        
        x = torch.stack(tokens, dim=1)  # (B, n_features, dim)
        x = x + self.feat_tokens
        
        # Apply SAINT layers
        for layer in self.layers:
            x = layer(x)
        
        # Pool and classify
        x = self.ln(x.mean(dim=1))
        logits = self.head(x).squeeze(-1)
        return logits


class SAINTLayer(nn.Module):
    def __init__(self, dim, heads=8, dropout=0.15):
        super().__init__()
        # Row attention (across batch)
        self.row_attn = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        # Col attention (across features)
        self.col_attn = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        
        # MLPs
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 2, dim),
            nn.Dropout(dropout)
        )
        
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.norm3 = nn.LayerNorm(dim)
    
    def forward(self, x):
        # Row attention
        x_n = self.norm1(x)
        attn_out, _ = self.row_attn(x_n, x_n, x_n)
        x = x + attn_out
        
        # Col attention
        x_t = x.transpose(0, 1)
        x_n = self.norm2(x_t)
        attn_out, _ = self.col_attn(x_n, x_n, x_n)
        x_t = x_t + attn_out
        x = x_t.transpose(0, 1)
        
        # MLP
        x_n = self.norm3(x)
        mlp_out = self.mlp(x_n)
        x = x + mlp_out
        
        return x


class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0):
        super().__init__()
        self.gamma = gamma

    def forward(self, inputs, targets):
        probs = torch.sigmoid(inputs)
        targets = targets.float()
        p_t = probs * targets + (1 - probs) * (1 - targets)
        loss = -(1 - p_t) ** self.gamma * (targets * torch.log(probs + 1e-8) + (1 - targets) * torch.log(1 - probs + 1e-8))
        return loss.mean()


def load_and_inspect(path, target_col="DIABETES_TYPE"):
    """Load dataframe and identify categorical/continuous columns."""
    df = pd.read_csv(path)
    df = df.copy()
    df[target_col] = df[target_col].astype(int)

    potential_cat = []
    for c in df.columns:
        if c == target_col:
            continue
        if df[c].dtype == object:
            potential_cat.append(c)
        elif pd.api.types.is_integer_dtype(df[c]) and df[c].nunique() <= 20:
            potential_cat.append(c)

    cont_cols = [c for c in df.columns if c not in potential_cat + [target_col]]

    cat_maps = {}
    cat_cardinalities = []
    for c in potential_cat:
        cats = sorted(df[c].fillna('__NA__').astype(str).unique())
        mapping = {v: i + 1 for i, v in enumerate(cats)}
        cat_maps[c] = mapping
        cat_cardinalities.append(len(cats))

    return df, potential_cat, cont_cols, cat_maps, cat_cardinalities


def train(args):
    seed_everything()
    os.makedirs(args.save_dir, exist_ok=True)

    # Load and split
    df, potential_cat, cont_cols, cat_maps, cat_cardinalities = load_and_inspect(args.input)
    
    if 'PATIENT_ID' in potential_cat:
        potential_cat = [c for c in potential_cat if c != 'PATIENT_ID']
    cat_cardinalities = [len(cat_maps[c]) for c in potential_cat]

    test_size = getattr(args, 'test_size', 0.2)
    train_df_full, test_df = train_test_split(df, test_size=test_size, random_state=args.seed, 
                                              stratify=df['DIABETES_TYPE'])
    
    val_frac = getattr(args, 'val_size', 0.1)
    if val_frac > 0 and len(train_df_full) > 50:
        train_df, val_df = train_test_split(train_df_full, test_size=val_frac, 
                                            random_state=args.seed, stratify=train_df_full['DIABETES_TYPE'])
    else:
        train_df, val_df = train_df_full, None

    # Fill NaNs
    for c in cont_cols:
        med = train_df[c].median()
        train_df[c] = train_df[c].fillna(med)
        if val_df is not None:
            val_df[c] = val_df[c].fillna(med)
        test_df[c] = test_df[c].fillna(med)

    # Feature engineering
    skew_candidates = ['TGL', 'HS_CRP', 'ACR', 'BLOOD_SUGAR_F', 'BLOOD_SUGAR_PP']
    skew_cols = [c for c in skew_candidates if c in cont_cols]
    for c in skew_cols:
        new_c = f'LOG1P_{c}'
        train_df[new_c] = np.log1p(train_df[c].astype(float).clip(lower=0))
        if val_df is not None:
            val_df[new_c] = np.log1p(val_df[c].astype(float).clip(lower=0))
        test_df[new_c] = np.log1p(test_df[c].astype(float).clip(lower=0))
        cont_cols.append(new_c)

    if 'AGE' in cont_cols and 'BMI' in cont_cols:
        train_df['AGE_BMI'] = train_df['AGE'] * train_df['BMI']
        if val_df is not None:
            val_df['AGE_BMI'] = val_df['AGE'] * val_df['BMI']
        test_df['AGE_BMI'] = test_df['AGE'] * test_df['BMI']
        cont_cols.append('AGE_BMI')

    if 'AGE' in cont_cols:
        train_df['AGE_SQ'] = train_df['AGE'] ** 2
        if val_df is not None:
            val_df['AGE_SQ'] = val_df['AGE'] ** 2
        test_df['AGE_SQ'] = test_df['AGE'] ** 2
        cont_cols.append('AGE_SQ')

    # Categorical encoding
    for c in potential_cat:
        train_df[c] = train_df[c].fillna('__NA__').astype(str)
        if val_df is not None:
            val_df[c] = val_df[c].fillna('__NA__').astype(str)
        test_df[c] = test_df[c].fillna('__NA__').astype(str)

    for c in potential_cat:
        mapping = cat_maps.get(c, {})
        train_df[c] = train_df[c].map(mapping).fillna(0).astype(int)
        if val_df is not None:
            val_df[c] = val_df[c].map(mapping).fillna(0).astype(int)
        test_df[c] = test_df[c].map(mapping).fillna(0).astype(int)

    # Scaling
    scaler = StandardScaler()
    if len(cont_cols) > 0:
        scaler.fit(train_df[cont_cols])
        train_df[cont_cols] = scaler.transform(train_df[cont_cols])
        if val_df is not None:
            val_df[cont_cols] = scaler.transform(val_df[cont_cols])
        test_df[cont_cols] = scaler.transform(test_df[cont_cols])

    # Convert to numpy
    Xc_train = train_df[potential_cat].values.astype(int) if len(potential_cat) > 0 else np.zeros((len(train_df), 0), dtype=int)
    Xn_train = train_df[cont_cols].values.astype(float) if len(cont_cols) > 0 else None
    y_train = train_df['DIABETES_TYPE'].values.astype(int)

    if val_df is not None:
        Xc_val = val_df[potential_cat].values.astype(int) if len(potential_cat) > 0 else np.zeros((len(val_df), 0), dtype=int)
        Xn_val = val_df[cont_cols].values.astype(float) if len(cont_cols) > 0 else None
        y_val = val_df['DIABETES_TYPE'].values.astype(int)
    else:
        Xc_val = Xn_val = y_val = None

    Xc_test = test_df[potential_cat].values.astype(int) if len(potential_cat) > 0 else np.zeros((len(test_df), 0), dtype=int)
    Xn_test = test_df[cont_cols].values.astype(float) if len(cont_cols) > 0 else None
    y_test = test_df['DIABETES_TYPE'].values.astype(int)

    # Device
    if args.device == 'cuda' and torch.cuda.is_available():
        device = torch.device('cuda')
    elif args.device == 'mps' and getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
        device = torch.device('mps')
    else:
        device = torch.device('cpu')

    # Model
    model = SAINT(
        n_cat=len(potential_cat),
        n_cont=len(cont_cols),
        cat_cardinalities=cat_cardinalities,
        dim=args.dim,
        depth=getattr(args, 'depth', 4),
        heads=getattr(args, 'heads', 8),
        dropout=getattr(args, 'dropout', 0.2)
    )
    model.to(device)

    # Loss and optimizer
    neg = (y_train == 0).sum()
    pos = (y_train == 1).sum()
    pos_weight = float(neg) / float(pos) if pos > 0 else 1.0
    
    use_focal = getattr(args, 'focal', False)
    if use_focal:
        criterion = FocalLoss(gamma=getattr(args, 'focal_gamma', 2.0))
    else:
        criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos_weight))

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=getattr(args, 'weight_decay', 1e-3))
    
    use_onecycle = getattr(args, 'onecycle', True)
    if use_onecycle:
        steps_per_epoch = max(1, int(np.ceil(len(y_train) / float(args.batch_size))))
        scheduler = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=getattr(args, 'max_lr', args.lr * 10),
                                                        steps_per_epoch=steps_per_epoch, epochs=args.epochs)
    else:
        scheduler = torch.optim.lr_scheduler.StepLR(opt, step_size=30, gamma=0.5)

    # Batch iterator
    batch_size = args.batch_size
    use_sampler = getattr(args, 'use_sampler', False)
    
    def batch_iter(Xc, Xn, y, bs):
        if use_sampler:
            Xc_t = torch.tensor(Xc, dtype=torch.long)
            Xn_t = torch.tensor(Xn.astype(np.float32), dtype=torch.float32) if Xn is not None else None
            y_t = torch.tensor(y.astype(np.float32), dtype=torch.float32)
            dataset_tensors = [Xc_t]
            if Xn_t is not None:
                dataset_tensors.append(Xn_t)
            dataset_tensors.append(y_t)
            ds = torch.utils.data.TensorDataset(*dataset_tensors)
            class_sample_count = np.array([(y == t).sum() for t in np.unique(y)])
            weight = 1.0 / class_sample_count
            samples_weight = np.array([weight[int(t)] for t in y])
            samples_weight = torch.from_numpy(samples_weight).double()
            sampler = torch.utils.data.sampler.WeightedRandomSampler(samples_weight, len(samples_weight))
            loader = torch.utils.data.DataLoader(ds, batch_size=bs, sampler=sampler)
            for batch in loader:
                if Xn is not None:
                    Xc_b, Xn_b, y_b = batch
                else:
                    Xc_b, y_b = batch[0], batch[-1]
                    Xn_b = None
                yield Xc_b.to(device), Xn_b.to(device) if Xn_b is not None else None, y_b.to(device)
        else:
            n = len(y)
            idx = np.arange(n)
            np.random.shuffle(idx)
            for i in range(0, n, bs):
                batch = idx[i:i+bs]
                Xc_b = torch.tensor(Xc[batch], dtype=torch.long, device=device)
                Xn_b = torch.tensor(Xn[batch].astype(np.float32), dtype=torch.float32, device=device) if Xn is not None else None
                y_b = torch.tensor(y[batch].astype(np.float32), dtype=torch.float32, device=device)
                yield Xc_b, Xn_b, y_b

    def evaluate(Xc, Xn, y_true):
        model.eval()
        losses = []
        probs_list = []
        with torch.no_grad():
            n = len(y_true)
            for i in range(0, n, batch_size):
                b = slice(i, i+batch_size)
                Xc_b = torch.tensor(Xc[b], dtype=torch.long, device=device)
                Xn_b = torch.tensor(Xn[b].astype(np.float32), dtype=torch.float32, device=device) if Xn is not None else None
                y_b = torch.tensor(y_true[b].astype(np.float32), dtype=torch.float32, device=device)
                logits = model(Xc_b, Xn_b)
                loss = criterion(logits, y_b)
                losses.append(loss.item() * len(y_b))
                probs = torch.sigmoid(logits).cpu().numpy()
                probs_list.append(probs)
        if len(probs_list) == 0:
            return None, None, None
        probs_all = np.concatenate(probs_list)
        loss_all = sum(losses) / len(y_true)
        preds_all = (probs_all >= 0.5).astype(int)
        try:
            auc = float(roc_auc_score(y_true, probs_all))
        except Exception:
            auc = float('nan')
        acc = float(accuracy_score(y_true, preds_all))
        return loss_all, auc, acc

    # Training loop
    train_losses = []
    best_val_auc = -1.0
    best_epoch = -1
    epochs_no_improve = 0
    patience = getattr(args, 'patience', 20)

    for epoch in range(args.epochs):
        model.train()
        total_loss = 0.0
        n_seen = 0
        for Xc_b, Xn_b, y_b in batch_iter(Xc_train, Xn_train, y_train, batch_size):
            opt.zero_grad()
            logits = model(Xc_b, Xn_b)
            loss = criterion(logits, y_b)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            opt.step()
            if use_onecycle:
                try:
                    scheduler.step()
                except Exception:
                    pass
            total_loss += loss.item() * Xc_b.size(0)
            n_seen += Xc_b.size(0)
        train_loss = total_loss / len(y_train)
        train_losses.append(train_loss)

        if Xc_val is not None:
            val_loss, val_auc, val_acc = evaluate(Xc_val, Xn_val, y_val)
            print(f"Epoch {epoch+1}/{args.epochs} train_loss={train_loss:.4f} val_loss={val_loss:.4f} val_auc={val_auc:.4f} val_acc={val_acc:.4f}")
        else:
            val_loss, val_auc, val_acc = None, None, None
            print(f"Epoch {epoch+1}/{args.epochs} train_loss={train_loss:.4f}")

        if not use_onecycle:
            scheduler.step()

        if val_auc is not None and not np.isnan(val_auc):
            if val_auc > best_val_auc:
                best_val_auc = val_auc
                best_epoch = epoch
                epochs_no_improve = 0
                torch.save(model.state_dict(), os.path.join(args.save_dir, 'best_model.pt'))
            else:
                epochs_no_improve += 1
        
        if epochs_no_improve >= patience:
            print(f"Early stopping after {epoch+1} epochs. Best val_auc={best_val_auc:.4f} at epoch {best_epoch+1}")
            break

    # Evaluation
    model.eval()
    with torch.no_grad():
        Xc_t = torch.tensor(Xc_test, dtype=torch.long, device=device)
        Xn_t = torch.tensor(Xn_test.astype(np.float32), dtype=torch.float32, device=device) if Xn_test is not None else None
        logits = model(Xc_t, Xn_t).cpu().numpy()
        probs = 1 / (1 + np.exp(-logits))

    try:
        roc_auc = float(roc_auc_score(y_test, probs))
    except Exception as e:
        print(f"Warning: Could not compute ROC AUC: {e}")
        roc_auc = float('nan')
    
    fpr, tpr, _ = roc_curve(y_test, probs)
    print(f"\nTest ROC AUC: {roc_auc:.4f}")

    # Plot ROC
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.plot(fpr, tpr, linewidth=2.5, label=f'ROC AUC={roc_auc:.4f}', color='#1f77b4')
    ax.plot([0, 1], [0, 1], linestyle='--', color='gray', alpha=0.5, linewidth=2, label='Random Classifier')
    ax.set_xlabel('False Positive Rate', fontsize=12, fontweight='bold')
    ax.set_ylabel('True Positive Rate', fontsize=12, fontweight='bold')
    ax.set_title('ROC Curve - SAINT', fontsize=14, fontweight='bold')
    ax.legend(fontsize=11, loc='lower right')
    ax.grid(True, alpha=0.3)
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    plt.savefig(os.path.join(args.save_dir, 'roc_saint.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)

    preds = (probs >= 0.5).astype(int)
    cm = confusion_matrix(y_test, preds, labels=[0,1])
    acc = accuracy_score(y_test, preds)
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, preds, average='binary', zero_division=0)
    print('Confusion matrix:\n', cm)
    print(f"Accuracy: {acc:.4f}  Precision: {prec:.4f}  Recall: {rec:.4f}  F1: {f1:.4f}")
    print('Classification report:\n', classification_report(y_test, preds, zero_division=0))

    # Plot confusion matrix
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(cm, cmap='Blues', aspect='auto')
    plt.colorbar(im, ax=ax, label='Count')
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            text = ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                          color="white" if cm[i, j] > cm.max() / 2 else "black",
                          fontsize=16, fontweight='bold')
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Negative (0)', 'Positive (1)'], fontsize=11)
    ax.set_yticklabels(['Negative (0)', 'Positive (1)'], fontsize=11)
    ax.set_xlabel('Predicted Label', fontsize=12, fontweight='bold')
    ax.set_ylabel('True Label', fontsize=12, fontweight='bold')
    ax.set_title('Confusion Matrix - SAINT', fontsize=14, fontweight='bold')
    plt.savefig(os.path.join(args.save_dir, 'cm_saint.png'), dpi=300, bbox_inches='tight')
    plt.close()

    torch.save(model.state_dict(), os.path.join(args.save_dir, 'saint_model.pt'))
    metrics = {
        'model': 'SAINT',
        'roc_auc': roc_auc if not np.isnan(roc_auc) else None,
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1': float(f1),
        'confusion_matrix': cm.tolist()
    }
    import json
    with open(os.path.join(args.save_dir, 'metrics_saint.json'), 'w') as fh:
        json.dump(metrics, fh, indent=2)

    # Plot training loss
    if len(train_losses) > 0:
        fig, ax = plt.subplots(figsize=(10, 6))
        epochs_range = range(1, len(train_losses) + 1)
        ax.plot(epochs_range, train_losses, 'o-', linewidth=2.5, markersize=6, label='Training Loss', color='#1f77b4')
        ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
        ax.set_ylabel('Loss (Binary Crossentropy)', fontsize=12, fontweight='bold')
        ax.set_title('Training Loss Curve - SAINT', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(args.save_dir, 'loss_curve_saint.png'), dpi=300, bbox_inches='tight')
        plt.close(fig)
        # Load best model if it exists
        best_model_path = os.path.join(args.save_dir, 'best_model.pt')
        if os.path.exists(best_model_path):
            model.load_state_dict(torch.load(best_model_path, map_location=device))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default='Dataset/Bio_4_f_T1&2.csv')
    parser.add_argument('--save-dir', default='Outputs/bio12_saint')
    parser.add_argument('--epochs', type=int, default=15)
    parser.add_argument('--batch-size', type=int, default=512)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--device', default='cuda', choices=['cpu', 'cuda', 'mps'])
    parser.add_argument('--dim', type=int, default=192, help='SAINT embedding dimension')
    parser.add_argument('--depth', type=int, default=4, help='Number of SAINT blocks')
    parser.add_argument('--heads', type=int, default=8, help='Number of attention heads')
    parser.add_argument('--weight-decay', type=float, default=1e-3)
    parser.add_argument('--dropout', type=float, default=0.2)
    parser.add_argument('--onecycle', action='store_true', default=True)
    parser.add_argument('--max-lr', type=float, default=1e-3)
    parser.add_argument('--val-size', type=float, default=0.1)
    parser.add_argument('--patience', type=int, default=9)
    parser.add_argument('--focal', action='store_true', default=False)
    parser.add_argument('--focal-gamma', type=float, default=2.0)
    parser.add_argument('--use-sampler', action='store_true', default=False)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    train(args)
