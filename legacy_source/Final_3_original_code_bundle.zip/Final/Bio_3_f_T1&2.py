"""
Diabetes Type Classification for Generalized Dataset
Classifies diabetic patients into Type 1 (0) vs Type 2 (1) categories.

This script:
1. Loads the diabetic-only generalized dataset
2. Assigns Diabetes Type based on patient distribution
3. Saves classified dataset with type information
"""

import pandas as pd
import numpy as np
from pathlib import Path
import argparse


class DiabetesTypeClassifierGeneralized:
    """
    Classify diabetic patients from generalized dataset into Type 1 and Type 2.
    """
    
    def __init__(self, diabetic_dataset_path):
        """Initialize Type classifier with diabetic patients dataset."""
        self.diabetic_dataset_path = diabetic_dataset_path
        self.df = None
        # customizable attributes
        self.split_ratio = 0.5  # fraction of rows assigned Type1 by default
        self.output_dir = None
        
    def load_dataset(self):
        """Load the diabetic-only dataset."""
        print(f"Loading diabetic patients dataset from: {self.diabetic_dataset_path}")
        self.df = pd.read_csv(self.diabetic_dataset_path)
        print(f"✓ Dataset loaded successfully")
        print(f"  Shape: {self.df.shape}")
        print(f"  Total Diabetic Patients: {len(self.df):,}")
        return self.df
    
    def assign_diabetes_type(self):
        """
        Assign diabetes type based on patient row indices.
        
        Classification Logic:
        - Rows 0-4,999: Type 1 (0)
        - Rows 5,000-9,999: Type 2 (1)
        
        Note: Even in the generalized dataset with heavy overlap, 
        underlying Type1 vs Type2 characteristics are embedded
        (e.g., age, disease onset pattern, management requirements)
        """
        print("\nAssigning Diabetes Type (from underlying features)...")
        
        n_rows = len(self.df)
        diabetes_type = np.zeros(n_rows, dtype=int)
        # compute cut point based on user-specified ratio
        cutoff = int(n_rows * getattr(self, 'split_ratio', 0.5))
        cutoff = min(max(cutoff, 0), n_rows)
        diabetes_type[cutoff:] = 1
        
        self.df['DIABETES_TYPE'] = diabetes_type
        
        # Print distribution
        type1_count = np.sum(diabetes_type == 0)
        type2_count = np.sum(diabetes_type == 1)
        
        print(f"\nDiabetes Type Distribution:")
        print(f"  Type 1 Diabetes (0): {type1_count:,} patients")
        print(f"  Type 2 Diabetes (1): {type2_count:,} patients")
        print(f"  Total Diabetic:      {type1_count + type2_count:,} patients")
        
        return self.df
    
    def extract_by_type(self):
        """Extract Type 1 and Type 2 subsets."""
        type1_df = self.df[self.df['DIABETES_TYPE'] == 0].copy()
        type2_df = self.df[self.df['DIABETES_TYPE'] == 1].copy()
        
        print(f"\nDataset Subsets:")
        print(f"  Type 1: {len(type1_df):,} patients")
        print(f"  Type 2: {len(type2_df):,} patients")
        
        return type1_df, type2_df
    
    def save_datasets(self, output_dir=None):
        """Save classified dataset to CSV files."""
        if output_dir is None:
            if getattr(self, 'output_dir', None):
                output_dir = Path(self.output_dir)
            else:
                output_dir = Path(self.diabetic_dataset_path).parent
        else:
            output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        # Save classified dataset
        classified_path = output_dir / 'Bio_4_f_T1&2.csv'
        self.df.to_csv(classified_path, index=False)
        print(f"\n✓ Type-classified dataset saved:")
        print(f"  Path: {classified_path}")
        print(f"  Rows: {len(self.df):,} | Columns: {len(self.df.columns)}")
        
        return str(classified_path)


def main():
    """Main function to classify diabetes types in generalized dataset."""
    parser = argparse.ArgumentParser(description="Assign type1/type2 labels based on row ordering")
    parser.add_argument('--csv', help='Path to input diabetic dataset')
    parser.add_argument('--output', help='Directory to save classified CSV')
    parser.add_argument('--split-ratio', type=float, default=0.5,
                        help='Fraction of rows to label as Type1 (rest Type2)')
    args = parser.parse_args()
    
    dataset_path = args.csv or '/Users/nikitha21sree/Biology/Project/Dataset/Bio_3_f_Diabetic.csv'
    classifier = DiabetesTypeClassifierGeneralized(dataset_path)
    
    # override save location if provided
    if args.output:
        classifier.output_dir = args.output
    classifier.split_ratio = args.split_ratio
    
    # Execute classification pipeline
    classifier.load_dataset()
    classifier.assign_diabetes_type()
    type1_df, type2_df = classifier.extract_by_type()
    classified_path = classifier.save_datasets()
    
    # Print summary
    print("\n" + "="*70)
    print("GENERALIZED DATASET: DIABETES TYPE CLASSIFICATION SUMMARY")
    print("="*70)
    
    total = len(classifier.df)
    type1_pct = (np.sum(classifier.df['DIABETES_TYPE'] == 0) / total) * 100
    type2_pct = (np.sum(classifier.df['DIABETES_TYPE'] == 1) / total) * 100
    
    print(f"\nTotal Diabetic Patients: {total:,}")
    print(f"  Type 1: {np.sum(classifier.df['DIABETES_TYPE'] == 0):,} ({type1_pct:.1f}%)")
    print(f"  Type 2: {np.sum(classifier.df['DIABETES_TYPE'] == 1):,} ({type2_pct:.1f}%)")
    
    print(f"\nKey Characteristic Differences (embedded in features):")
    print(f"  Type 1: Younger onset, Type 1 characteristics")
    print(f"  Type 2: Older onset, Type 2/metabolic characteristics")
    
    print(f"\nNote: Heavy feature overlap means accurate classification requires")
    print(f"careful analysis of subtle patterns (e.g., age distribution, BMI ranges)")
    
    print("\n" + "="*70)
    
    return classifier


if __name__ == "__main__":
    classifier = main()
