#!/usr/bin/env python3
"""Bio_8_f_Cardiovascular.py

Classify diabetic patients for cardiovascular disease severity into four balanced classes
(LOW, MILD, MODERATE, SEVERE) using LDL_DIRECT, TGL, TCL_HDL_RATIO, TOTAL_CHOLESTEROL, PLT.

Score Points: Mild=10, Moderate=20, Severe=35
Produces: Dataset/Bio_f_Cardiovascular.csv

Multi-disease note:
- TGL and TOTAL_CHOLESTEROL overlap with hepatic, neuropathy
- TCL_HDL_RATIO critical for cardiovascular risk
- PLT (platelet count) indicates clotting risk
"""
import os
import sys
import pandas as pd
import numpy as np


INPUT_PATH = os.path.join('Dataset', 'Bio_3_f_Diabetic.csv')
OUTPUT_PATH = os.path.join('Dataset', 'Bio_9_f_Cardiovascular.csv')


def get_ldl_score(ldl):
    """LDL Direct scoring (higher = worse)."""
    try:
        ldl = float(ldl)
    except (ValueError, TypeError):
        return 0
    if ldl < 100:
        return 0  # Low risk
    if 100 <= ldl < 130:
        return 1  # Moderate
    if 130 <= ldl < 160:
        return 2  # High
    return 3  # Very High (>=160)


def get_tgl_score(tgl):
    """Triglyceride scoring."""
    try:
        tgl = float(tgl)
    except (ValueError, TypeError):
        return 0
    if tgl < 150:
        return 0
    if 150 <= tgl < 200:
        return 1
    if 200 <= tgl < 500:
        return 2
    return 3  # >=500


def get_tcl_hdl_ratio_score(ratio):
    """TCL/HDL Ratio scoring (higher = worse)."""
    try:
        ratio = float(ratio)
    except (ValueError, TypeError):
        return 0
    if ratio < 4.0:
        return 0  # Low risk
    if 4.0 <= ratio < 5.0:
        return 1  # Moderate
    if 5.0 <= ratio < 6.0:
        return 2  # High
    return 3  # Very High (>=6.0)


def get_total_chol_score(tc):
    """Total Cholesterol scoring."""
    try:
        tc = float(tc)
    except (ValueError, TypeError):
        return 0
    if tc < 200:
        return 0  # Low risk
    if 200 <= tc < 240:
        return 1  # Moderate
    if 240 <= tc < 300:
        return 2  # High
    return 3  # Very High (>=300)


def get_plt_score(plt):
    """Platelet count scoring (clotting risk; abnormal = high/low risk)."""
    try:
        plt = float(plt)
    except (ValueError, TypeError):
        return 0
    if 150 <= plt <= 400:
        return 0  # Normal
    if (100 <= plt < 150) or (400 < plt <= 700):
        return 1  # Borderline
    if (75 <= plt < 100) or (700 < plt):
        return 2  # Abnormal
    return 3  # Severe (<75 or >>700)


def compute_cv_score(row):
    """Composite cardiovascular risk score."""
    ldl_score = get_ldl_score(row.get('LDL_DIRECT', 0))
    tgl_score = get_tgl_score(row.get('TGL', 0))
    ratio_score = get_tcl_hdl_ratio_score(row.get('TCL_HDL_RATIO', 0))
    tc_score = get_total_chol_score(row.get('TOTAL_CHOLESTEROL', 0))
    plt_score = get_plt_score(row.get('PLT', 0))
    
    # Weighted composite
    composite = (ldl_score * 0.30 + tgl_score * 0.25 + ratio_score * 0.25 +
                 tc_score * 0.15 + plt_score * 0.05)
    return composite


from dataset_utils import assign_balanced_severity as _assign

def assign_balanced_severity(df, score_col='CV_SCORE'):
    # general label order consistent across diseases
    label_order = ['NONE', 'SEVERE', 'MILD', 'MODERATE']
    return _assign(df, score_col, label_order)


def main():
    if not os.path.exists(INPUT_PATH):
        print(f"Input file not found: {INPUT_PATH}")
        sys.exit(1)

    print(f"Loading diabetic dataset from: {INPUT_PATH}")
    df = pd.read_csv(INPUT_PATH)
    print(f"Loaded: {df.shape[0]} rows × {df.shape[1]} columns\n")

    # Ensure required numeric columns exist and are cleaned
    from dataset_utils import ensure_numeric_cols
    required = ['LDL_DIRECT', 'TGL', 'TCL_HDL_RATIO', 'TOTAL_CHOLESTEROL', 'PLT']
    df = ensure_numeric_cols(df, required, fill_strategy='median', default=0)

    # Compute composite score
    df['CV_SCORE'] = df.apply(compute_cv_score, axis=1)

    print("Computing composite cardiovascular risk score...")
    print(f"Computed score range: {df['CV_SCORE'].min():.2f} - {df['CV_SCORE'].max():.2f}\n")

    # Assign balanced severity
    df['CARDIOVASCULAR_SEVERITY'] = assign_balanced_severity(df, score_col='CV_SCORE')

    dist = df['CARDIOVASCULAR_SEVERITY'].value_counts().reindex(
        ['NONE', 'SEVERE', 'MILD', 'MODERATE']).fillna(0).astype(int)
    print('Severity distribution after balanced assignment:')
    for lvl in ['NONE', 'SEVERE', 'MILD', 'MODERATE']:
        print(f"  {lvl:<8}: {dist[lvl]:,} patients")

    # Summary stats
    print('\nCardiovascular Summary by Severity:\n')
    for lvl in ['SEVERE', 'MODERATE', 'MILD', 'NONE']:
        level_data = df[df['CARDIOVASCULAR_SEVERITY'] == lvl]
        avg_ldl = level_data['LDL_DIRECT'].mean()
        avg_tgl = level_data['TGL'].mean()
        avg_ratio = level_data['TCL_HDL_RATIO'].mean()
        print(f"{lvl}: count={len(level_data):,}")
        print(f"  Avg LDL: {avg_ldl:.2f} mg/dL")
        print(f"  Avg TGL: {avg_tgl:.2f} mg/dL")
        print(f"  Avg TCL/HDL Ratio: {avg_ratio:.2f}\n")

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"✓ Saved cardiovascular-classified dataset to: {OUTPUT_PATH}")


if __name__ == '__main__':
    main()
