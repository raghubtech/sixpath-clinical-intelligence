#!/usr/bin/env python3
"""Bio_6_f_Nephropathy.py

Classify diabetic patients for nephropathy severity into four balanced
classes (MILD, MODERATE, SEVERE, CRITICAL) using SR_CREATININE and ACR
with ranges taken from the provided table. Produces Dataset/Bio_f_Nephropathy.csv
"""
import os
import sys
import pandas as pd
import numpy as np
import argparse


INPUT_PATH = os.path.join('Dataset', 'Bio_3_f_Diabetic.csv')
OUTPUT_PATH = os.path.join('Dataset', 'Bio_7_f_Nephropathy.csv')


def map_egfr_score_from_creatinine(cr):
    # Attachment maps creatinine ranges to kidney function. We derive an
    # eGFR-like score from serum creatinine using the same buckets.
    try:
        if np.isnan(cr):
            return 0
    except Exception:
        pass
    try:
        cr = float(cr)
    except Exception:
        return 0
    if cr < 1.0:
        return 0
    elif cr < 1.6:
        return 1
    elif cr < 2.6:
        return 2
    else:
        return 3


def map_acr_score(acr):
    try:
        if np.isnan(acr):
            return 0
    except Exception:
        pass
    try:
        acr = float(acr)
    except Exception:
        return 0
    if acr < 30:
        return 0
    elif acr < 301:
        return 1
    elif acr < 1001:
        return 2
    else:
        return 3


def map_creatinine_score(cr):
    # Use the same creatinine buckets as a direct severity contributor.
    return map_egfr_score_from_creatinine(cr)


from dataset_utils import assign_balanced_severity as _assign

def assign_balanced_severity(df, score_col='NEPHRO_SCORE'):
    # Use shared utility with new label order
    label_order = ['NONE', 'SEVERE', 'MILD', 'MODERATE']
    return _assign(df, score_col, label_order)


def main():
    parser = argparse.ArgumentParser(description="Generate nephropathy severity labels")
    parser.add_argument('--csv', help='Input diabetic dataset path')
    parser.add_argument('--output', help='Output CSV path')
    parser.add_argument('--merge-mild-moderate', action='store_true',
                        help='Collapse MILD and MODERATE into a single category after assignment')
    args = parser.parse_args()
    
    input_path = args.csv or INPUT_PATH
    output_path = args.output or OUTPUT_PATH

    if not os.path.exists(input_path):
        print(f"Input file not found: {input_path}")
        sys.exit(1)

    print(f"Loading diabetic dataset from: {input_path}")
    df = pd.read_csv(input_path)
    print(f"Loaded: {df.shape[0]} rows × {df.shape[1]} columns\n")

    # Ensure expected columns exist; fallbacks if necessary
    creat_col = 'SR_CREATININE' if 'SR_CREATININE' in df.columns else (
        'CREATININE' if 'CREATININE' in df.columns else None)
    acr_col = 'ACR' if 'ACR' in df.columns else (
        'URINE_ACR' if 'URINE_ACR' in df.columns else None)

    if creat_col is None or acr_col is None:
        print('Required columns not found. Expected SR_CREATININE and ACR (or equivalents).')
        print('Columns present:', ', '.join(df.columns.tolist()))
        sys.exit(1)

    # Fill missing values conservatively using shared helper
    from dataset_utils import ensure_numeric_cols
    df = ensure_numeric_cols(df, [creat_col, acr_col], fill_strategy='median', default=0)

    # Compute component scores
    df['EGFR_SCORE'] = df[creat_col].apply(map_egfr_score_from_creatinine)
    df['ACR_SCORE'] = df[acr_col].apply(map_acr_score)
    df['CREAT_SCORE'] = df[creat_col].apply(map_creatinine_score)

    # Composite score (0..3); higher => worse
    df['NEPHRO_SCORE'] = (df['EGFR_SCORE'] + df['ACR_SCORE'] + df['CREAT_SCORE']) / 3.0

    print("Computing composite nephropathy score using SR_CREATININE and ACR...")
    print(f"Computed composite score range: {df['NEPHRO_SCORE'].min():.2f} - {df['NEPHRO_SCORE'].max():.2f}\n")

    # Assign balanced severity
    df['NEPHROPATHY_SEVERITY'] = assign_balanced_severity(df, score_col='NEPHRO_SCORE')
    if args.merge_mild_moderate:
        df['NEPHROPATHY_SEVERITY'] = df['NEPHROPATHY_SEVERITY'].replace(
            {'MILD': 'MILD_MOD', 'MODERATE': 'MILD_MOD'})
        print("Merged MILD/MODERATE into MILD_MOD (overlap removed).", flush=True)

    # Show distribution
    # compute distribution, adjusting order if classes merged
    order = ['NONE','SEVERE','MILD','MODERATE']
    if args.merge_mild_moderate:
        order = ['NONE','SEVERE','MILD_MOD']
    dist = df['NEPHROPATHY_SEVERITY'].value_counts().reindex(order).fillna(0).astype(int)
    print('Assigning balanced severity groups (~n/4 per label)...\n')
    print('Severity distribution after balanced assignment:')
    for lvl in order:
        print(f"  {lvl:<8}: {dist[lvl]:,} patients")

    # Summary stats
    print('\nNephropathy Summary by Severity:\n')
    summary_levels = ['NONE','SEVERE','MILD','MODERATE']
    if args.merge_mild_moderate:
        summary_levels = ['NONE','SEVERE','MILD_MOD']
    for lvl in summary_levels:
        level_data = df[df['NEPHROPATHY_SEVERITY'] == lvl]
        avg_acr = level_data[acr_col].mean()
        avg_creat = level_data[creat_col].mean()
        print(f"{lvl}: count={len(level_data):,}")
        print(f"  Avg ACR: {avg_acr:.1f} mg/g")
        print(f"  Avg Creatinine: {avg_creat:.2f} mg/dL\n")

    # Save result
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    print(f"\n✓ Saved nephropathy-classified dataset to: {output_path}")


if __name__ == '__main__':
    main()
