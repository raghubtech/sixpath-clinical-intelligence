#!/usr/bin/env python3
"""Bio_7_f_Neuropathy.py

Classify diabetic patients for neuropathy severity into four balanced classes
(MILD, MODERATE, SEVERE, CRITICAL) using ANKLE_BRACHIAL_INDEX, HS_CRP, ESR_30_MTS,
DIABETES_DURATION_YEARS, and TGL with ranges from clinical table.

Score Points: Mild=15, Moderate=25, Severe=40
Produces: Dataset/Bio_f_Neuropathy.csv

Multi-disease note:
- HS_CRP and TGL may overlap with other complications
- ANKLE_BRACHIAL_INDEX primary indicator of peripheral neuropathy/vascular disease
"""
import os
import sys
import pandas as pd
import numpy as np


INPUT_PATH = os.path.join('Dataset', 'Bio_3_f_Diabetic.csv')
OUTPUT_PATH = os.path.join('Dataset', 'Bio_8_f_Neuropathy.csv')


def get_abi_score(abi):
    """Ankle-Brachial Index scoring (lower = worse vascular function)."""
    try:
        abi = float(abi)
    except (ValueError, TypeError):
        return 0
    if abi >= 1.0:
        return 0  # Subclinical
    if 0.9 <= abi < 1.0:
        return 1  # Mild
    if 0.7 <= abi < 0.9:
        return 2  # Moderate
    return 3  # Severe (<0.7)


def get_hs_crp_score(crp):
    """High-sensitivity CRP scoring (inflammation marker)."""
    try:
        crp = float(crp)
    except (ValueError, TypeError):
        return 0
    if crp < 3.0:
        return 0  # Subclinical
    if 3.0 <= crp <= 10:
        return 1  # Mild
    if 10 < crp <= 20:
        return 2  # Moderate
    return 3  # Severe (>20)


def get_esr_score(esr):
    """ESR 30-minute score (inflammation)."""
    try:
        esr = float(esr)
    except (ValueError, TypeError):
        return 0
    if esr < 20:
        return 0  # Subclinical
    if 20 <= esr <= 40:
        return 1  # Mild
    if 40 < esr <= 60:
        return 2  # Moderate
    return 3  # Severe (>60)


def get_duration_score(years):
    """Diabetes duration score."""
    try:
        years = float(years)
    except (ValueError, TypeError):
        return 0
    if years < 5:
        return 0  # Subclinical
    if 5 <= years <= 10:
        return 1  # Mild
    if 10 < years <= 20:
        return 2  # Moderate
    return 3  # Severe (>20)


def get_tgl_score(tgl):
    """Triglyceride score."""
    try:
        tgl = float(tgl)
    except (ValueError, TypeError):
        return 0
    if tgl < 200:
        return 0
    if 200 <= tgl <= 300:
        return 1
    if 300 < tgl <= 500:
        return 2
    return 3  # >500


def compute_neuropathy_score(row):
    """Composite score using weighted multi-biomarker approach."""
    abi_score = get_abi_score(row.get('ANKLE_BRACHIAL_INDEX', 1.0))
    crp_score = get_hs_crp_score(row.get('HS_CRP', 0))
    esr_score = get_esr_score(row.get('ESR_30_MTS', 0))
    duration_score = get_duration_score(row.get('DIABETES_DURATION_YEARS', 0))
    tgl_score = get_tgl_score(row.get('TGL', 0))
    
    # Weighted composite (ABI most important for neuropathy)
    composite = (abi_score * 0.35 + crp_score * 0.25 + esr_score * 0.15 +
                 duration_score * 0.15 + tgl_score * 0.10)
    return composite


# use shared utility for balanced severity
def assign_balanced_severity(df, score_col='NEURO_SCORE'):
    """Wrapper around dataset_utils.assign_balanced_severity with new labels."""
    from dataset_utils import assign_balanced_severity as _assign
    # new label set as per requirements: NONE, SEVERE, MILD, MODERATE
    label_order = ['NONE', 'SEVERE', 'MILD', 'MODERATE']
    return _assign(df, score_col, label_order)


def main():
    if not os.path.exists(INPUT_PATH):
        print(f"Input file not found: {INPUT_PATH}")
        sys.exit(1)

    print(f"Loading diabetic dataset from: {INPUT_PATH}")
    df = pd.read_csv(INPUT_PATH)
    print(f"Loaded: {df.shape[0]} rows × {df.shape[1]} columns\n")

    # Ensure required columns exist and are numeric
    from dataset_utils import ensure_numeric_cols
    required = ['ANKLE_BRACHIAL_INDEX', 'HS_CRP', 'ESR_30_MTS', 'DIABETES_DURATION_YEARS', 'TGL']
    df = ensure_numeric_cols(df, required, fill_strategy='median', default=0)

    # Compute composite score
    df['NEURO_SCORE'] = df.apply(compute_neuropathy_score, axis=1)

    print("Computing composite neuropathy score...")
    print(f"Computed score range: {df['NEURO_SCORE'].min():.2f} - {df['NEURO_SCORE'].max():.2f}\n")

    # Assign balanced severity
    df['NEUROPATHY_SEVERITY'] = assign_balanced_severity(df, score_col='NEURO_SCORE')

    dist = df['NEUROPATHY_SEVERITY'].value_counts().reindex(
        ['NONE', 'SEVERE', 'MILD', 'MODERATE']).fillna(0).astype(int)
    print('Severity distribution after balanced assignment:')
    for lvl in ['NONE', 'SEVERE', 'MILD', 'MODERATE']:
        print(f"  {lvl:<8}: {dist[lvl]:,} patients")

    # Summary stats by severity
    print('\nNeuropathy Summary by Severity:\n')
    for lvl in ['NONE', 'SEVERE', 'MILD', 'MODERATE']:
        level_data = df[df['NEUROPATHY_SEVERITY'] == lvl]
        avg_abi = level_data['ANKLE_BRACHIAL_INDEX'].mean()
        avg_crp = level_data['HS_CRP'].mean()
        avg_esr = level_data['ESR_30_MTS'].mean()
        print(f"{lvl}: count={len(level_data):,}")
        print(f"  Avg ABI: {avg_abi:.2f}")
        print(f"  Avg HS_CRP: {avg_crp:.2f} mg/L")
        print(f"  Avg ESR: {avg_esr:.2f} min\n")

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"✓ Saved neuropathy-classified dataset to: {OUTPUT_PATH}")


if __name__ == '__main__':
    main()
