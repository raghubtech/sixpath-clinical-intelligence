"""
FT-Transformer style model for Bio_5_f_severity tabular classification
- Lightweight per-feature tokenization
- Transformer encoder over feature tokens
- Optional Optuna hyperparameter search (disabled by default)

Sanity-run default: 1 epoch (use --optuna to run full study)
"""

import argparse
from pathlib import Path
from matplotlib import cm
import pandas as pd
import numpy as np
import random
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, roc_auc_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import json
import os
import warnings
warnings.filterwarnings('ignore')

# Set random seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
DEVICE = torch.device('cuda' if torch.cuda.is_available() else ('mps' if getattr(torch,'has_mps',False) else 'cpu'))

class TabularDataset(Dataset):
    def __init__(self, X_cont, X_cat, y):
        self.X_cont = X_cont.astype(np.float32)
        self.X_cat = X_cat.astype(np.int64) if X_cat is not None else None
        self.y = y.astype(np.int64)
    def __len__(self):
        return len(self.y)
    def __getitem__(self, idx):
        cont = torch.from_numpy(self.X_cont[idx])
        cat = torch.from_numpy(self.X_cat[idx]) if self.X_cat is not None else None
        return cont, cat, int(self.y[idx])

class FTLikeTransformer(nn.Module):
    def __init__(self, n_cont, cat_cardinals, embed_dim=64, n_heads=4, n_layers=4, dropout=0.1):
        super().__init__()
        self.n_cont = n_cont
        self.cat_cardinals = cat_cardinals or []
        self.embed_dim = embed_dim
        # Per-continuous-feature projection (feature-specific)
        self.cont_projs = nn.ModuleList([nn.Linear(1, embed_dim) for _ in range(n_cont)])
        # Categorical embeddings
        self.cat_embeds = nn.ModuleList([nn.Embedding(card, embed_dim) for card in self.cat_cardinals])
        # Positional (feature) embeddings
        n_tokens = n_cont + len(self.cat_cardinals)
        self.feat_pos = nn.Parameter(torch.randn(n_tokens, embed_dim))
        # Transformer
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=n_heads, dim_feedforward=embed_dim*2, dropout=dropout, activation='gelu')
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.norm = nn.LayerNorm(embed_dim)
        # Classifier
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim, embed_dim//2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim//2, 4)
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            if isinstance(m, nn.Embedding):
                nn.init.normal_(m.weight, std=0.01)

    def forward(self, x_cont, x_cat=None):
        # x_cont: (B, n_cont)
        B = x_cont.size(0)
        cont_tokens = []
        for i, proj in enumerate(self.cont_projs):
            v = x_cont[:, i].unsqueeze(1)  # (B,1)
            t = proj(v)  # (B, embed)
            cont_tokens.append(t)
        if cont_tokens:
            cont_stack = torch.stack(cont_tokens, dim=1)  # (B, n_cont, embed)
        else:
            cont_stack = torch.zeros(B,0,self.embed_dim, device=x_cont.device)
        cat_stack = []
        if self.cat_embeds and x_cat is not None:
            for i, emb in enumerate(self.cat_embeds):
                cat_stack.append(emb(x_cat[:, i]))
            cat_stack = torch.stack(cat_stack, dim=1)
        else:
            cat_stack = torch.zeros(B,0,self.embed_dim, device=x_cont.device)
        tokens = torch.cat([cont_stack, cat_stack], dim=1)  # (B, n_tokens, embed)
        tokens = tokens + self.feat_pos.unsqueeze(0)
        # transformer expects (S,B,E)
        tokens = tokens.transpose(0,1)
        out = self.transformer(tokens)  # (S,B,E)
        out = out.transpose(0,1)  # (B,S,E)
        # Pool (mean)
        pooled = out.mean(dim=1)
        pooled = self.norm(pooled)
        logits = self.classifier(pooled)
        return logits

class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0):
        super().__init__()
        self.gamma = gamma
        self.ce = nn.CrossEntropyLoss()
    def forward(self, logits, targets):
        logpt = -self.ce(logits, targets)
        pt = logpt.exp()
        loss = -((1-pt)**self.gamma) * logpt
        return loss.mean()


def load_and_preprocess(path):
    df = pd.read_csv(path)
    # Drop ID and target
    target = 'SEVERITY_LEVEL'
    assert target in df.columns
    y = df[target].copy()
    # encode target to 0..3 using label encoder with specified order if present
    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    # choose columns: continuous numeric features excluding target and PATIENT_ID
    exclude = {'PATIENT_ID', target}
    numeric_cols = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]
    # detect some categorical columns by name
    # treat BLOOD_GROUP, RH_TYPING as categorical if present
    cat_cols = [c for c in ['BLOOD_GROUP','RH_TYPING'] if c in df.columns]
    cont_cols = [c for c in numeric_cols if c not in cat_cols]
    X_cont = df[cont_cols].fillna(df[cont_cols].median()).values
    # standardize
    scaler = StandardScaler()
    X_cont = scaler.fit_transform(X_cont)
    if cat_cols:
        X_cat = df[cat_cols].fillna('NA')
        X_cat_enc = np.stack([LabelEncoder().fit_transform(X_cat[c].astype(str)) for c in cat_cols], axis=1)
        cat_cardinals = [int(X_cat[c].nunique()) for c in cat_cols]
    else:
        X_cat_enc = None
        cat_cardinals = []
    return X_cont, X_cat_enc, y_enc, cont_cols, cat_cols, cat_cardinals


def train_one_epoch(model, loader, opt, loss_fn):
    model.train()
    losses = []
    for cont, cat, y in loader:
        cont = cont.to(DEVICE)
        cat = cat.to(DEVICE) if cat is not None else None
        y = y.to(DEVICE)
        logits = model(cont, cat)
        loss = loss_fn(logits, y)
        opt.zero_grad()
        loss.backward()
        opt.step()
        losses.append(loss.item())
    return float(np.mean(losses))


def eval_model(model, loader):
    model.eval()
    ys = []
    preds = []
    with torch.no_grad():
        for cont, cat, y in loader:
            cont = cont.to(DEVICE)
            cat = cat.to(DEVICE) if cat is not None else None
            logits = model(cont, cat)
            p = logits.argmax(dim=1).cpu().numpy()
            preds.append(p)
            ys.append(y.numpy())
    y_true = np.concatenate(ys)
    y_pred = np.concatenate(preds)
    acc = accuracy_score(y_true, y_pred)
    return acc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv', default='/Users/nikitha21sree/Biology/Project/Dataset/Bio_5_f_severity.csv')
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--batch', type=int, default=256)
    parser.add_argument('--embed_dim', type=int, default=32)
    parser.add_argument('--n_heads', type=int, default=1)
    parser.add_argument('--n_layers', type=int, default=1)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--weight_decay', type=float, default=1e-5)
    parser.add_argument('--optuna', action='store_true')
    parser.add_argument('--out', default='/Users/nikitha21sree/Biology/Project/Outputs/bio13', help='output directory for metrics and plots')
    args = parser.parse_args()

    data_path = Path(args.csv)
    if not data_path.exists():
        print('CSV not found at', data_path)
        return
    X_cont, X_cat, y, cont_cols, cat_cols, cat_cardinals = load_and_preprocess(str(data_path))
    X_train, X_temp, y_train, y_temp = train_test_split(X_cont, y, stratify=y, test_size=0.3, random_state=42)
    if X_cat is not None:
        Xc_train, Xc_temp = train_test_split(X_cat, stratify=y, test_size=0.3, random_state=42)
    else:
        Xc_train = Xc_temp = None
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, stratify=y_temp, test_size=0.5, random_state=42)
    if X_cat is not None:
        Xc_val, Xc_test = train_test_split(Xc_temp, stratify=y_temp, test_size=0.5, random_state=42)
    else:
        Xc_val = Xc_test = None
    # keep a copy of raw test continuous features for SHAP
    X_test_cont = X_test.copy()

    train_ds = TabularDataset(X_train, Xc_train if Xc_train is not None else None, y_train)
    val_ds = TabularDataset(X_val, Xc_val if Xc_val is not None else None, y_val)
    test_ds = TabularDataset(X_test, Xc_test if Xc_test is not None else None, y_test)

    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=args.batch, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=args.batch, shuffle=False, num_workers=0)

    model = FTLikeTransformer(n_cont=len(cont_cols), cat_cardinals=cat_cardinals, embed_dim=args.embed_dim, n_heads=args.n_heads, n_layers=args.n_layers).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    loss_fn = FocalLoss(gamma=2.0)

    print('Device:', DEVICE)
    print('Train size:', len(train_ds), 'Val size:', len(val_ds), 'Test size:', len(test_ds))

    history = {'train_loss': [], 'val_loss': [], 'val_acc': []}
    for epoch in range(1, args.epochs+1):
        tr_loss = train_one_epoch(model, train_loader, opt, loss_fn)
        # compute val loss and acc
        model.eval()
        val_losses = []
        yv_true, yv_pred = [], []
        with torch.no_grad():
            for cont, cat, yb in val_loader:
                cont = cont.to(DEVICE)
                cat = cat.to(DEVICE) if cat is not None else None
                yb = yb.to(DEVICE)
                logits = model(cont, cat)
                loss_val = loss_fn(logits, yb)
                val_losses.append(loss_val.item())
                preds = logits.argmax(dim=1)
                yv_true.extend(yb.cpu().numpy())
                yv_pred.extend(preds.cpu().numpy())
        val_loss = float(np.mean(val_losses)) if val_losses else 0.0
        val_acc = float(accuracy_score(yv_true, yv_pred)) if yv_true else 0.0
        history['train_loss'].append(tr_loss)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)
        print(f'Epoch {epoch}/{args.epochs}  train_loss={tr_loss:.4f}  val_loss={val_loss:.4f}  val_acc={val_acc:.4f}')

    # evaluation and metrics
    model.eval()
    y_true, y_pred, y_prob = [], [], []
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    with torch.no_grad():
        for cont, cat, yb in test_loader:
            cont = cont.to(DEVICE)
            cat = cat.to(DEVICE) if cat is not None else None
            logits = model(cont, cat)
            probs = torch.softmax(logits, dim=1).cpu().numpy()
            preds = probs.argmax(axis=1)
            y_true.extend(yb.numpy().tolist())
            y_pred.extend(preds.tolist())
            y_prob.extend(probs.tolist())
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    y_prob = np.array(y_prob)
    metrics = {}
    metrics['accuracy'] = float(accuracy_score(y_true, y_pred))
    metrics['precision_macro'] = float(precision_score(y_true, y_pred, average='macro', zero_division=0))
    metrics['recall_macro'] = float(recall_score(y_true, y_pred, average='macro', zero_division=0))
    metrics['f1_macro'] = float(f1_score(y_true, y_pred, average='macro', zero_division=0))
    
    auc = roc_auc_score(pd.get_dummies(y_true), y_prob, average='macro', multi_class='ovr')

    metrics['roc_auc_macro'] = float(auc) if auc is not None else None
    cm = confusion_matrix(y_true, y_pred).tolist()
    metrics['confusion_matrix'] = cm
    # Save outputs
    # metrics already using out_dir defined above
    with open(out_dir / 'metrics.json', 'w') as f:
        json.dump(metrics, f, indent=2)
    print(f"\nTest ROC AUC (macro): {metrics['roc_auc_macro']}")
    print("Confusion matrix:\n", np.array(metrics['confusion_matrix']))
    print(f"Accuracy: {metrics['accuracy']:.4f}  Precision: {metrics['precision_macro']:.4f}  Recall: {metrics['recall_macro']:.4f}  F1: {metrics['f1_macro']:.4f}")
    print("Classification report:\n", classification_report(y_true, y_pred))
    # ROC and confusion plots
    
    from sklearn.metrics import roc_curve
    plt.figure(figsize=(8,6))
    # binarize once
    y_true_bin = pd.get_dummies(y_true).values
    for i in range(y_prob.shape[1]):
        fpr, tpr, _ = roc_curve(y_true_bin[:, i], y_prob[:, i])
        plt.plot(fpr, tpr, label=f"cls{i}")
    plt.plot([0,1],[0,1],'--',color='gray')
    plt.xlabel('FPR'); plt.ylabel('TPR'); plt.title('ROC curves'); plt.legend(); plt.tight_layout()
    plt.savefig(out_dir / 'roc.png', dpi=200); plt.close()


    cm_arr = np.array(cm)
    plt.figure(figsize=(6,6))
    plt.imshow(cm_arr, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion matrix'); plt.colorbar()
    ticks = np.arange(cm_arr.shape[0])
    plt.xticks(ticks, ticks, rotation=45, ha='right'); plt.yticks(ticks, ticks)
    thresh = cm_arr.max()/2.0
    for i in range(cm_arr.shape[0]):
        for j in range(cm_arr.shape[1]):
            plt.text(j,i,format(cm_arr[i,j],'d'),ha='center',va='center',color='white' if cm_arr[i,j]>thresh else 'black')
    plt.ylabel('True'); plt.xlabel('Predicted'); plt.tight_layout(); plt.savefig(out_dir / 'confusion.png', dpi=200); plt.close()
    # loss curve
    plt.figure(figsize=(6,4))
    plt.plot(history['train_loss'], label='train'); plt.plot(history['val_loss'], label='val')
    plt.xlabel('Epoch'); plt.ylabel('Loss'); plt.legend(); plt.tight_layout();
    plt.savefig(out_dir / 'loss.png', dpi=200); plt.close()
    # save model
    torch.save(model.state_dict(), out_dir / 'model.pt')
    # shap
    try:
        import shap
        import warnings
        warnings.filterwarnings('ignore')
        sample_size = min(100, len(y_true))
        sample_idx = np.random.choice(len(y_true), sample_size, replace=False)
        # use continuous test features preserved earlier
        X_test_arr = X_test_cont if 'X_test_cont' in locals() else None
        if X_test_arr is not None:
            X_sample = X_test_arr[sample_idx]
            def model_predict(x):
                with torch.no_grad():
                    x_t = torch.from_numpy(x).float().to(DEVICE)
                    logits = model(x_t, None)
                    probs = torch.softmax(logits, dim=1)
                return probs.cpu().numpy()
            explainer = shap.KernelExplainer(model_predict, X_test_arr[:50])
            shap_values = explainer.shap_values(X_sample)
            feature_names = [f"feat{i}" for i in range(X_test_arr.shape[1])]
            plt.figure(figsize=(10,6))
            if isinstance(shap_values,list) and len(shap_values)>0:
                shap.summary_plot(shap_values[0], X_sample, feature_names=feature_names, show=False)
            else:
                shap.summary_plot(shap_values, X_sample, feature_names=feature_names, show=False)
            plt.title("SHAP Feature Importance")
            plt.tight_layout()
            plt.savefig(out_dir / 'shap_summary.png', dpi=200, bbox_inches='tight')
            plt.close()
    except Exception as e:
        print(f"SHAP skipped: {e}")
    # done
    print('Metrics saved to', out_dir / 'metrics.json')

if __name__ == '__main__':
    main()
