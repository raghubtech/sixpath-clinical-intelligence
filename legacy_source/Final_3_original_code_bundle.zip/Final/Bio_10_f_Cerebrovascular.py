#!/usr/bin/env python3
"""Bio_10_f_Cerebrovascular.py

Classify diabetic patients for cerebrovascular disease risk into four balanced classes
(NONE, MILD, MODERATE, SEVERE) using TOTAL_CHOLESTEROL, HS_CRP, DIABETES_DURATION_YEARS, SR_SODIUM, STRESS_LEVEL.

Score Points: Mild=10, Moderate=20, Severe=35
Produces: Dataset/Bio_f_Cerebrovascular.csv

Multi-disease note:
- TOTAL_CHOLESTEROL overlaps with cardiovascular disease
- HS_CRP is systemic inflammation marker (shared across multiple complications)
- SR_SODIUM/electrolyte balance affects cerebral perfusion
- STRESS_LEVEL psychosocial risk factor for stroke in diabetics
"""
import os
import sys
import pandas as pd
import numpy as np


INPUT_PATH = os.path.join('Dataset', 'Bio_3_f_Diabetic.csv')
OUTPUT_PATH = os.path.join('Dataset', 'Bio_11_f_Cerebrovascular.csv')


def get_tc_score(tc):
    """Total Cholesterol scoring (cerebrovascular risk)."""
    try:
        tc = float(tc)
    except (ValueError, TypeError):
        return 0
    if tc < 200:
        return 0  # Low risk
    if 200 <= tc < 240:
        return 1  # Moderate
    if 240 <= tc < 300:
        return 2  # High
    return 3  # Very High (>=300)


def get_crp_score(crp):
    """HS_CRP scoring (inflammatory marker)."""
    try:
        crp = float(crp)
    except (ValueError, TypeError):
        return 0
    if crp < 3.0:
        return 0  # Low
    if 3.0 <= crp <= 10:
        return 1  # Moderate
    if 10 < crp <= 20:
        return 2  # High
    return 3  # Very High (>20)


def get_duration_score(years):
    """Diabetes duration scoring (longer = higher stroke risk)."""
    try:
        years = float(years)
    except (ValueError, TypeError):
        return 0
    if years < 5:
        return 0  # Low risk
    if 5 <= years <= 10:
        return 1  # Moderate
    if 10 < years <= 20:
        return 2  # High
    return 3  # Very High (>20)


def get_sodium_score(na):
    """Sodium electrolyte balance scoring (abnormal = vascular risk)."""
    try:
        na = float(na)
    except (ValueError, TypeError):
        return 0
    if 136 <= na <= 145:
        return 0  # Normal
    if (130 <= na < 136) or (145 < na <= 150):
        return 1  # Borderline
    if (125 <= na < 130) or (150 < na <= 155):
        return 2  # Abnormal
    return 3  # Severe (<125 or >155)


def get_stress_score(stress):
    """Stress level scoring (0-10 scale; higher = more risk)."""
    try:
        stress = float(stress)
    except (ValueError, TypeError):
        return 0
    if stress <= 4:
        return 0  # Low
    if 5 <= stress <= 7:
        return 1  # Moderate
    if 8 <= stress <= 9:
        return 2  # High
    return 3  # Very High (=10)


def compute_cbv_score(row):
    """Composite cerebrovascular risk score."""
    tc_score = get_tc_score(row.get('TOTAL_CHOLESTEROL', 0))
    crp_score = get_crp_score(row.get('HS_CRP', 0))
    duration_score = get_duration_score(row.get('DIABETES_DURATION_YEARS', 0))
    sodium_score = get_sodium_score(row.get('SR_SODIUM', 0))
    stress_score = get_stress_score(row.get('STRESS_LEVEL', 0))
    
    # Weighted composite
    composite = (tc_score * 0.25 + crp_score * 0.25 + duration_score * 0.25 +
                 sodium_score * 0.15 + stress_score * 0.10)
    return composite


from dataset_utils import assign_balanced_severity as _assign

def assign_balanced_severity(df, score_col='CBV_SCORE'):
    label_order = ['NONE', 'SEVERE', 'MILD', 'MODERATE']
    return _assign(df, score_col, label_order)


def main():
    if not os.path.exists(INPUT_PATH):
        print(f"Input file not found: {INPUT_PATH}")
        sys.exit(1)

    print(f"Loading diabetic dataset from: {INPUT_PATH}")
    df = pd.read_csv(INPUT_PATH)
    print(f"Loaded: {df.shape[0]} rows × {df.shape[1]} columns\n")

    # Ensure required numeric columns exist and are cleaned
    from dataset_utils import ensure_numeric_cols
    # provide sensible defaults for some
    df['SR_SODIUM'] = df.get('SR_SODIUM', 140)
    df['STRESS_LEVEL'] = df.get('STRESS_LEVEL', 5)
    required = ['TOTAL_CHOLESTEROL', 'HS_CRP', 'DIABETES_DURATION_YEARS', 'SR_SODIUM', 'STRESS_LEVEL']
    df = ensure_numeric_cols(df, required, fill_strategy='median', default=0)

    # Compute composite score
    df['CBV_SCORE'] = df.apply(compute_cbv_score, axis=1)

    print("Computing composite cerebrovascular risk score...")
    print(f"Computed score range: {df['CBV_SCORE'].min():.2f} - {df['CBV_SCORE'].max():.2f}\n")

    # Assign balanced severity
    df['CEREBROVASCULAR_SEVERITY'] = assign_balanced_severity(df, score_col='CBV_SCORE')

    dist = df['CEREBROVASCULAR_SEVERITY'].value_counts().reindex(
        ['NONE', 'SEVERE', 'MILD', 'MODERATE']).fillna(0).astype(int)
    print('Severity distribution after balanced assignment:')
    for lvl in ['NONE', 'SEVERE', 'MILD', 'MODERATE']:
        print(f"  {lvl:<8}: {dist[lvl]:,} patients")

    # Summary stats
    print('\nCerebrovascular Summary by Severity:\n')
    for lvl in ['SEVERE', 'MODERATE', 'MILD', 'NONE']:
        level_data = df[df['CEREBROVASCULAR_SEVERITY'] == lvl]
        avg_tc = level_data['TOTAL_CHOLESTEROL'].mean()
        avg_crp = level_data['HS_CRP'].mean()
        avg_duration = level_data['DIABETES_DURATION_YEARS'].mean()
        print(f"{lvl}: count={len(level_data):,}")
        print(f"  Avg Total Cholesterol: {avg_tc:.2f} mg/dL")
        print(f"  Avg HS_CRP: {avg_crp:.2f} mg/L")
        print(f"  Avg Duration: {avg_duration:.2f} years\n")

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"✓ Saved cerebrovascular-classified dataset to: {OUTPUT_PATH}")


if __name__ == '__main__':
    main()
