"""Train a small Tab-Transformer-like model for DIABETIC_STATUS.
Defaults use Dataset/Bio_2_f_Data_Classified.csv and save outputs to Outputs/bio11.
Quick test defaults: 2 epochs, SHAP disabled. Use --shap to enable SHAP (slow).
"""
import argparse
import os
import random
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
# disable torch compile/dynamo to avoid heavy import-time overhead on macOS
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')
import torch
import torch.nn as nn
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support, roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class TabTransformer(nn.Module):
    def __init__(self, n_cat, n_cont, cat_cardinalities, d_model=64, n_heads=4, n_layers=2, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        # Embeddings per categorical feature
        self.cat_embs = nn.ModuleList()
        self.cat_dims = []
        for c in cat_cardinalities:
            emb_size = min(50, max(4, (c + 1) // 2))
            self.cat_embs.append(nn.Embedding(c + 1, emb_size))
            self.cat_dims.append(emb_size)

        # Project continuous features to d_model
        self.cont_proj = nn.Linear(n_cont, d_model) if n_cont > 0 else None

        # Project concatenated embeddings to d_model
        tot_emb = sum(self.cat_dims) + (d_model if n_cont > 0 else 0)
        self.feat_proj = nn.Linear(tot_emb, d_model)

        encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=n_heads, dropout=dropout)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.classifier = nn.Sequential(nn.Linear(d_model, d_model // 2), nn.ReLU(), nn.Dropout(dropout), nn.Linear(d_model // 2, 1))

    def forward(self, x_cats, x_cont):
        emb_list = []
        for i, emb in enumerate(self.cat_embs):
            idx = x_cats[:, i].long()
            emb_list.append(emb(idx))
        if x_cont is not None and self.cont_proj is not None:
            cont_proj = self.cont_proj(x_cont.float())
            emb_list.append(cont_proj.unsqueeze(1))

        if len(emb_list) == 0:
            raise ValueError("No features provided to model")

        # flatten and project
        concat = torch.cat([e.reshape(e.size(0), -1) for e in emb_list], dim=1)
        x = self.feat_proj(concat)  # (B, d_model)
        x = x.unsqueeze(0)  # (seq_len=1, B, d_model)
        out = self.transformer(x)  # (1, B, d_model)
        pooled = out.mean(dim=0)
        logits = self.classifier(pooled).squeeze(1)
        return logits


def load_and_prepare(path, target_col="DIABETIC_STATUS"):
    df = pd.read_csv(path)
    df = df.copy()
    if 'PATIENT_ID' in df.columns:
        df = df.drop(columns=['PATIENT_ID'])

    df[target_col] = df[target_col].astype(int)

    potential_cat = []
    for c in df.columns:
        if c == target_col:
            continue
        if df[c].dtype == object:
            potential_cat.append(c)
        elif pd.api.types.is_integer_dtype(df[c]) and df[c].nunique() <= 20:
            potential_cat.append(c)

    cont_cols = [c for c in df.columns if c not in potential_cat + [target_col]]

    for c in cont_cols:
        df[c] = df[c].fillna(df[c].median())
    for c in potential_cat:
        df[c] = df[c].fillna("__NA__").astype(str)

    cat_maps = {}
    cat_cardinalities = []
    for c in potential_cat:
        cats = sorted(df[c].unique())
        mapping = {v: i + 1 for i, v in enumerate(cats)}
        cat_maps[c] = mapping
        df[c] = df[c].map(mapping).fillna(0).astype(int)
        cat_cardinalities.append(len(cats))

    scaler = StandardScaler()
    if len(cont_cols) > 0:
        df[cont_cols] = scaler.fit_transform(df[cont_cols])

    X_cats = df[potential_cat].values.astype(int) if len(potential_cat) > 0 else np.zeros((len(df), 0), dtype=int)
    X_cont = df[cont_cols].values.astype(float) if len(cont_cols) > 0 else None
    y = df[target_col].values.astype(int)

    meta = {
        'cat_cols': potential_cat,
        'cont_cols': cont_cols,
        'cat_maps': cat_maps,
        'scaler': scaler,
        'cat_cardinalities': cat_cardinalities
    }
    return X_cats, X_cont, y, meta


def train(args):
    seed_everything()
    os.makedirs(args.save_dir, exist_ok=True)

    X_cats, X_cont, y, meta = load_and_prepare(args.input)

    # Create ONLY train/test split (NO VALIDATION to prevent data leakage)
    test_size = getattr(args, 'test_size', 0.2)
    Xc_train, Xc_test, Xn_train, Xn_test, y_train, y_test = train_test_split(
        X_cats, X_cont, y, test_size=test_size, random_state=42, stratify=y)

    # Choose device
    if args.device == 'cuda' and torch.cuda.is_available():
        device = torch.device('cuda')
    elif args.device == 'mps' and getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
        device = torch.device('mps')
    else:
        device = torch.device('cpu')

    model = TabTransformer(
        n_cat=len(meta['cat_cols']),
        n_cont=len(meta['cont_cols']),
        cat_cardinalities=meta['cat_cardinalities'],
        d_model=args.d_model,
        n_heads=getattr(args, 'n_heads', 4),
        n_layers=getattr(args, 'n_layers', 2),
        dropout=getattr(args, 'dropout', 0.1)
    )
    model.to(device)

    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=getattr(args, 'weight_decay', 1e-4))
    criterion = nn.BCEWithLogitsLoss()

    batch_size = args.batch_size

    def batch_iter(Xc, Xn, y, bs):
        n = len(y)
        idx = np.arange(n)
        np.random.shuffle(idx)
        for i in range(0, n, bs):
            batch = idx[i:i+bs]
            Xc_b = torch.tensor(Xc[batch], dtype=torch.long, device=device)
            Xn_b = torch.tensor(Xn[batch].astype(np.float32), dtype=torch.float32, device=device) if Xn is not None else None
            y_b = torch.tensor(y[batch].astype(np.float32), dtype=torch.float32, device=device)
            yield Xc_b, Xn_b, y_b

    def evaluate(Xc, Xn, y_true):
        model.eval()
        losses = []
        probs_list = []
        with torch.no_grad():
            n = len(y_true)
            for i in range(0, n, batch_size):
                b = slice(i, i+batch_size)
                Xc_b = torch.tensor(Xc[b], dtype=torch.long, device=device)
                Xn_b = torch.tensor(Xn[b].astype(np.float32), dtype=torch.float32, device=device) if Xn is not None else None
                y_b = torch.tensor(y_true[b].astype(np.float32), dtype=torch.float32, device=device)
                logits = model(Xc_b, Xn_b)
                loss = criterion(logits, y_b)
                losses.append(loss.item() * len(y_b))
                probs = torch.sigmoid(logits).cpu().numpy()
                probs_list.append(probs)
        if len(probs_list) == 0:
            return None, None, None
        probs_all = np.concatenate(probs_list)
        loss_all = sum(losses) / len(y_true)
        preds_all = (probs_all >= 0.5).astype(int)
        try:
            auc = float(roc_auc_score(y_true, probs_all))
        except Exception:
            auc = float('nan')
        acc = float(accuracy_score(y_true, preds_all))
        return loss_all, auc, acc

    # training loop (NO VALIDATION - prevents data leakage)
    train_losses = []

    for epoch in range(args.epochs):
        model.train()
        total_loss = 0.0
        n_seen = 0
        for Xc_b, Xn_b, y_b in batch_iter(Xc_train, Xn_train, y_train, batch_size):
            opt.zero_grad()
            logits = model(Xc_b, Xn_b)
            loss = criterion(logits, y_b)
            loss.backward()
            opt.step()
            total_loss += loss.item() * Xc_b.size(0)
            n_seen += Xc_b.size(0)
        train_loss = total_loss / len(y_train)
        train_losses.append(train_loss)
        print(f"Epoch {epoch+1}/{args.epochs} train_loss={train_loss:.4f}")

    # final evaluation on test set
    _, test_auc, test_acc = evaluate(Xc_test, Xn_test, y_test)
    # compute final probs and confusion matrix for saving
    model.eval()
    with torch.no_grad():
        Xc_t = torch.tensor(Xc_test, dtype=torch.long, device=device)
        Xn_t = torch.tensor(Xn_test.astype(np.float32), dtype=torch.float32, device=device) if Xn_test is not None else None
        logits = model(Xc_t, Xn_t).cpu().numpy()
        probs = 1 / (1 + np.exp(-logits))

    try:
        roc_auc = float(roc_auc_score(y_test, probs))
    except Exception as e:
        print(f"Warning: Could not compute ROC AUC: {e}")
        roc_auc = float('nan')
    
    fpr, tpr, _ = roc_curve(y_test, probs)
    print(f"Test ROC AUC: {roc_auc:.4f}")

    # save ROC plot with improved formatting
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.plot(fpr, tpr, linewidth=2.5, label=f'ROC AUC={roc_auc:.4f}', color='#1f77b4')
    ax.plot([0, 1], [0, 1], linestyle='--', color='gray', alpha=0.5, linewidth=2, label='Random Classifier')
    ax.set_xlabel('False Positive Rate', fontsize=12, fontweight='bold')
    ax.set_ylabel('True Positive Rate', fontsize=12, fontweight='bold')
    ax.set_title('ROC Curve - Diabetic Status Detection', fontsize=14, fontweight='bold')
    ax.legend(fontsize=11, loc='lower right')
    ax.grid(True, alpha=0.3)
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    plt.savefig(os.path.join(args.save_dir, 'roc_bio11.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)

    preds = (probs >= 0.5).astype(int)
    cm = confusion_matrix(y_test, preds, labels=[0,1]) if len(np.unique(y_test))>1 else confusion_matrix(y_test, preds)
    acc = accuracy_score(y_test, preds)
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, preds, average='binary', zero_division=0)
    print('Confusion matrix:\n', cm)
    print(f"Accuracy: {acc:.4f}  Precision: {prec:.4f}  Recall: {rec:.4f}  F1: {f1:.4f}")
    print('Classification report:\n', classification_report(y_test, preds, zero_division=0))

    # save confusion matrix with visible numbers
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(cm, cmap='Blues', aspect='auto')
    plt.colorbar(im, ax=ax, label='Count')
    
    # Add text annotations (confusion matrix values)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            text = ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                          color="white" if cm[i, j] > cm.max() / 2 else "black",
                          fontsize=16, fontweight='bold')
    
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Negative (0)', 'Positive (1)'], fontsize=11)
    ax.set_yticklabels(['Negative (0)', 'Positive (1)'], fontsize=11)
    ax.set_xlabel('Predicted Label', fontsize=12, fontweight='bold')
    ax.set_ylabel('True Label', fontsize=12, fontweight='bold')
    ax.set_title('Confusion Matrix - Diabetic Status Detection', fontsize=14, fontweight='bold')
    plt.savefig(os.path.join(args.save_dir, 'cm_bio11.png'), dpi=300, bbox_inches='tight')
    plt.close()
    torch.save(model.state_dict(), os.path.join(args.save_dir, 'bio11_model.pt'))
    metrics = {
        'roc_auc': roc_auc if not np.isnan(roc_auc) else None,
        'accuracy': float(acc),
        'precision': float(prec),
        'recall': float(rec),
        'f1': float(f1),
        'confusion_matrix': cm.tolist()
    }
    import json
    with open(os.path.join(args.save_dir, 'metrics_bio11.json'), 'w') as fh:
        json.dump(metrics, fh, indent=2)

    # save training loss curve
    if len(train_losses) > 0:
        fig, ax = plt.subplots(figsize=(10, 6))
        epochs_range = range(1, len(train_losses) + 1)
        ax.plot(epochs_range, train_losses, 'o-', linewidth=2.5, markersize=6, label='Training Loss', color='#1f77b4')
        ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
        ax.set_ylabel('Loss (Binary Crossentropy)', fontsize=12, fontweight='bold')
        ax.set_title('Training Loss Curve', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(args.save_dir, 'loss_curve_bio11.png'), dpi=300, bbox_inches='tight')
        plt.close(fig)

    # optional SHAP (slow)
    if args.shap:
        try:
            import shap
        except Exception:
            print('SHAP not installed; skipping SHAP step.')
            return
        # build background and test samples
        background_idx = np.random.choice(len(Xc_train), size=min(50, len(Xc_train)), replace=False)
        X_bg = np.hstack([Xc_train[background_idx], Xn_train[background_idx] if Xn_train is not None else np.zeros((len(background_idx), 0))])
        test_idx = np.random.choice(len(Xc_test), size=min(100, len(Xc_test)), replace=False)
        X_test_sample = np.hstack([Xc_test[test_idx], Xn_test[test_idx] if Xn_test is not None else np.zeros((len(test_idx), 0))])

        def model_wrapper(x_array):
            if x_array.ndim == 1:
                x_array = x_array.reshape(1, -1)
            Xc_part = x_array[:, :X_cats.shape[1]].astype(int)
            Xn_part = x_array[:, X_cats.shape[1]:].astype(float) if Xn_train is not None else None
            with torch.no_grad():
                Xc_t = torch.tensor(Xc_part, dtype=torch.long, device=device)
                Xn_t = torch.tensor(Xn_part.astype(np.float32), dtype=torch.float32, device=device) if Xn_part is not None else None
                logits = model(Xc_t, Xn_t).cpu().numpy()
            probs = 1 / (1 + np.exp(-logits))
            return probs.flatten()

        explainer = shap.KernelExplainer(model_wrapper, X_bg)
        shap_values = explainer.shap_values(X_test_sample, nsamples=200)
        shap.summary_plot(shap_values, X_test_sample, show=False)
        plt.savefig(os.path.join(args.save_dir, 'shap_bio11.png'))
        plt.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default='/Users/nikitha21sree/Biology/Project/Dataset/Bio_2_f_Data_Classified.csv')
    parser.add_argument('--save-dir', default='Outputs/bio11')
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--device', default='cpu')
    parser.add_argument('--d-model', dest='d_model', type=int, default=64)
    parser.add_argument('--shap', action='store_true')
    parser.add_argument('--weight-decay', dest='weight_decay', type=float, default=1e-4)
    parser.add_argument('--dropout', type=float, default=0.3)
    parser.add_argument('--n-layers', dest='n_layers', type=int, default=4)
    parser.add_argument('--n-heads', dest='n_heads', type=int, default=8)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--noise', type=float, default=0.4, help='Stddev of Gaussian noise to add to continuous features')
    parser.add_argument('--test-size', dest='test_size', type=float, default=0.2, help='Test set fraction')
    args = parser.parse_args()
    train(args)
