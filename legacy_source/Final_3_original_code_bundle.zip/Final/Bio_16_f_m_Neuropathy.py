#!/usr/bin/env python3
"""Train an MLP on Bio_7_f_Neuropathy.csv and save ROC, confusion matrix, loss curve, and metrics JSON.
Uses split-before-fit preprocessing (no leakage). Multi-class support with macro AUC.
"""
import os
import json
import argparse

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    roc_auc_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False


def load_and_preprocess(path, label_col="NEUROPATHY_SEVERITY", test_size=0.2, val_size=0.1, seed=42):
    df = pd.read_csv(path)
    
    # Remove duplicate patients (keep first occurrence)
    if "PATIENT_ID" in df.columns:
        dup_count = df.duplicated(subset=["PATIENT_ID"]).sum()
        if dup_count > 0:
            print(f"Removing {dup_count} duplicate patient records", flush=True)
        df = df.drop_duplicates(subset=["PATIENT_ID"], keep='first')
        df = df.drop(columns=["PATIENT_ID"])

    stratify = df[label_col] if label_col in df.columns else None
    train_val, test = train_test_split(df, test_size=test_size, random_state=seed, stratify=stratify)
    stratify_tv = train_val[label_col] if label_col in df.columns else None
    train, val = train_test_split(train_val, test_size=val_size / (1 - test_size), random_state=seed, stratify=stratify_tv)

    y_train = train[label_col].values
    y_val = val[label_col].values
    y_test = test[label_col].values
    X_train = train.drop(columns=[label_col])
    X_val = val.drop(columns=[label_col])
    X_test = test.drop(columns=[label_col])

    num_cols = X_train.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = [c for c in X_train.columns if c not in num_cols]

    num_medians = X_train[num_cols].median()
    X_train[num_cols] = X_train[num_cols].fillna(num_medians)
    X_val[num_cols] = X_val[num_cols].fillna(num_medians)
    X_test[num_cols] = X_test[num_cols].fillna(num_medians)

    scaler = StandardScaler()
    X_train_num = scaler.fit_transform(X_train[num_cols]) if num_cols else np.zeros((len(X_train), 0))
    X_val_num = scaler.transform(X_val[num_cols]) if num_cols else np.zeros((len(X_val), 0))
    X_test_num = scaler.transform(X_test[num_cols]) if num_cols else np.zeros((len(X_test), 0))

    X_train_cat = pd.get_dummies(X_train[cat_cols].astype(str), dummy_na=True)
    train_cat_cols = X_train_cat.columns.tolist()
    X_val_cat = pd.get_dummies(X_val[cat_cols].astype(str), dummy_na=True).reindex(columns=train_cat_cols, fill_value=0)
    X_test_cat = pd.get_dummies(X_test[cat_cols].astype(str), dummy_na=True).reindex(columns=train_cat_cols, fill_value=0)

    X_train_final = np.hstack([X_train_num, X_train_cat.values]) if X_train_cat.shape[1] or num_cols else np.zeros((len(X_train), 0))
    X_val_final = np.hstack([X_val_num, X_val_cat.values]) if X_val_cat.shape[1] or num_cols else np.zeros((len(X_val), 0))
    X_test_final = np.hstack([X_test_num, X_test_cat.values]) if X_test_cat.shape[1] or num_cols else np.zeros((len(X_test), 0))

    le = LabelEncoder()
    y_train_enc = le.fit_transform(y_train)
    y_val_enc = le.transform(y_val)
    y_test_enc = le.transform(y_test)

    # Build feature names for SHAP
    feature_names = list(num_cols) + train_cat_cols

    meta = {
        "num_cols": num_cols,
        "cat_cols": cat_cols,
        "train_cat_columns": train_cat_cols,
        "label_classes": le.classes_.tolist(),
        "feature_names": feature_names,
    }

    return (X_train_final, X_val_final, X_test_final, y_train_enc, y_val_enc, y_test_enc, meta, scaler)


class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dims=(256, 128), dropout=0.2, n_classes=2):
        super().__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev = h
        layers.append(nn.Linear(prev, n_classes))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def train_and_evaluate(X_train, X_val, X_test, y_train, y_val, y_test, meta, out_prefix, device=None, epochs=50, batch_size=256, seed=42):
    if device is None:
        device = torch.device("mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu"))

    torch.manual_seed(seed)
    input_dim = X_train.shape[1]
    n_classes = len(meta["label_classes"]) if isinstance(meta, dict) else int(np.max(y_train) + 1)
    
    # Create output directory
    out_dir = out_prefix
    os.makedirs(out_dir, exist_ok=True)

    # Print class counts
    unique_train, counts_train = np.unique(y_train, return_counts=True)
    print(f"Train class counts: {dict(zip([meta['label_classes'][i] for i in unique_train], counts_train))}", flush=True)

    model = MLP(input_dim, hidden_dims=(32, 128), dropout=0.1, n_classes=n_classes).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-2)
    
    # Class-weighted loss
    class_weights = torch.from_numpy(np.array([1.0 / counts_train[i] if i in unique_train else 1.0 for i in range(n_classes)])).float()
    class_weights = class_weights / class_weights.sum() * n_classes
    class_weights = class_weights.to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights)

    train_ds = TensorDataset(torch.from_numpy(X_train).float(), torch.from_numpy(y_train).long())
    val_ds = TensorDataset(torch.from_numpy(X_val).float(), torch.from_numpy(y_val).long())
    test_ds = TensorDataset(torch.from_numpy(X_test).float(), torch.from_numpy(y_test).long())

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    # OneCycleLR scheduler
    total_steps = epochs * len(train_loader)
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=5e-3, total_steps=total_steps)

    best_val_loss = float('inf')
    best_state = None
    history = {"train_loss": [], "val_loss": []}
    patience = 30
    wait = 0

    # Print training setup
    print(f"Training on device: {device}", flush=True)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Model params: {total_params}, epochs={epochs}, batch_size={batch_size}", flush=True)

    for epoch in range(1, epochs + 1):
        model.train()
        running = 0.0
        n = 0
        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            logits = model(xb)
            loss = criterion(logits, yb)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            running += loss.item() * xb.size(0)
            n += xb.size(0)
        train_loss = running / n

        model.eval()
        running = 0.0
        n = 0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb = xb.to(device)
                yb = yb.to(device)
                logits = model(xb)
                loss = criterion(logits, yb)
                running += loss.item() * xb.size(0)
                n += xb.size(0)
        val_loss = running / n

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        print(f"Epoch {epoch}/{epochs} - train_loss: {train_loss:.6f} val_loss: {val_loss:.6f}", flush=True)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                break

    # Load best
    if best_state is not None:
        model.load_state_dict(best_state)

    # Test metrics
    model.eval()
    y_true = []
    y_prob = []
    y_pred = []
    with torch.no_grad():
        for xb, yb in test_loader:
            xb = xb.to(device)
            logits = model(xb)
            probs = torch.softmax(logits, dim=1).cpu().numpy()
            preds = probs.argmax(axis=1)
            y_true.extend(yb.numpy().tolist())
            y_prob.extend(probs.tolist())
            y_pred.extend(preds.tolist())

    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    y_prob = np.array(y_prob)

    # Print detailed test metrics
    print("\nTest Metrics:", flush=True)
    metrics = {}
    metrics["accuracy"] = float(accuracy_score(y_true, y_pred))
    metrics["precision_macro"] = float(precision_score(y_true, y_pred, average='macro', zero_division=0))
    metrics["recall_macro"] = float(recall_score(y_true, y_pred, average='macro', zero_division=0))
    metrics["f1_macro"] = float(f1_score(y_true, y_pred, average='macro', zero_division=0))

    # AUC (macro, one-vs-rest). Requires binarized y_true
    try:
        auc = roc_auc_score(pd.get_dummies(y_true), y_prob, average='macro', multi_class='ovr')
    except Exception:
        auc = None
    
    print(f"Test ROC AUC (macro): {auc}", flush=True)
    print(f"Confusion matrix:\n {confusion_matrix(y_true, y_pred)}", flush=True)
    print(f"Accuracy: {metrics['accuracy']:.4f}  Precision: {metrics['precision_macro']:.4f}  Recall: {metrics['recall_macro']:.4f}  F1: {metrics['f1_macro']:.4f}", flush=True)
    print("Classification report:", flush=True)
    print(classification_report(y_true, y_pred, target_names=meta['label_classes']), flush=True)
    metrics["roc_auc_macro"] = float(auc) if auc is not None else None

    cm = confusion_matrix(y_true, y_pred).tolist()
    metrics["confusion_matrix"] = cm
    metrics["classes"] = meta["label_classes"]

    # Save metrics
    with open(os.path.join(out_dir, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    # ROC plot (one curve per class)
    from sklearn.metrics import roc_curve
    # binarize true labels for ROC; convert to numpy array to avoid pandas indexing issues
    y_true_bin = pd.get_dummies(y_true).values
    plt.figure(figsize=(8, 6))
    for i, cls in enumerate(meta["label_classes"]):
        fpr, tpr, _ = roc_curve(y_true_bin[:, i], y_prob[:, i])
        plt.plot(fpr, tpr, label=f"{cls}")
    plt.plot([0, 1], [0, 1], '--', color='gray')
    plt.xlabel('FPR')
    plt.ylabel('TPR')
    plt.title('ROC curves')
    plt.legend()
    plt.tight_layout()
    roc_path = os.path.join(out_dir, "roc.png")
    plt.savefig(roc_path, dpi=200)
    plt.close()
    print(f"ROC plot saved to {roc_path}", flush=True)


    # Confusion matrix plot
    plt.figure(figsize=(6, 6))
    cm_arr = np.array(cm)
    plt.imshow(cm_arr, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion matrix')
    plt.colorbar()
    ticks = np.arange(len(meta["label_classes"]))
    plt.xticks(ticks, meta["label_classes"], rotation=45, ha='right')
    plt.yticks(ticks, meta["label_classes"])
    thresh = cm_arr.max() / 2.0
    for i in range(cm_arr.shape[0]):
        for j in range(cm_arr.shape[1]):
            plt.text(j, i, format(cm_arr[i, j], 'd'), ha='center', va='center', color='white' if cm_arr[i, j] > thresh else 'black')
    plt.ylabel('True')
    plt.xlabel('Predicted')
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "confusion.png"), dpi=200)
    plt.close()

    # Loss curve
    plt.figure(figsize=(6, 4))
    plt.plot(history['train_loss'], label='train')
    plt.plot(history['val_loss'], label='val')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "loss.png"), dpi=200)
    plt.close()

    # Save model
    torch.save(model.state_dict(), os.path.join(out_dir, "model.pt"))

    # SHAP analysis with feature names
    if SHAP_AVAILABLE:
        try:
            sample_size = min(100, X_test.shape[0])
            sample_idx = np.random.choice(X_test.shape[0], sample_size, replace=False)
            X_sample = X_test[sample_idx]
            
            def model_predict(x):
                with torch.no_grad():
                    x_t = torch.from_numpy(x).float().to(device)
                    logits = model(x_t)
                    probs = torch.softmax(logits, dim=1)
                return probs.cpu().numpy()
            
            explainer = shap.KernelExplainer(model_predict, X_test[:50])
            shap_values = explainer.shap_values(X_sample)
            
            feature_names = meta.get("feature_names", [f"Feature_{i}" for i in range(X_test.shape[1])])
            
            plt.figure(figsize=(10, 6))
            if isinstance(shap_values, list) and len(shap_values) > 0:
                shap.summary_plot(shap_values[0], X_sample, feature_names=feature_names, show=False)
            else:
                shap.summary_plot(shap_values, X_sample, feature_names=feature_names, show=False)
            plt.title("SHAP Feature Importance", fontsize=12, fontweight='bold')
            plt.tight_layout()
            plt.savefig(os.path.join(out_dir, "shap_summary.png"), dpi=200, bbox_inches='tight')
            plt.close()
            print("SHAP summary plot saved with feature names.", flush=True)
        except Exception as e:
            print(f"SHAP analysis skipped: {e}", flush=True)
    else:
        print("SHAP not installed; install via: pip install shap", flush=True)

    return metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv', default='/Users/nikitha21sree/Biology/Project/Dataset/Bio_8_f_Neuropathy.csv')
    parser.add_argument('--out', default='/Users/nikitha21sree/Biology/Project/Outputs/bio16')
    parser.add_argument('--epochs', type=int, default=50)
    args = parser.parse_args()

    X_train, X_val, X_test, y_train, y_val, y_test, meta, scaler = load_and_preprocess(args.csv, label_col='NEUROPATHY_SEVERITY')
    metrics = train_and_evaluate(X_train, X_val, X_test, y_train, y_val, y_test, meta, args.out, epochs=args.epochs)
    print('Done. Metrics saved to', os.path.join(args.out, 'metrics.json'))


if __name__ == '__main__':
    main()
