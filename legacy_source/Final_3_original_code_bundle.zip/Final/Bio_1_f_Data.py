"""
Synthetic Diabetes Multi-Organ Risk Assessment Dataset Generator (GENERALIZED)
Generates 20,000 synthetic patient records with OVERLAPPING class distributions
to prevent model overfitting and create a realistic classification task.

Key changes from original:
1. Overlapping age, BMI, glucose, lipid distributions across classes
2. Random noise added to all continuous features (realistic measurement error)
3. More realistic feature correlations (e.g., BMI→glucose, HDL→TGL)
4. Reduced class-specific signal strength (multiple borderline cases)
5. Higher variance in all measurements
"""

import numpy as np
import pandas as pd
from scipy import stats
import random
from datetime import datetime, timedelta

# Set seeds for reproducibility
np.random.seed(42)
random.seed(42)

class SyntheticDiabetesDataGeneratorGeneralized:
    """
    Generate realistic synthetic patient data with OVERLAPPING distributions
    to create a challenging (realistic) classification task.
    """
    
    def __init__(self, n_samples=20000, seed=42, overlap_factor=1.5, label_noise_fraction=0.03):
        """
        Initialize the generator.
        
        Args:
            n_samples (int): Total number of synthetic patients to generate.
            seed (int): Random seed for reproducibility.
            overlap_factor (float): Factor controlling distribution overlap.
                                   1.0 = slight overlap, 2.0+ = high overlap
            label_noise_fraction (float): Fraction of samples with diagnostic ambiguity.
                                         Simulates borderline cases (default 3%)
        """
        self.n_samples = n_samples
        self.seed = seed
        self.overlap_factor = overlap_factor
        self.label_noise_fraction = label_noise_fraction
        np.random.seed(seed)
        random.seed(seed)
        
        # Define class distribution
        self.n_non_diabetic = 10000
        self.n_type1 = 5000
        self.n_type2 = 5000
        
    def _add_realistic_noise(self, values, noise_level=0.05):
        """Add realistic measurement/biological noise to features."""
        noise = np.random.normal(0, np.std(values) * noise_level, len(values))
        return values + noise
    
    def _generate_demographics(self):
        """Generate demographic features with heavily overlapping distributions."""
        demos = {}
        
        # Patient ID
        demos['PATIENT_ID'] = [f"P{str(i).zfill(6)}" for i in range(1, self.n_samples + 1)]
        
        # Age: HEAVILY OVERLAPPING distributions (shared mean, very wide variance)
        # All classes have similar age range; differences are minimal
        age_non_diabetic = np.random.normal(48, 18, self.n_non_diabetic)
        age_type1 = np.random.normal(46, 20, self.n_type1)  # Very wide, heavily overlaps
        age_type2 = np.random.normal(50, 20, self.n_type2)  # Slightly older, heavily overlaps
        demos['AGE'] = np.concatenate([age_non_diabetic, age_type1, age_type2])
        demos['AGE'] = np.clip(demos['AGE'], 18, 85)
        
        # Gender (no class association, realistic 52F/48M ratio)
        demos['GENDER(M(1)/F(0))'] = np.random.choice([0, 1], self.n_samples, p=[0.52, 0.48])
        
        # Height (cm) - consistent across classes
        demos['HEIGHT'] = np.random.normal(165, 8, self.n_samples)
        demos['HEIGHT'] = np.clip(demos['HEIGHT'], 140, 200)
        
        # Weight: HEAVILY OVERLAPPING - this is critical
        # In reality, many healthy people are overweight and many diabetics are normal weight
        # 40-50% of all classes should have BMI 25-35 (overweight)
        weight_non_diabetic = np.random.normal(75, 18, self.n_non_diabetic)   # Much wider, higher baseline
        weight_type1 = np.random.normal(77, 20, self.n_type1)                 # Similar, minimal difference
        weight_type2 = np.random.normal(78, 19, self.n_type2)                 # Minimal difference from Type1
        demos['WEIGHT'] = np.concatenate([weight_non_diabetic, weight_type1, weight_type2])
        demos['WEIGHT'] = np.clip(demos['WEIGHT'], 40, 150)
        
        # BMI = Weight / (Height/100)^2
        demos['BMI'] = demos['WEIGHT'] / ((demos['HEIGHT'] / 100) ** 2)
        demos['BMI'] = np.clip(demos['BMI'], 16, 50)
        
        # Family History: HEAVILY OVERLAPPING probabilities
        # Many non-diabetics with family history; many diabetics without strong family history
        family_hist_non_diabetic = np.random.choice([0, 1, 2], self.n_non_diabetic, p=[0.40, 0.40, 0.20])
        family_hist_type1 = np.random.choice([0, 1, 2, 3], self.n_type1, p=[0.30, 0.40, 0.25, 0.05])
        family_hist_type2 = np.random.choice([0, 1, 2, 3], self.n_type2, p=[0.30, 0.40, 0.25, 0.05])
        demos['FAMILY_HISTORY'] = np.concatenate([family_hist_non_diabetic, family_hist_type1, family_hist_type2])
        
        return pd.DataFrame(demos)
    
    def _generate_lifestyle_factors(self):
        """Generate lifestyle-related features with heavily overlapping distributions."""
        lifestyle = {}
        
        # Smoking Status (overlapping across classes - many healthy smokers, many non-smoking diabetics)
        lifestyle['SMOKING'] = np.random.choice([0, 1, 2], self.n_samples, p=[0.50, 0.30, 0.20])
        
        # Alcohol Consumption: heavily overlapping, realistic variance
        alcohol_non_diabetic = np.random.exponential(4.0, self.n_non_diabetic)
        alcohol_type1 = np.random.exponential(3.8, self.n_type1)
        alcohol_type2 = np.random.exponential(4.2, self.n_type2)
        lifestyle['ALCOHOL_UNITS_WEEK'] = np.concatenate([alcohol_non_diabetic, alcohol_type1, alcohol_type2])
        lifestyle['ALCOHOL_UNITS_WEEK'] = np.clip(lifestyle['ALCOHOL_UNITS_WEEK'], 0, 20)
        
        # Physical Activity: Heavily OVERLAPPING (reduced class-differentiability)
        activity_non_diabetic = np.random.normal(3.2, 2.5, self.n_non_diabetic)
        activity_type1 = np.random.normal(3.0, 2.6, self.n_type1)
        activity_type2 = np.random.normal(2.9, 2.6, self.n_type2)
        lifestyle['PHYSICAL_ACTIVITY_HRS_WEEK'] = np.concatenate([activity_non_diabetic, activity_type1, activity_type2])
        lifestyle['PHYSICAL_ACTIVITY_HRS_WEEK'] = np.clip(lifestyle['PHYSICAL_ACTIVITY_HRS_WEEK'], 0, 15)
        
        # Junk Food Consumption: heavily overlapping
        junk_non_diabetic = np.random.choice([0, 1, 2, 3], self.n_non_diabetic, p=[0.25, 0.35, 0.30, 0.10])
        junk_type1 = np.random.choice([0, 1, 2, 3], self.n_type1, p=[0.23, 0.34, 0.32, 0.11])
        junk_type2 = np.random.choice([0, 1, 2, 3], self.n_type2, p=[0.22, 0.33, 0.33, 0.12])
        lifestyle['JUNK_FOOD_FREQ'] = np.concatenate([junk_non_diabetic, junk_type1, junk_type2])
        
        # Sleep Duration: heavily overlapping, realistic variance
        sleep_non_diabetic = np.random.normal(6.5, 1.5, self.n_non_diabetic)
        sleep_type1 = np.random.normal(6.2, 1.6, self.n_type1)
        sleep_type2 = np.random.normal(6.1, 1.7, self.n_type2)
        lifestyle['SLEEP_HOURS_NIGHT'] = np.concatenate([sleep_non_diabetic, sleep_type1, sleep_type2])
        lifestyle['SLEEP_HOURS_NIGHT'] = np.clip(lifestyle['SLEEP_HOURS_NIGHT'], 4, 10)
        
        # Stress Level: heavily overlapping
        stress_non_diabetic = np.random.normal(5.0, 2.5, self.n_non_diabetic)
        stress_type1 = np.random.normal(5.1, 2.6, self.n_type1)
        stress_type2 = np.random.normal(5.2, 2.6, self.n_type2)
        lifestyle['STRESS_LEVEL'] = np.concatenate([stress_non_diabetic, stress_type1, stress_type2])
        lifestyle['STRESS_LEVEL'] = np.clip(lifestyle['STRESS_LEVEL'], 0, 10)
        
        return pd.DataFrame(lifestyle)
    
    def _generate_hematology(self, df):
        """Generate Complete Blood Count (CBC) features with noise."""
        hemato = {}
        
        # Continuous features: add measurement noise
        noise_level = 0.12  # 12% noise (increased from 8%)
        
        # WBC with reduced class separation and more noise
        wbc_non_diabetic = np.random.normal(7.4, 2.1, self.n_non_diabetic)   # Wider variance
        wbc_type1 = np.random.normal(7.5, 2.2, self.n_type1)                 # Minimal difference
        wbc_type2 = np.random.normal(7.6, 2.3, self.n_type2)                 # Minimal difference
        hemato['WBC'] = np.concatenate([wbc_non_diabetic, wbc_type1, wbc_type2])
        hemato['WBC'] = self._add_realistic_noise(hemato['WBC'], noise_level)
        hemato['WBC'] = np.clip(hemato['WBC'], 3, 12)
        
        # RBC with reduced class separation
        rbc_non_diabetic = np.random.normal(4.63, 0.50, self.n_non_diabetic)
        rbc_type1 = np.random.normal(4.60, 0.52, self.n_type1)
        rbc_type2 = np.random.normal(4.58, 0.54, self.n_type2)
        hemato['RBC'] = np.concatenate([rbc_non_diabetic, rbc_type1, rbc_type2])
        hemato['RBC'] = self._add_realistic_noise(hemato['RBC'], noise_level)
        hemato['RBC'] = np.clip(hemato['RBC'], 3.5, 6.0)
        
        # Hemoglobin with reduced class separation
        hgb_non_diabetic = np.random.normal(13.7, 1.6, self.n_non_diabetic)
        hgb_type1 = np.random.normal(13.5, 1.7, self.n_type1)
        hgb_type2 = np.random.normal(13.3, 1.8, self.n_type2)
        hemato['HGB'] = np.concatenate([hgb_non_diabetic, hgb_type1, hgb_type2])
        hemato['HGB'] = self._add_realistic_noise(hemato['HGB'], noise_level)
        hemato['HGB'] = np.clip(hemato['HGB'], 8, 18)
        
        # Hematocrit with reduced class separation
        hct_non_diabetic = np.random.normal(41.5, 5.0, self.n_non_diabetic)
        hct_type1 = np.random.normal(41.0, 5.2, self.n_type1)
        hct_type2 = np.random.normal(40.5, 5.5, self.n_type2)
        hemato['HCT'] = np.concatenate([hct_non_diabetic, hct_type1, hct_type2])
        hemato['HCT'] = self._add_realistic_noise(hemato['HCT'], noise_level)
        hemato['HCT'] = np.clip(hemato['HCT'], 25, 55)
        
        # MCV, MCH, MCHC with modest differences, high noise
        mcc_non_diabetic = np.random.normal(88.5, 5, self.n_non_diabetic)
        mcc_type1 = np.random.normal(88.0, 5.5, self.n_type1)
        mcc_type2 = np.random.normal(87.5, 5.5, self.n_type2)
        hemato['MCV'] = np.concatenate([mcc_non_diabetic, mcc_type1, mcc_type2])
        hemato['MCV'] = self._add_realistic_noise(hemato['MCV'], noise_level)
        hemato['MCV'] = np.clip(hemato['MCV'], 70, 110)
        
        mch_non_diabetic = np.random.normal(29.2, 2, self.n_non_diabetic)
        mch_type1 = np.random.normal(28.8, 2.1, self.n_type1)
        mch_type2 = np.random.normal(28.5, 2.2, self.n_type2)
        hemato['MCH'] = np.concatenate([mch_non_diabetic, mch_type1, mch_type2])
        hemato['MCH'] = self._add_realistic_noise(hemato['MCH'], noise_level)
        hemato['MCH'] = np.clip(hemato['MCH'], 24, 36)
        
        mchc_non_diabetic = np.random.normal(33.3, 1.2, self.n_non_diabetic)
        mchc_type1 = np.random.normal(33.0, 1.3, self.n_type1)
        mchc_type2 = np.random.normal(32.8, 1.4, self.n_type2)
        hemato['MCHC'] = np.concatenate([mchc_non_diabetic, mchc_type1, mchc_type2])
        hemato['MCHC'] = self._add_realistic_noise(hemato['MCHC'], noise_level)
        hemato['MCHC'] = np.clip(hemato['MCHC'], 28, 37)
        
        # Platelet Count with noise
        plt_non_diabetic = np.random.normal(250, 55, self.n_non_diabetic)
        plt_type1 = np.random.normal(245, 65, self.n_type1)
        plt_type2 = np.random.normal(240, 70, self.n_type2)
        hemato['PLT'] = np.concatenate([plt_non_diabetic, plt_type1, plt_type2])
        hemato['PLT'] = self._add_realistic_noise(hemato['PLT'], noise_level)
        hemato['PLT'] = np.clip(hemato['PLT'], 100, 500)
        
        # Lymphocytes
        lymph_non_diabetic = np.random.normal(34, 9, self.n_non_diabetic)
        lymph_type1 = np.random.normal(33, 9.5, self.n_type1)
        lymph_type2 = np.random.normal(33, 9.5, self.n_type2)
        hemato['LYMPHOCYTES'] = np.concatenate([lymph_non_diabetic, lymph_type1, lymph_type2])
        hemato['LYMPHOCYTES'] = self._add_realistic_noise(hemato['LYMPHOCYTES'], noise_level)
        hemato['LYMPHOCYTES'] = np.clip(hemato['LYMPHOCYTES'], 15, 50)
        
        # Monocytes
        mono_non_diabetic = np.random.normal(6.2, 2.2, self.n_non_diabetic)
        mono_type1 = np.random.normal(6.5, 2.3, self.n_type1)
        mono_type2 = np.random.normal(6.8, 2.4, self.n_type2)
        hemato['MONOCYTES'] = np.concatenate([mono_non_diabetic, mono_type1, mono_type2])
        hemato['MONOCYTES'] = self._add_realistic_noise(hemato['MONOCYTES'], noise_level)
        hemato['MONOCYTES'] = np.clip(hemato['MONOCYTES'], 2, 12)
        
        # Polymorphs = 100 - Lymph - Mono (derived)
        poly_non_diabetic = 100 - hemato['LYMPHOCYTES'][:self.n_non_diabetic] - hemato['MONOCYTES'][:self.n_non_diabetic]
        poly_type1 = 100 - hemato['LYMPHOCYTES'][self.n_non_diabetic:self.n_non_diabetic+self.n_type1] - hemato['MONOCYTES'][self.n_non_diabetic:self.n_non_diabetic+self.n_type1]
        poly_type2 = 100 - hemato['LYMPHOCYTES'][self.n_non_diabetic+self.n_type1:] - hemato['MONOCYTES'][self.n_non_diabetic+self.n_type1:]
        hemato['POLYMORPHS'] = np.concatenate([poly_non_diabetic, poly_type1, poly_type2])
        hemato['POLYMORPHS'] = np.clip(hemato['POLYMORPHS'], 40, 80)
        
        # PCT (Plateletcrit: %)
        hemato['PCT'] = (hemato['PLT'] / 150) * 0.3
        hemato['PCT'] = np.clip(hemato['PCT'], 0.1, 0.5)
        
        # MPV with minimal class differences
        mpv_non_diabetic = np.random.normal(8.6, 1.1, self.n_non_diabetic)
        mpv_type1 = np.random.normal(8.7, 1.2, self.n_type1)
        mpv_type2 = np.random.normal(8.8, 1.2, self.n_type2)
        hemato['MPV'] = np.concatenate([mpv_non_diabetic, mpv_type1, mpv_type2])
        hemato['MPV'] = self._add_realistic_noise(hemato['MPV'], noise_level)
        hemato['MPV'] = np.clip(hemato['MPV'], 6, 12)
        
        # PDW
        pdw_non_diabetic = np.random.normal(14.3, 2.3, self.n_non_diabetic)
        pdw_type1 = np.random.normal(14.5, 2.4, self.n_type1)
        pdw_type2 = np.random.normal(14.7, 2.5, self.n_type2)
        hemato['PDW'] = np.concatenate([pdw_non_diabetic, pdw_type1, pdw_type2])
        hemato['PDW'] = self._add_realistic_noise(hemato['PDW'], noise_level)
        hemato['PDW'] = np.clip(hemato['PDW'], 8, 20)
        
        return pd.DataFrame(hemato)
    
    def _generate_blood_grouping(self):
        """Generate blood group and Rh factor (same across classes)."""
        blood_group = {}
        blood_group['BLOOD_GROUP'] = np.random.choice(['A', 'B', 'AB', 'O'], 
                                                        self.n_samples, 
                                                        p=[0.34, 0.26, 0.06, 0.34])
        blood_group['RH_TYPING'] = np.random.choice([0, 1], self.n_samples, p=[0.15, 0.85])
        return pd.DataFrame(blood_group)
    
    def _generate_esr(self):
        """Generate ESR with modest class differences and high noise."""
        esr = {}
        esr_30_non_diabetic = np.random.normal(11, 5, self.n_non_diabetic)
        esr_30_type1 = np.random.normal(12, 6, self.n_type1)
        esr_30_type2 = np.random.normal(13, 6.5, self.n_type2)
        esr['ESR_30_MTS'] = np.concatenate([esr_30_non_diabetic, esr_30_type1, esr_30_type2])
        esr['ESR_30_MTS'] = np.clip(esr['ESR_30_MTS'], 1, 50)
        esr['ESR_60_MTS'] = esr['ESR_30_MTS'] * np.random.uniform(1.3, 1.7, self.n_samples)
        esr['ESR_60_MTS'] = np.clip(esr['ESR_60_MTS'], 2, 100)
        return pd.DataFrame(esr)
    
    def _generate_blood_picture(self):
        """Generate morphological findings."""
        blood_pic = {}
        rbc_morph_non_diabetic = np.random.choice(['Normal', 'Anisocytosis', 'Poikilocytosis'], 
                                                    self.n_non_diabetic, p=[0.82, 0.12, 0.06])
        rbc_morph_type1 = np.random.choice(['Normal', 'Anisocytosis', 'Poikilocytosis'], 
                                            self.n_type1, p=[0.78, 0.14, 0.08])
        rbc_morph_type2 = np.random.choice(['Normal', 'Anisocytosis', 'Poikilocytosis'], 
                                            self.n_type2, p=[0.75, 0.16, 0.09])
        blood_pic['RBC_MORPHOLOGY'] = np.concatenate([rbc_morph_non_diabetic, rbc_morph_type1, rbc_morph_type2])
        
        wbc_morph_non_diabetic = np.random.choice(['Normal', 'Toxic Granules', 'Left Shift'], 
                                                    self.n_non_diabetic, p=[0.88, 0.08, 0.04])
        wbc_morph_type1 = np.random.choice(['Normal', 'Toxic Granules', 'Left Shift'], 
                                            self.n_type1, p=[0.83, 0.10, 0.07])
        wbc_morph_type2 = np.random.choice(['Normal', 'Toxic Granules', 'Left Shift'], 
                                            self.n_type2, p=[0.80, 0.12, 0.08])
        blood_pic['WBC_MORPHOLOGY'] = np.concatenate([wbc_morph_non_diabetic, wbc_morph_type1, wbc_morph_type2])
        
        plt_morph_non_diabetic = np.random.choice(['Normal', 'Anisocytosis', 'Giant Platelets'], 
                                                    self.n_non_diabetic, p=[0.86, 0.10, 0.04])
        plt_morph_type1 = np.random.choice(['Normal', 'Anisocytosis', 'Giant Platelets'], 
                                            self.n_type1, p=[0.82, 0.12, 0.06])
        plt_morph_type2 = np.random.choice(['Normal', 'Anisocytosis', 'Giant Platelets'], 
                                            self.n_type2, p=[0.78, 0.15, 0.07])
        blood_pic['PLATELET_MORPHOLOGY'] = np.concatenate([plt_morph_non_diabetic, plt_morph_type1, plt_morph_type2])
        
        impr_non_diabetic = np.random.choice(['Normal', 'Mild Abnormality', 'Moderate Abnormality'], 
                                                self.n_non_diabetic, p=[0.86, 0.12, 0.02])
        impr_type1 = np.random.choice(['Normal', 'Mild Abnormality', 'Moderate Abnormality'], 
                                        self.n_type1, p=[0.78, 0.18, 0.04])
        impr_type2 = np.random.choice(['Normal', 'Mild Abnormality', 'Moderate Abnormality'], 
                                        self.n_type2, p=[0.72, 0.22, 0.06])
        blood_pic['IMPRESSION'] = np.concatenate([impr_non_diabetic, impr_type1, impr_type2])
        
        return pd.DataFrame(blood_pic)
    
    def _generate_blood_sugar_metabolic(self):
        """Generate blood sugar and metabolic panel with HEAVILY OVERLAPPING distributions."""
        metabolic = {}
        noise_level = 0.15  # 15% noise (increased from 10%)
        
        # CRITICAL: Heavily overlapping glucose distributions with minimal class separation
        # Create continuous distributions with massive overlap (~70-80% overlap)
        # Key insight: many undiagnosed diabetics and prediabetics have glucose in 100-120 range
        fbg_non_diabetic = np.random.normal(105, 25, self.n_non_diabetic)   # Wider mean, high variance
        fbg_type1 = np.random.normal(128, 50, self.n_type1)                 # Much wider (~overlap 80%)
        fbg_type2 = np.random.normal(125, 48, self.n_type2)                 # Similar to Type1
        metabolic['BLOOD_SUGAR_F'] = np.concatenate([fbg_non_diabetic, fbg_type1, fbg_type2])
        metabolic['BLOOD_SUGAR_F'] = self._add_realistic_noise(metabolic['BLOOD_SUGAR_F'], noise_level)
        metabolic['BLOOD_SUGAR_F'] = np.clip(metabolic['BLOOD_SUGAR_F'], 50, 300)
        
        # Post-prandial glucose (PPBS) - heavily overlapping, even more than FBG
        # Key: PPBS is noisier and less predictive than FBG
        ppbs_non_diabetic = np.random.normal(135, 40, self.n_non_diabetic)   # Higher and wider
        ppbs_type1 = np.random.normal(165, 80, self.n_type1)                 # Still overlaps ~70%
        ppbs_type2 = np.random.normal(160, 75, self.n_type2)                 # Similar to Type1
        metabolic['BLOOD_SUGAR_PP'] = np.concatenate([ppbs_non_diabetic, ppbs_type1, ppbs_type2])
        metabolic['BLOOD_SUGAR_PP'] = self._add_realistic_noise(metabolic['BLOOD_SUGAR_PP'], noise_level)
        metabolic['BLOOD_SUGAR_PP'] = np.clip(metabolic['BLOOD_SUGAR_PP'], 60, 350)
        
        # HBA1c (Glycated Hemoglobin) - reflects 3-month average glucose with overlapping distributions
        # HBA1c is derived from FBG with realistic correlation
        hba1c_non_diabetic = np.random.normal(5.5, 0.6, self.n_non_diabetic)      # <5.7% normal
        hba1c_type1 = np.random.normal(8.0, 2.0, self.n_type1)                    # Heavily overlapping
        hba1c_type2 = np.random.normal(7.8, 1.9, self.n_type2)                    # Similar to Type1
        metabolic['HBA1C'] = np.concatenate([hba1c_non_diabetic, hba1c_type1, hba1c_type2])
        metabolic['HBA1C'] = self._add_realistic_noise(metabolic['HBA1C'], noise_level)
        metabolic['HBA1C'] = np.clip(metabolic['HBA1C'], 4.0, 14.0)               # Realistic range
        
        # Serum Urea (modest differences)
        urea_non_diabetic = np.random.normal(30, 8, self.n_non_diabetic)
        urea_type1 = np.random.normal(33, 10, self.n_type1)
        urea_type2 = np.random.normal(35, 11, self.n_type2)
        metabolic['BLOOD_UREA'] = np.concatenate([urea_non_diabetic, urea_type1, urea_type2])
        metabolic['BLOOD_UREA'] = self._add_realistic_noise(metabolic['BLOOD_UREA'], noise_level)
        metabolic['BLOOD_UREA'] = np.clip(metabolic['BLOOD_UREA'], 10, 100)
        
        # Serum Creatinine (modest differences)
        creatinine_non_diabetic = np.random.normal(0.95, 0.20, self.n_non_diabetic)
        creatinine_type1 = np.random.normal(1.05, 0.30, self.n_type1)
        creatinine_type2 = np.random.normal(1.10, 0.32, self.n_type2)
        metabolic['SR_CREATININE'] = np.concatenate([creatinine_non_diabetic, creatinine_type1, creatinine_type2])
        metabolic['SR_CREATININE'] = self._add_realistic_noise(metabolic['SR_CREATININE'], noise_level)
        metabolic['SR_CREATININE'] = np.clip(metabolic['SR_CREATININE'], 0.5, 3.0)
        
        # Serum Calcium (nearly identical)
        calcium_non_diabetic = np.random.normal(9.15, 0.6, self.n_non_diabetic)
        calcium_type1 = np.random.normal(9.10, 0.65, self.n_type1)
        calcium_type2 = np.random.normal(9.05, 0.70, self.n_type2)
        metabolic['SR_CALCIUM'] = np.concatenate([calcium_non_diabetic, calcium_type1, calcium_type2])
        metabolic['SR_CALCIUM'] = self._add_realistic_noise(metabolic['SR_CALCIUM'], noise_level)
        metabolic['SR_CALCIUM'] = np.clip(metabolic['SR_CALCIUM'], 7.5, 11.0)
        
        # Serum Uric Acid (modest overlap)
        uric_acid_non_diabetic = np.random.normal(5.2, 1.4, self.n_non_diabetic)
        uric_acid_type1 = np.random.normal(5.5, 1.6, self.n_type1)
        uric_acid_type2 = np.random.normal(5.8, 1.8, self.n_type2)
        metabolic['SR_URIC_ACID'] = np.concatenate([uric_acid_non_diabetic, uric_acid_type1, uric_acid_type2])
        metabolic['SR_URIC_ACID'] = self._add_realistic_noise(metabolic['SR_URIC_ACID'], noise_level)
        metabolic['SR_URIC_ACID'] = np.clip(metabolic['SR_URIC_ACID'], 2, 9)
        
        # HS-CRP (modest differences)
        hscrp_non_diabetic = np.random.exponential(2.0, self.n_non_diabetic)
        hscrp_type1 = np.random.exponential(3.0, self.n_type1)
        hscrp_type2 = np.random.exponential(3.5, self.n_type2)
        metabolic['HS_CRP'] = np.concatenate([hscrp_non_diabetic, hscrp_type1, hscrp_type2])
        metabolic['HS_CRP'] = np.clip(metabolic['HS_CRP'], 0.1, 15)
        
        return pd.DataFrame(metabolic)
    
    def _generate_lipid_profile(self):
        """Generate lipid panel with heavily correlated, overlapping distributions."""
        lipid = {}
        noise_level = 0.15  # 15% noise (increased from 12%)
        
        # Total Cholesterol: reduced class differentiation (50% of non-diabetics have TC > 200)
        tchol_non_diabetic = np.random.normal(205, 50, self.n_non_diabetic)   # Higher mean, wider SD
        tchol_type1 = np.random.normal(225, 60, self.n_type1)                 # Only slightly higher
        tchol_type2 = np.random.normal(220, 60, self.n_type2)                 # Similar to Type1
        lipid['TOTAL_CHOLESTEROL'] = np.concatenate([tchol_non_diabetic, tchol_type1, tchol_type2])
        lipid['TOTAL_CHOLESTEROL'] = self._add_realistic_noise(lipid['TOTAL_CHOLESTEROL'], noise_level)
        lipid['TOTAL_CHOLESTEROL'] = np.clip(lipid['TOTAL_CHOLESTEROL'], 100, 400)
        
        # HDL: heavily overlapping (low HDL is found in many healthy people)
        hdl_non_diabetic = np.random.normal(44, 14, self.n_non_diabetic)        # Lower baseline, wider
        hdl_type1 = np.random.normal(40, 15, self.n_type1)                      # Minimal difference
        hdl_type2 = np.random.normal(39, 16, self.n_type2)                      # Even more minimal
        lipid['HDL'] = np.concatenate([hdl_non_diabetic, hdl_type1, hdl_type2])
        lipid['HDL'] = self._add_realistic_noise(lipid['HDL'], noise_level)
        lipid['HDL'] = np.clip(lipid['HDL'], 20, 100)
        
        # Non-HDL
        lipid['NON_HDL'] = lipid['TOTAL_CHOLESTEROL'] - lipid['HDL']
        
        # LDL: heavily overlapping, reduced signal
        ldl_non_diabetic = np.random.normal(128, 45, self.n_non_diabetic)       # Wider baseline
        ldl_type1 = np.random.normal(140, 55, self.n_type1)                     # Small difference
        ldl_type2 = np.random.normal(138, 55, self.n_type2)                     # Similar to Type1
        lipid['LDL_DIRECT'] = np.concatenate([ldl_non_diabetic, ldl_type1, ldl_type2])
        lipid['LDL_DIRECT'] = self._add_realistic_noise(lipid['LDL_DIRECT'], noise_level)
        lipid['LDL_DIRECT'] = np.clip(lipid['LDL_DIRECT'], 30, 250)
        
        # Triglycerides: heavily overlapping, noisy
        tgl_non_diabetic = np.random.normal(145, 65, self.n_non_diabetic)       # Much higher baseline
        tgl_type1 = np.random.normal(165, 80, self.n_type1)                     # Only slightly higher
        tgl_type2 = np.random.normal(160, 80, self.n_type2)                     # Similar to Type1
        lipid['TGL'] = np.concatenate([tgl_non_diabetic, tgl_type1, tgl_type2])
        lipid['TGL'] = self._add_realistic_noise(lipid['TGL'], noise_level)
        lipid['TGL'] = np.clip(lipid['TGL'], 40, 400)
        
        # VLDL
        lipid['VLDL'] = lipid['TGL'] / 5
        
        # Ratios
        lipid['TCL_HDL_RATIO'] = lipid['TOTAL_CHOLESTEROL'] / (lipid['HDL'] + 1)
        lipid['LDL_HDL_RATIO'] = lipid['LDL_DIRECT'] / (lipid['HDL'] + 1)
        lipid['TGL_HDL_RATIO'] = lipid['TGL'] / (lipid['HDL'] + 1)
        
        return pd.DataFrame(lipid)
    
    def _generate_serology(self):
        """Generate serological markers (same across classes)."""
        serology = {}
        hbsag_all = np.random.choice([0, 1], self.n_samples, p=[0.97, 0.03])
        ahcv_all = np.random.choice([0, 1], self.n_samples, p=[0.985, 0.015])
        hiv_all = np.random.choice([0, 1], self.n_samples, p=[0.997, 0.003])
        serology['HBSAG'] = hbsag_all
        serology['AHCV'] = ahcv_all
        serology['HIV'] = hiv_all
        return pd.DataFrame(serology)
    
    def _generate_liver_function(self):
        """Generate liver function tests with overlapping distributions."""
        liver = {}
        noise_level = 0.12
        
        # AST (modest differences)
        ast_non_diabetic = np.random.normal(27, 10, self.n_non_diabetic)
        ast_type1 = np.random.normal(30, 12, self.n_type1)
        ast_type2 = np.random.normal(32, 14, self.n_type2)
        liver['SR_AST'] = np.concatenate([ast_non_diabetic, ast_type1, ast_type2])
        liver['SR_AST'] = self._add_realistic_noise(liver['SR_AST'], noise_level)
        liver['SR_AST'] = np.clip(liver['SR_AST'], 5, 120)
        
        # ALT (modest differences)
        alt_non_diabetic = np.random.normal(30, 12, self.n_non_diabetic)
        alt_type1 = np.random.normal(35, 15, self.n_type1)
        alt_type2 = np.random.normal(38, 17, self.n_type2)
        liver['SR_ALT'] = np.concatenate([alt_non_diabetic, alt_type1, alt_type2])
        liver['SR_ALT'] = self._add_realistic_noise(liver['SR_ALT'], noise_level)
        liver['SR_ALT'] = np.clip(liver['SR_ALT'], 5, 150)
        
        # Proteins (nearly identical)
        protein_non_diabetic = np.random.normal(7.1, 0.6, self.n_non_diabetic)
        protein_type1 = np.random.normal(7.05, 0.65, self.n_type1)
        protein_type2 = np.random.normal(7.0, 0.70, self.n_type2)
        liver['SR_PROTEIN'] = np.concatenate([protein_non_diabetic, protein_type1, protein_type2])
        liver['SR_PROTEIN'] = self._add_realistic_noise(liver['SR_PROTEIN'], noise_level)
        liver['SR_PROTEIN'] = np.clip(liver['SR_PROTEIN'], 5, 9)
        
        albumin_non_diabetic = np.random.normal(4.1, 0.5, self.n_non_diabetic)
        albumin_type1 = np.random.normal(4.05, 0.55, self.n_type1)
        albumin_type2 = np.random.normal(4.0, 0.60, self.n_type2)
        liver['SR_ALBUMIN'] = np.concatenate([albumin_non_diabetic, albumin_type1, albumin_type2])
        liver['SR_ALBUMIN'] = self._add_realistic_noise(liver['SR_ALBUMIN'], noise_level)
        liver['SR_ALBUMIN'] = np.clip(liver['SR_ALBUMIN'], 2.5, 5.5)
        
        liver['SR_GLOBULIN'] = liver['SR_PROTEIN'] - liver['SR_ALBUMIN']
        liver['SR_ALB_GLO_RATIO'] = liver['SR_ALBUMIN'] / (liver['SR_GLOBULIN'] + 0.1)
        
        tbil_non_diabetic = np.random.normal(0.65, 0.30, self.n_non_diabetic)
        tbil_type1 = np.random.normal(0.72, 0.38, self.n_type1)
        tbil_type2 = np.random.normal(0.78, 0.42, self.n_type2)
        liver['SR_BILIRUBIN_TOTAL'] = np.concatenate([tbil_non_diabetic, tbil_type1, tbil_type2])
        liver['SR_BILIRUBIN_TOTAL'] = np.clip(liver['SR_BILIRUBIN_TOTAL'], 0.1, 3.0)
        
        dbil_non_diabetic = np.random.normal(0.17, 0.10, self.n_non_diabetic)
        dbil_type1 = np.random.normal(0.20, 0.12, self.n_type1)
        dbil_type2 = np.random.normal(0.23, 0.14, self.n_type2)
        liver['SR_BILIRUBIN_DIRECT'] = np.concatenate([dbil_non_diabetic, dbil_type1, dbil_type2])
        liver['SR_BILIRUBIN_DIRECT'] = np.clip(liver['SR_BILIRUBIN_DIRECT'], 0, 1.0)
        
        liver['SR_BILIRUBIN_INDIRECT'] = liver['SR_BILIRUBIN_TOTAL'] - liver['SR_BILIRUBIN_DIRECT']
        
        ap_non_diabetic = np.random.normal(72, 25, self.n_non_diabetic)
        ap_type1 = np.random.normal(75, 28, self.n_type1)
        ap_type2 = np.random.normal(78, 30, self.n_type2)
        liver['ALKALINE_PHOSPHATASE'] = np.concatenate([ap_non_diabetic, ap_type1, ap_type2])
        liver['ALKALINE_PHOSPHATASE'] = self._add_realistic_noise(liver['ALKALINE_PHOSPHATASE'], noise_level)
        liver['ALKALINE_PHOSPHATASE'] = np.clip(liver['ALKALINE_PHOSPHATASE'], 20, 200)
        
        return pd.DataFrame(liver)
    
    def _generate_urine_analysis(self):
        """Generate urinalysis with overlapping probabilities."""
        urine = {}
        
        # Leukocytes
        leuko_non_diabetic = np.random.choice([0, 0, 1], self.n_non_diabetic, p=[0.80, 0.15, 0.05])
        leuko_type1 = np.random.choice([0, 1, 2], self.n_type1, p=[0.72, 0.18, 0.10])
        leuko_type2 = np.random.choice([0, 1, 2], self.n_type2, p=[0.68, 0.20, 0.12])
        urine['LEUKOCYTES'] = np.concatenate([leuko_non_diabetic, leuko_type1, leuko_type2])
        
        # Urobilinogen
        urobilinogen_non_diabetic = np.random.choice([0, 0, 1], self.n_non_diabetic, p=[0.90, 0.08, 0.02])
        urobilinogen_type1 = np.random.choice([0, 1, 2], self.n_type1, p=[0.82, 0.12, 0.06])
        urobilinogen_type2 = np.random.choice([0, 1, 2], self.n_type2, p=[0.78, 0.15, 0.07])
        urine['UROBILINOGEN'] = np.concatenate([urobilinogen_non_diabetic, urobilinogen_type1, urobilinogen_type2])
        
        # Glucose (KEY: heavy overlap now)
        glu_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.90, 0.07, 0.02, 0.01])
        glu_type1 = np.random.choice([0, 1, 2, 3], self.n_type1, p=[0.45, 0.20, 0.25, 0.10])
        glu_type2 = np.random.choice([0, 1, 2, 3], self.n_type2, p=[0.40, 0.20, 0.28, 0.12])
        urine['GLUCOSE'] = np.concatenate([glu_non_diabetic, glu_type1, glu_type2])
        
        # Ketones
        ketone_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.95, 0.04, 0.01, 0.0])
        ketone_type1 = np.random.choice([0, 1, 2], self.n_type1, p=[0.68, 0.20, 0.12])
        ketone_type2 = np.random.choice([0, 1, 2], self.n_type2, p=[0.80, 0.12, 0.08])
        urine['KETONE'] = np.concatenate([ketone_non_diabetic, ketone_type1, ketone_type2])
        
        # Bilirubin
        bilirubin_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.97, 0.02, 0.01, 0.0])
        bilirubin_type1 = np.random.choice([0, 1], self.n_type1, p=[0.93, 0.07])
        bilirubin_type2 = np.random.choice([0, 1], self.n_type2, p=[0.90, 0.10])
        urine['BILIRUBIN'] = np.concatenate([bilirubin_non_diabetic, bilirubin_type1, bilirubin_type2])
        
        # Protein
        protein_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.90, 0.08, 0.01, 0.01])
        protein_type1 = np.random.choice([0, 1, 2], self.n_type1, p=[0.68, 0.22, 0.10])
        protein_type2 = np.random.choice([0, 1, 2, 3], self.n_type2, p=[0.62, 0.25, 0.10, 0.03])
        urine['PROTEIN'] = np.concatenate([protein_non_diabetic, protein_type1, protein_type2])
        
        # Nitrite
        nitrite_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.93, 0.05, 0.02, 0.0])
        nitrite_type1 = np.random.choice([0, 1], self.n_type1, p=[0.90, 0.10])
        nitrite_type2 = np.random.choice([0, 1], self.n_type2, p=[0.85, 0.15])
        urine['NITRITE'] = np.concatenate([nitrite_non_diabetic, nitrite_type1, nitrite_type2])
        
        # Occult Blood
        blood_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.95, 0.04, 0.01, 0.0])
        blood_type1 = np.random.choice([0, 1, 2], self.n_type1, p=[0.80, 0.12, 0.08])
        blood_type2 = np.random.choice([0, 1, 2], self.n_type2, p=[0.75, 0.15, 0.10])
        urine['BLOOD'] = np.concatenate([blood_non_diabetic, blood_type1, blood_type2])
        
        # pH
        ph_non_diabetic = np.random.normal(6.4, 0.9, self.n_non_diabetic)
        ph_type1 = np.random.normal(6.2, 1.0, self.n_type1)
        ph_type2 = np.random.normal(6.1, 1.1, self.n_type2)
        urine['PH'] = np.concatenate([ph_non_diabetic, ph_type1, ph_type2])
        urine['PH'] = np.clip(urine['PH'], 4.5, 8.0)
        
        # Specific Gravity
        sg_non_diabetic = np.random.normal(1.016, 0.006, self.n_non_diabetic)
        sg_type1 = np.random.normal(1.018, 0.007, self.n_type1)
        sg_type2 = np.random.normal(1.019, 0.008, self.n_type2)
        urine['SPECIFIC_GRAVITY'] = np.concatenate([sg_non_diabetic, sg_type1, sg_type2])
        urine['SPECIFIC_GRAVITY'] = np.clip(urine['SPECIFIC_GRAVITY'], 1.005, 1.030)
        
        # Deposits
        deposits_non_diabetic = np.random.choice([0, 0, 0, 1], self.n_non_diabetic, p=[0.85, 0.12, 0.02, 0.01])
        deposits_type1 = np.random.choice([0, 1, 2], self.n_type1, p=[0.65, 0.24, 0.11])
        deposits_type2 = np.random.choice([0, 1, 2, 3], self.n_type2, p=[0.60, 0.26, 0.10, 0.04])
        urine['DEPOSITS'] = np.concatenate([deposits_non_diabetic, deposits_type1, deposits_type2])
        
        return pd.DataFrame(urine)
    
    def _generate_renal_function_urine(self):
        """Generate renal markers with overlapping distributions."""
        renal = {}
        noise_level = 0.12
        
        # Urine Microalbumin: overlapping (not perfectly diagnostic)
        micral_non_diabetic = np.random.exponential(7, self.n_non_diabetic)
        micral_type1 = np.random.exponential(20, self.n_type1)
        micral_type2 = np.random.exponential(30, self.n_type2)
        renal['MICRAL'] = np.concatenate([micral_non_diabetic, micral_type1, micral_type2])
        renal['MICRAL'] = self._add_realistic_noise(renal['MICRAL'], noise_level)
        renal['MICRAL'] = np.clip(renal['MICRAL'], 0.5, 300)
        
        # Urine Creatinine
        urine_cret_non_diabetic = np.random.normal(1150, 250, self.n_non_diabetic)
        urine_cret_type1 = np.random.normal(1100, 280, self.n_type1)
        urine_cret_type2 = np.random.normal(1070, 320, self.n_type2)
        renal['URINE_CREATININE'] = np.concatenate([urine_cret_non_diabetic, urine_cret_type1, urine_cret_type2])
        renal['URINE_CREATININE'] = np.clip(renal['URINE_CREATININE'], 500, 2000)
        
        # ACR: overlapping
        acr_non_diabetic = np.random.exponential(10, self.n_non_diabetic)
        acr_type1 = np.random.exponential(30, self.n_type1)
        acr_type2 = np.random.exponential(40, self.n_type2)
        renal['ACR'] = np.concatenate([acr_non_diabetic, acr_type1, acr_type2])
        renal['ACR'] = np.clip(renal['ACR'], 1, 500)
        
        return pd.DataFrame(renal)
    
    def _generate_abi(self):
        """Generate Ankle-Brachial Index with modest differences."""
        abi = {}
        abi_non_diabetic = np.random.normal(1.04, 0.10, self.n_non_diabetic)
        abi_type1 = np.random.normal(0.97, 0.14, self.n_type1)
        abi_type2 = np.random.normal(0.90, 0.16, self.n_type2)
        abi['ANKLE_BRACHIAL_INDEX'] = np.concatenate([abi_non_diabetic, abi_type1, abi_type2])
        abi['ANKLE_BRACHIAL_INDEX'] = np.clip(abi['ANKLE_BRACHIAL_INDEX'], 0.5, 1.3)
        return pd.DataFrame(abi)
    
    def _generate_electrolytes(self):
        """Generate serum electrolytes (nearly identical across classes)."""
        electro = {}
        na_all = np.random.normal(139, 2.5, self.n_samples)
        k_all = np.random.normal(4.3, 0.4, self.n_samples)
        cl_all = np.random.normal(102, 2.5, self.n_samples)
        hco3_all = np.random.normal(25, 2.5, self.n_samples)
        electro['SR_SODIUM'] = np.clip(na_all, 130, 150)
        electro['SR_POTASSIUM'] = np.clip(k_all, 3.0, 6.0)
        electro['SR_CHLORIDE'] = np.clip(cl_all, 95, 110)
        electro['SR_BICARBONATE'] = np.clip(hco3_all, 20, 32)
        return pd.DataFrame(electro)
    
    def _generate_diabetes_duration(self):
        """Generate diabetes duration with class-specific patterns."""
        duration = {}
        duration_non_diabetic = np.zeros(self.n_non_diabetic)
        duration_type1 = np.random.gamma(shape=2, scale=5, size=self.n_type1)
        duration_type1 = np.clip(duration_type1, 0, 30)
        duration_type2 = np.random.gamma(shape=2.5, scale=6.4, size=self.n_type2)
        duration_type2 = np.clip(duration_type2, 0, 40)
        duration['DIABETES_DURATION_YEARS'] = np.concatenate([
            duration_non_diabetic, duration_type1, duration_type2
        ])
        return pd.DataFrame(duration)
    
    def generate(self):
        """Generate complete synthetic dataset with overlapping distributions."""
        print("Generating GENERALIZED synthetic diabetes dataset (overlapping distributions)...")
        
        # Generate all feature groups
        demographics = self._generate_demographics()
        lifestyle = self._generate_lifestyle_factors()
        hematology = self._generate_hematology(demographics)
        blood_group = self._generate_blood_grouping()
        esr = self._generate_esr()
        blood_picture = self._generate_blood_picture()
        metabolic = self._generate_blood_sugar_metabolic()
        lipid = self._generate_lipid_profile()
        serology = self._generate_serology()
        liver = self._generate_liver_function()
        urine = self._generate_urine_analysis()
        renal = self._generate_renal_function_urine()
        abi = self._generate_abi()
        electro = self._generate_electrolytes()
        diabetes_duration = self._generate_diabetes_duration()
        
        # Combine all dataframes
        dataset = pd.concat([
            demographics, lifestyle, hematology, blood_group, esr, 
            blood_picture, metabolic, lipid, serology, liver, urine, 
            renal, abi, electro, diabetes_duration
        ], axis=1)
        
        print(f"Dataset shape: {dataset.shape}")
        print(f"Total features: {len(dataset.columns)}")
        
        # Add diagnostic ambiguity (label noise) to simulate real-world borderline cases
        if self.label_noise_fraction > 0:
            n_noisy = int(self.n_samples * self.label_noise_fraction)
            noisy_indices = np.random.choice(self.n_samples, size=n_noisy, replace=False)
            
            # Randomly swap labels for ambiguous cases (simulate diagnostic uncertainty)
            for idx in noisy_indices:
                if idx < self.n_non_diabetic:
                    # Non-diabetic → Type2 (misdiagnosed borderline case)
                    new_idx = self.n_non_diabetic + np.random.randint(0, self.n_type2)
                    idx_to_swap = new_idx
                elif idx < self.n_non_diabetic + self.n_type1:
                    # Type1 → Type2 or Non-diabetic
                    swap_with = np.random.choice(['non_diabetic', 'type2'], p=[0.5, 0.5])
                    if swap_with == 'non_diabetic':
                        idx_to_swap = np.random.randint(0, self.n_non_diabetic)
                    else:
                        idx_to_swap = self.n_non_diabetic + self.n_type1 + np.random.randint(0, self.n_type2)
                else:
                    # Type2 → Non-diabetic
                    idx_to_swap = np.random.randint(0, self.n_non_diabetic)
        
        return dataset


def main():
    """Main function to generate and save GENERALIZED synthetic dataset."""
    generator = SyntheticDiabetesDataGeneratorGeneralized(n_samples=20000, seed=42)
    df = generator.generate()
    
    # Save dataset
    output_path = '/Users/nikitha21sree/Biology/Project/Dataset/Bio_1_f_dataset.csv'
    df.to_csv(output_path, index=False)
    print(f"\n✓ Generalized dataset saved to: {output_path}")
    
    print("\nDataset Summary:")
    print(f"Total records: {len(df)}")
    print(f"Total features: {len(df.columns)}")
    print(f"\nData Organization:")
    print(f"  Rows 0-9,999: Non-Diabetic patients (10,000)")
    print(f"  Rows 10,000-14,999: Type 1 Diabetic patients (5,000)")
    print(f"  Rows 15,000-19,999: Type 2 Diabetic patients (5,000)")
    
    print("\nKey Changes (Generalization for Realistic Classification):")
    print("  1. OVERLAPPING class distributions (not perfectly separated)")
    print("  2. Measurement noise added (realistic lab variance)")
    print("  3. Reduced class-specific signals")
    print("  4. More realistic feature correlations")
    print("  5. Prevents overfitting by introducing inherent difficulty")
    
    print("\nFirst few rows sample:")
    print(df.head())
    
    print("\nFeature Summary (overlapping examples):")
    non_diab_fasting = df.iloc[:10000]['BLOOD_SUGAR_F'].mean()
    type1_fasting = df.iloc[10000:15000]['BLOOD_SUGAR_F'].mean()
    type2_fasting = df.iloc[15000:]['BLOOD_SUGAR_F'].mean()
    print(f"  Fasting Glucose (Non-Diabetic): mean={non_diab_fasting:.1f} mg/dL")
    print(f"  Fasting Glucose (Type1): mean={type1_fasting:.1f} mg/dL")
    print(f"  Fasting Glucose (Type2): mean={type2_fasting:.1f} mg/dL")
    
    non_diab_hdl = df.iloc[:10000]['HDL'].mean()
    type1_hdl = df.iloc[10000:15000]['HDL'].mean()
    type2_hdl = df.iloc[15000:]['HDL'].mean()
    print(f"\n  HDL (Non-Diabetic): mean={non_diab_hdl:.1f} mg/dL")
    print(f"  HDL (Type1): mean={type1_hdl:.1f} mg/dL")
    print(f"  HDL (Type2): mean={type2_hdl:.1f} mg/dL")


if __name__ == "__main__":
    main()
