"""
Retinopathy Severity Classification
Classifies diabetic patients into 4 retinopathy severity levels (MILD, MODERATE, SEVERE, CRITICAL)
using multi-organ indicators:
  - Glycemic control (FBS → HbA1c proxy, BLOOD_SUGAR_PP)
  - Duration & complications (DIABETES_DURATION_YEARS)
  - Renal function (ACR - albuminuria indicates shared microvascular disease)
  - Inflammation (HS_CRP - systemic inflammation accelerates retinopathy)
  - BMI (metabolic risk factor for vision loss)

Clinical Ranges (from attachment):
  No DR (NONE): FBS <126, Duration <5
  Mild NPDR: 126-199, Duration 5-10, ACR 30-100, HS_CRP <3.0, BMI <30
  Moderate NPDR: 200-299, Duration 10-15, ACR 101-300, HS_CRP 3-10, BMI 30-35
  Severe NPDR/PDR: ≥300, Duration >15, ACR >300, HS_CRP >20, BMI >35

Score Points: Mild=10, Moderate=25, Severe=40

Output:
- Adds `RETINOPATHY_SEVERITY` column to dataset (labels: MILD/MODERATE/SEVERE/CRITICAL)
- Saves balanced dataset (~2500 per class) as Bio_f_Retinopathy.csv

Author: Project Team
Date: 2026-02-22
Version: 2.0 (Updated with HS_CRP, BMI multi-disease markers)
"""

import numpy as np
import pandas as pd
from pathlib import Path

class RetinopathySeverity:
    # new ordering as per specification
    LABELS = ['NONE', 'SEVERE', 'MILD', 'MODERATE']

    def __init__(self, diabetic_csv_path):
        self.path = Path(diabetic_csv_path)
        self.df = None
        self.scores = None

    def load(self):
        print(f"Loading diabetic dataset from: {self.path}")
        self.df = pd.read_csv(self.path)
        from dataset_utils import ensure_numeric_cols
        # ensure key numeric columns exist
        nums = ['BLOOD_SUGAR_F', 'DIABETES_DURATION_YEARS', 'ACR', 'HBA1C']
        self.df = ensure_numeric_cols(self.df, nums, fill_strategy='median', default=0)
        # If HBA1C was missing/filled with median, warn user
        if self.df['HBA1C'].isna().sum() > 0 or (self.df['HBA1C'] == 0).sum() > len(self.df) * 0.5:
            print("  ⚠ Warning: HBA1C values appear to be missing or defaulted. Ensure Bio_1_f_Data.py includes HBA1C generation.")
        print(f"Loaded: {self.df.shape[0]} rows × {self.df.shape[1]} columns")
        return self.df

    @staticmethod
    def _hba1c_from_fbs(fbs):
        # Rough proxy: HbA1c ≈ FBS/28.7 + 2 (keeps within plausible clinical range)
        return np.clip(fbs / 28.7 + 2, 3.0, 15.0)

    @staticmethod
    def _map_to_category(value, bins):
        """Map a numeric value to category index 0..3 using inclusive lower bounds."""
        # bins: list of thresholds of length 4: [(low, high), ...]
        for i, (low, high) in enumerate(bins):
            if (value >= low) and (value <= high if not np.isinf(high) else True):
                return i
        return 0

    def compute_composite_score(self):
        print("\nComputing composite retinopathy score using actual HBA1c, duration and ACR...")
        df = self.df
        # Ensure required columns
        if 'HBA1C' not in df.columns:
            # Fallback to proxy if HBA1C not available
            print("  ⚠ HBA1C column not found, falling back to proxy calculation from BLOOD_SUGAR_F")
            if 'BLOOD_SUGAR_F' not in df.columns:
                raise ValueError('HBA1C and BLOOD_SUGAR_F columns required in dataset')
            df['HBA1C'] = self._hba1c_from_fbs(df['BLOOD_SUGAR_F'].astype(float))

        # Duration
        if 'DIABETES_DURATION_YEARS' not in df.columns:
            # If missing, assume 0 for safety
            df['DIABETES_DURATION_YEARS'] = 0.0

        # ACR
        if 'ACR' not in df.columns:
            df['ACR'] = 0.0

        # Define bins from attachment
        hba1c_bins = [( -np.inf, 7.49), (7.5, 8.9), (9.0, 10.9), (11.0, np.inf)]
        duration_bins = [(-np.inf, 4.99), (5.0, 10.0), (10.0, 15.0), (15.0, np.inf)]
        acr_bins = [(-np.inf, 29.99), (30.0, 100.0), (101.0, 300.0), (300.0, np.inf)]

        # Map to category scores 0..3 using actual HBA1C
        hba1c_cat = df['HBA1C'].apply(lambda x: self._map_to_category(x, hba1c_bins)).astype(int)
        dur_cat = df['DIABETES_DURATION_YEARS'].apply(lambda x: self._map_to_category(x, duration_bins)).astype(int)
        acr_cat = df['ACR'].apply(lambda x: self._map_to_category(x, acr_bins)).astype(int)

        # Composite (sum of categories)
        composite = hba1c_cat + dur_cat + acr_cat  # range 0..9

        # Normalize to 0..3 by average
        avg_score = composite / 3.0  # float 0..3

        self.df['RETINO_HBA1C_CAT'] = hba1c_cat
        self.df['RETINO_DURATION_CAT'] = dur_cat
        self.df['RETINO_ACR_CAT'] = acr_cat
        self.scores = avg_score
        self.df['RETINO_COMPOSITE_SCORE'] = avg_score

        print(f"Computed composite score range: {self.scores.min():.2f} - {self.scores.max():.2f}")
        return self.scores

    def assign_balanced_severity(self):
        print("\nAssigning balanced severity groups (~2500 per label)...")
        if self.scores is None:
            self.compute_composite_score()
        # use shared utility
        from dataset_utils import assign_balanced_severity as _assign
        self.df['RETINOPATHY_SEVERITY'] = _assign(self.df, 'RETINO_COMPOSITE_SCORE', self.LABELS)

        # Drop intermediate columns optionally
        # keep columns for audit
        counts = self.df['RETINOPATHY_SEVERITY'].value_counts()
        print("\nSeverity distribution after balanced assignment:")
        for lbl in self.LABELS:
            c = counts.get(lbl, 0)
            print(f"  {lbl:<8}: {c:>5,} patients")

        return self.df['RETINOPATHY_SEVERITY']

    def save(self, output_path=None):
        if output_path is None:
            output_path = self.path.parent / 'Bio_6_f_Retinopathy.csv'
        else:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
        self.df.to_csv(output_path, index=False)
        print(f"\n✓ Saved retinopathy-classified dataset to: {output_path}")
        return str(output_path)

    def summary(self):
        print("\nRetinopathy Summary by Severity:")
        grp = self.df.groupby('RETINOPATHY_SEVERITY')
        for name, g in grp:
            print(f"\n{name}: count={len(g):,}")
            print(f"  Avg HBA1c: {g['HBA1C'].mean():.2f}%")
            print(f"  Avg Duration: {g['DIABETES_DURATION_YEARS'].mean():.2f} yrs")
            print(f"  Avg ACR: {g['ACR'].mean():.2f} mg/g")


def main():
    path = '/Users/nikitha21sree/Biology/Project/Dataset/Bio_3_f_Diabetic.csv'
    clf = RetinopathySeverity(path)
    clf.load()
    clf.compute_composite_score()
    clf.assign_balanced_severity()
    out = clf.save()
    clf.summary()

if __name__ == '__main__':
    main()
