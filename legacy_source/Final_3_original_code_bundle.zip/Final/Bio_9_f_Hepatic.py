#!/usr/bin/env python3
"""Bio_9_f_Hepatic.py

Classify diabetic patients for hepatic (liver) disease severity into four balanced classes
(NONE, MILD, MODERATE, SEVERE) using SR_AST, SR_ALT, SR_BILIRUBIN_TOTAL, SR_ALBUMIN, SR_GLOBULIN.

Score Points: Mild=10, Moderate=20, Severe=30
Produces: Dataset/Bio_f_Hepatic.csv

Multi-disease note:
- Liver dysfunction can be secondary to metabolic syndrome
- AST/ALT may elevate in response to systemic inflammation (shared with cardiovascular/neuropathy)
- Albumin/Globulin reflect liver synthesis (nutritional/systemic health)
"""
import os
import sys
import pandas as pd
import numpy as np
import argparse


INPUT_PATH = os.path.join('Dataset', 'Bio_3_f_Diabetic.csv')
OUTPUT_PATH = os.path.join('Dataset', 'Bio_10_f_Hepatic.csv')


def get_ast_score(ast):
    """AST (Aspartate Aminotransferase) scoring."""
    try:
        ast = float(ast)
    except (ValueError, TypeError):
        return 0
    if ast <= 40:
        return 0  # Normal
    elif ast <= 80:
        return 1  # Mild elevation
    elif ast <= 120:
        return 2  # Moderate
    else:
        return 3  # Severe (>120)


def get_alt_score(alt):
    """ALT (Alanine Aminotransferase) scoring."""
    try:
        alt = float(alt)
    except (ValueError, TypeError):
        return 0
    if alt <= 56:
        return 0  # Normal
    elif alt <= 100:
        return 1  # Mild
    elif alt <= 150:
        return 2  # Moderate
    else:
        return 3  # Severe (>150)


def get_bilirubin_score(bili):
    """Total Bilirubin scoring."""
    try:
        bili = float(bili)
    except (ValueError, TypeError):
        return 0
    if bili <= 1.2:
        return 0  # Normal
    elif bili <= 2.0:
        return 1  # Mild
    elif bili <= 3.0:
        return 2  # Moderate
    else:
        return 3  # Severe (>3.0)


def get_albumin_score(alb):
    """Albumin scoring (lower = worse liver function)."""
    try:
        alb = float(alb)
    except (ValueError, TypeError):
        return 0
    if alb >= 3.5:
        return 0  # Normal
    elif alb >= 2.8:
        return 1  # Mild
    elif alb >= 2.5:
        return 2  # Moderate
    else:
        return 3  # Severe (<2.5)


def get_globulin_score(glob):
    """Globulin scoring (abnormal = high inflammation/dysfunction)."""
    try:
        glob = float(glob)
    except (ValueError, TypeError):
        return 0
    if glob <= 3.5:
        return 0  # Normal
    elif glob <= 4.0:
        return 1  # Mild
    elif glob <= 4.5:
        return 2  # Moderate
    else:
        return 3  # Severe (>4.5)


def compute_hepatic_score(row):
    """Composite hepatic dysfunction score."""
    ast_score = get_ast_score(row.get('SR_AST', 0))
    alt_score = get_alt_score(row.get('SR_ALT', 0))
    bili_score = get_bilirubin_score(row.get('SR_BILIRUBIN_TOTAL', 0))
    alb_score = get_albumin_score(row.get('SR_ALBUMIN', 0))
    glob_score = get_globulin_score(row.get('SR_GLOBULIN', 0))
    
    # Weighted composite
    composite = (ast_score * 0.25 + alt_score * 0.25 + bili_score * 0.20 +
                 alb_score * 0.20 + glob_score * 0.10)
    return composite


from dataset_utils import assign_balanced_severity as _assign

def assign_balanced_severity(df, score_col='HEPATIC_SCORE'):
    label_order = ['NONE', 'SEVERE', 'MILD', 'MODERATE']
    return _assign(df, score_col, label_order)


def main():
    parser = argparse.ArgumentParser(description="Generate hepatic severity labels")
    parser.add_argument('--csv', help='Input diabetic dataset path')
    parser.add_argument('--output', help='Output CSV path')
    parser.add_argument('--merge-mild-moderate', action='store_true',
                        help='Collapse MILD and MODERATE into a single category after assignment')
    args = parser.parse_args()
    
    input_path = args.csv or INPUT_PATH
    output_path = args.output or OUTPUT_PATH

    if not os.path.exists(input_path):
        print(f"Input file not found: {input_path}")
        sys.exit(1)

    print(f"Loading diabetic dataset from: {input_path}")
    df = pd.read_csv(input_path)
    print(f"Loaded: {df.shape[0]} rows × {df.shape[1]} columns\n")

    # Ensure required numeric columns exist and are cleaned
    from dataset_utils import ensure_numeric_cols
    required = ['SR_AST', 'SR_ALT', 'SR_BILIRUBIN_TOTAL', 'SR_ALBUMIN', 'SR_GLOBULIN']
    df = ensure_numeric_cols(df, required, fill_strategy='median', default=0)

    # Compute composite score
    df['HEPATIC_SCORE'] = df.apply(compute_hepatic_score, axis=1)

    print("Computing composite hepatic dysfunction score...")
    print(f"Computed score range: {df['HEPATIC_SCORE'].min():.2f} - {df['HEPATIC_SCORE'].max():.2f}\n")

    # Assign balanced severity
    df['HEPATIC_SEVERITY'] = assign_balanced_severity(df, score_col='HEPATIC_SCORE')
    if args.merge_mild_moderate:
        df['HEPATIC_SEVERITY'] = df['HEPATIC_SEVERITY'].replace(
            {'MILD': 'MILD_MOD', 'MODERATE': 'MILD_MOD'})
        print("Merged MILD/MODERATE into MILD_MOD (overlap removed).", flush=True)

    order = ['NONE', 'SEVERE', 'MILD', 'MODERATE']
    if args.merge_mild_moderate:
        order = ['NONE', 'SEVERE', 'MILD_MOD']
    dist = df['HEPATIC_SEVERITY'].value_counts().reindex(order).fillna(0).astype(int)
    print('Severity distribution after balanced assignment:')
    for lvl in order:
        print(f"  {lvl:<8}: {dist[lvl]:,} patients")

    # Summary stats
    print('\nHepatic Summary by Severity:\n')
    summary_levels = ['SEVERE', 'MODERATE', 'MILD', 'NONE']
    if args.merge_mild_moderate:
        summary_levels = ['SEVERE', 'MILD_MOD', 'NONE']
    for lvl in summary_levels:
        level_data = df[df['HEPATIC_SEVERITY'] == lvl]
        avg_ast = level_data['SR_AST'].mean()
        avg_alt = level_data['SR_ALT'].mean()
        avg_bili = level_data['SR_BILIRUBIN_TOTAL'].mean()
        avg_alb = level_data['SR_ALBUMIN'].mean()
        print(f"{lvl}: count={len(level_data):,}")
        print(f"  Avg AST: {avg_ast:.2f} IU/L")
        print(f"  Avg ALT: {avg_alt:.2f} IU/L")
        print(f"  Avg Bilirubin: {avg_bili:.2f} mg/dL")
        print(f"  Avg Albumin: {avg_alb:.2f} g/dL\n")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    print(f"\n✓ Saved hepatic-classified dataset to: {output_path}")


if __name__ == '__main__':
    main()
