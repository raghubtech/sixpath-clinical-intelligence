"""Utility functions for generating balanced severity datasets across diseases."""
import numpy as np
import pandas as pd


def assign_balanced_severity(df, score_col, label_order):
    """Split dataset into balanced groups according to score column.

    Parameters
    ----------
    df : pandas.DataFrame
        Input dataframe containing score_col.
    score_col : str
        Column name containing numeric scores (higher=worse).
    label_order : list of str
        Labels in descending severity order (first element receives highest scores).

    Returns
    -------
    pandas.Series
        Severity labels assigned to each index of ``df``.
    """
    idx_sorted = df.sort_values(score_col, ascending=False).index.to_numpy()
    groups = np.array_split(idx_sorted, len(label_order))
    severity = pd.Series(index=df.index, dtype=object)
    for grp_idx, indices in enumerate(groups):
        severity.loc[indices] = label_order[grp_idx]
    return severity


def ensure_numeric_cols(df, cols, fill_strategy="median", default=0):
    """Convert given cols to numeric, filling missing values.

    Parameters
    ----------
    df : pandas.DataFrame
    cols : iterable of str
        Column names to process.
    fill_strategy : {"median","zero"}
        How to fill NaNs.
    default : scalar
        Default fill if column absent or entirely NaN.
    """
    for col in cols:
        if col not in df.columns:
            df[col] = default
        df[col] = pd.to_numeric(df[col], errors='coerce')
        if fill_strategy == "median":
            if df[col].notna().any():
                df[col].fillna(df[col].median(), inplace=True)
            else:
                df[col].fillna(default, inplace=True)
        else:
            df[col].fillna(default, inplace=True)
    return df
