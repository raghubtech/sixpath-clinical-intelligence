"""
Diabetes Overall Severity Classification (MILD, MODERATE, SEVERE, CRITICAL)
Multi-organ composite severity classifier incorporating:
  - Glycemic control (FBS, PPBS)
  - Renal function (SR_CREATININE, ACR)
  - Lipid profile (LDL, TGL, TCL_HDL_RATIO)
  - Duration & inflammation (DIABETES_DURATION_YEARS, HS_CRP)
  - Hepatic markers (SR_AST, SR_ALT - secondary morbidity)

This script:
1. Loads the diabetic patients dataset
2. Calculates multi-organ composite severity scores 
3. Assigns severity level to each patient (MILD, MODERATE, SEVERE, CRITICAL)
4. Ensures balanced class distribution (2500 per level from 10k patients)
5. Saves classified dataset with SEVERITY_LEVEL column

Reference Ranges (from Clinical Severity Table):
    MILD        | MODERATE    | SEVERE      | CRITICAL
    FBS: 126-150 | 151-199 | 200-299 | ≥300
    PPBS: 180-225 | 226-299 | 300-399 | ≥400
    HBA1c: 5.7-6.4% | 6.5-7.9% | 8.0-9.9% | ≥10%
    SR_Creatinine: 1.1-1.5 | 1.6-2.0 | 2.1-3.0 | >3.0
    ACR: 30-100 | 101-300 | 301-1000 | >1000
    LDL: 130-159 | 160-189 | 190-219 | ≥220
    TGL: 150-199 | 200-299 | 300-499 | ≥500
    TC:HDL: 4.5-5.0 | 5.1-6.0 | 6.1-7.0 | >7.0
    Duration: 1-5 | 6-15 | 16-25 | >25
    HS_CRP: 1.0-3.0 | 3.1-10 | 11-20 | >20

Score Points (per clinical table): Mild=10, Moderate=20, Severe=35

"""

import pandas as pd
import numpy as np
from pathlib import Path

class DiabetesSeverityClassifier:
    """
    Classify diabetic patients into severity levels based on clinical biomarkers.
    """
    
    # Severity score ranges - directly from clinical table with proper non-overlapping intervals
    # Each tuple is (mild_upper, moderate_upper, severe_upper) exclusive upper bounds
    SEVERITY_RANGES = {
        'FBS': {'MILD': (126, 150), 'MODERATE': (151, 199), 'SEVERE': (200, 299), 'CRITICAL': (300, float('inf'))},
        'PPBS': {'MILD': (180, 225), 'MODERATE': (226, 299), 'SEVERE': (300, 399), 'CRITICAL': (400, float('inf'))},
        'SR_CREATININE': {'MILD': (1.1, 1.5), 'MODERATE': (1.6, 2.0), 'SEVERE': (2.1, 3.0), 'CRITICAL': (3.0, float('inf'))},
        'ACR': {'MILD': (30, 100), 'MODERATE': (101, 300), 'SEVERE': (301, 1000), 'CRITICAL': (1000, float('inf'))},
        'HBA1C': {'MILD': (5.7, 6.4), 'MODERATE': (6.5, 7.9), 'SEVERE': (8.0, 9.9), 'CRITICAL': (10.0, float('inf'))},
        'LDL_DIRECT': {'MILD': (130, 159), 'MODERATE': (160, 189), 'SEVERE': (190, 219), 'CRITICAL': (220, float('inf'))},
        'TGL': {'MILD': (150, 199), 'MODERATE': (200, 299), 'SEVERE': (300, 499), 'CRITICAL': (500, float('inf'))},
        'TCL_HDL_RATIO': {'MILD': (4.5, 5.0), 'MODERATE': (5.1, 6.0), 'SEVERE': (6.1, 7.0), 'CRITICAL': (7.0, float('inf'))},
        'DIABETES_DURATION': {'MILD': (1, 5), 'MODERATE': (6, 15), 'SEVERE': (16, 25), 'CRITICAL': (25, float('inf'))},
        'HS_CRP': {'MILD': (1.0, 3.0), 'MODERATE': (3.1, 10), 'SEVERE': (11, 20), 'CRITICAL': (20, float('inf'))},
    }
    
    # Biomarkers for severity calculation - directly from clinical reference table
    # Glycemic control: FBS, PPBS
    # Renal function: SR_CREATININE, ACR
    # Lipid profile: LDL_DIRECT, TGL, TCL_HDL_RATIO
    # Duration & inflammation: DIABETES_DURATION_YEARS, HS_CRP
    SEVERITY_BIOMARKERS = [
        'BLOOD_SUGAR_F', 'BLOOD_SUGAR_PP',           # Glycemic control
        'SR_CREATININE', 'ACR',                      # Renal function
        'LDL_DIRECT', 'TGL', 'TCL_HDL_RATIO',       # Lipid profile
        'DIABETES_DURATION_YEARS', 'HS_CRP', 'HBA1C'  # Duration & inflammation
    ]
    
    def __init__(self, diabetic_dataset_path):
        """
        Initialize severity classifier with diabetic patients dataset.
        
        Args:
            diabetic_dataset_path (str): Path to diabetic patients CSV
        """
        self.diabetic_dataset_path = diabetic_dataset_path
        self.df = None
        self.severity_scores = None
        
    def load_dataset(self):
        """Load the diabetic patients with type dataset."""
        print(f"Loading diabetic patients dataset from: {self.diabetic_dataset_path}")
        self.df = pd.read_csv(self.diabetic_dataset_path)
        print(f"✓ Dataset loaded successfully")
        print(f"  Shape: {self.df.shape}")
        print(f"  Total Diabetic Patients: {len(self.df):,}")
        return self.df
    
    def _get_biomarker_severity_score(self, value, biomarker):
        """Map biomarker value to severity score (0=MILD, 1=MODERATE, 2=SEVERE, 3=CRITICAL).
        
        Uses the clinical ranges defined in SEVERITY_RANGES, checking intervals in ascending
        order (MILD < MODERATE < SEVERE < CRITICAL) with proper non-overlapping boundaries.
        
        Args:
            value: Biomarker measurement value
            biomarker: Key in SEVERITY_RANGES (e.g. 'FBS', 'ACR', 'HS_CRP')
            
        Returns:
            int: 0 (MILD), 1 (MODERATE), 2 (SEVERE), or 3 (CRITICAL); 1.5 if missing
        """
        if pd.isna(value):
            return 1.5  # Default to moderate if missing
        
        ranges = self.SEVERITY_RANGES.get(biomarker)
        if not ranges:
            return 1.5  # Unknown biomarker defaults to moderate
        
        severity_order = ['MILD', 'MODERATE', 'SEVERE', 'CRITICAL']
        for idx, severity in enumerate(severity_order):
            low, high = ranges[severity]
            if value <= high:  # First match wins
                return idx
        
        return 3  # Fallback to CRITICAL
    
    def calculate_severity_scores(self):
        """
        Calculate composite severity score for each patient.
        Weighted scoring based on key biomarkers.
        
        Returns:
            np.array: Severity scores for all patients
        """
        print("\nCalculating Severity Scores...")
        
        # Biomarker mapping: (data_column_name -> severity_ranges_key)
        # All biomarkers from clinical severity table
        biomarker_mapping = {
            'BLOOD_SUGAR_F': 'FBS',
            'BLOOD_SUGAR_PP': 'PPBS',
            'SR_CREATININE': 'SR_CREATININE',
            'ACR': 'ACR',
            'LDL_DIRECT': 'LDL_DIRECT',
            'TGL': 'TGL',
            'TCL_HDL_RATIO': 'TCL_HDL_RATIO',
            'DIABETES_DURATION_YEARS': 'DIABETES_DURATION',
            'HS_CRP': 'HS_CRP'
        }
        
        # Track which biomarkers are actually available in the data
        available_biomarkers = {k: v for k, v in biomarker_mapping.items() if k in self.df.columns}
        if not available_biomarkers:
            # Fallback if no biomarkers found
            print("Warning: No recognized biomarkers found. Using HS_CRP if available.")
            available_biomarkers = {'HS_CRP': 'HS_CRP'} if 'HS_CRP' in self.df.columns else {}
        
        print(f"  Using {len(available_biomarkers)} biomarkers: {list(available_biomarkers.keys())}")
        
        # Initialize scores array
        n_patients = len(self.df)
        composite_scores = np.zeros(n_patients)
        
        # Calculate severity score for each available biomarker
        for data_col, severity_key in available_biomarkers.items():
            # Get severity for this biomarker
            biomarker_scores = self.df[data_col].apply(
                lambda x: self._get_biomarker_severity_score(x, severity_key)
            )
            # Add to composite (weighted equally)
            composite_scores += biomarker_scores.values
        
        # Normalize to 0-3 scale based on available biomarkers
        n_biomarkers = len(available_biomarkers) if available_biomarkers else 1
        avg_scores = composite_scores / n_biomarkers
        self.severity_scores = avg_scores
        
        print(f"✓ Calculated severity scores for {n_patients:,} patients")
        print(f"  Score range: {avg_scores.min():.2f} - {avg_scores.max():.2f}")
        
        return avg_scores
    
    def assign_severity_levels_balanced(self):
        """
        Assign severity levels with balanced distribution (2000-3000 per level).
        Uses percentile-based approach to ensure balance.
        
        Returns:
            pd.DataFrame: Dataset with added SEVERITY_LEVEL column
        """
        print("\nAssigning Severity Levels with Balanced Distribution...")
        
        # Sort patients by severity score
        severity_indices = np.argsort(self.severity_scores)
        sorted_scores = self.severity_scores[severity_indices]
        
        # Initialize severity level array
        severity_levels = np.empty(len(self.df), dtype=object)
        
        # Divide into 4 groups with target distribution
        n_patients = len(self.df)
        
        # Calculate how many per severity level
        # Target: MILD ~2500, MODERATE ~2500, SEVERE ~2500, CRITICAL ~2500 (total 10000)
        patients_per_level = n_patients // 4
        
        # Assign severity levels based on sorted order
        level_assignments = ['MILD', 'MODERATE', 'SEVERE', 'CRITICAL']
        
        for i, level in enumerate(level_assignments):
            start_idx = i * patients_per_level
            if i == 3:  # Last group gets remaining
                end_idx = n_patients
            else:
                end_idx = (i + 1) * patients_per_level
            
            severity_levels[severity_indices[start_idx:end_idx]] = level
        
        # Add to dataframe
        self.df['SEVERITY_LEVEL'] = severity_levels
        
        # Print distribution
        severity_counts = pd.Series(severity_levels).value_counts()
        print(f"\nSeverity Level Distribution:")
        for level in level_assignments:
            count = severity_counts.get(level, 0)
            pct = (count / n_patients) * 100
            print(f"  {level:<10}: {count:>5,} patients ({pct:>5.2f}%)")
        
        return self.df
    
    def print_severity_statistics(self):
        """Print detailed severity statistics."""
        print("\n" + "="*70)
        print("SEVERITY DISTRIBUTION ANALYSIS")
        print("="*70)
        
        severity_counts = self.df['SEVERITY_LEVEL'].value_counts()
        level_order = ['MILD', 'MODERATE', 'SEVERE', 'CRITICAL']
        
        print(f"\nTotal Diabetic Patients: {len(self.df):,}")
        print("\nSeverity Level Distribution:")
        print("-" * 70)
        
        for level in level_order:
            if level in severity_counts.index:
                count = severity_counts[level]
                percentage = (count / len(self.df)) * 100
                
                # Get characteristics of this level
                level_data = self.df[self.df['SEVERITY_LEVEL'] == level]
                avg_fbs = level_data['BLOOD_SUGAR_F'].mean()
                avg_creatinine = level_data['SR_CREATININE'].mean()
                avg_acr = level_data['ACR'].mean()
                avg_duration = level_data['DIABETES_DURATION_YEARS'].mean() if 'DIABETES_DURATION_YEARS' in level_data.columns else 0
                
                print(f"\n{level.upper()}:")
                print(f"  Count: {count:,} patients ({percentage:.2f}%)")
                print(f"  Avg FBS: {avg_fbs:.1f} mg/dL")
                print(f"  Avg Creatinine: {avg_creatinine:.2f} mg/dL")
                print(f"  Avg ACR: {avg_acr:.1f} mg/g")
                print(f"  Avg Diabetes Duration: {avg_duration:.1f} years")
        
        print("\n" + "="*70)
    
    def save_dataset(self, output_dir=None):
        """
        Save the classified dataset with SEVERITY_LEVEL column.
        
        Args:
            output_dir (str): Directory to save CSV file (default: same as input)
        
        Returns:
            str: Path to the saved dataset
        """
        if output_dir is None:
            output_dir = Path(self.diabetic_dataset_path).parent
        else:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # Save dataset with SEVERITY_LEVEL
        output_path = output_dir / 'Bio_5_f_severity.csv'
        self.df.to_csv(output_path, index=False)
        
        print(f"\n✓ Severity-classified dataset saved:")
        print(f"  Path: {output_path}")
        print(f"  Rows: {len(self.df):,} | Columns: {len(self.df.columns)}")
        
        return str(output_path)
    
    def get_severity_summary(self):
        """Get summary statistics by severity level."""
        summary_stats = {}
        
        for level in ['MILD', 'MODERATE', 'SEVERE', 'CRITICAL']:
            level_data = self.df[self.df['SEVERITY_LEVEL'] == level]
            summary_stats[level] = {
                'count': len(level_data),
                'percentage': (len(level_data) / len(self.df)) * 100,
                'avg_age': level_data['AGE'].mean(),
                'avg_bmi': level_data['BMI'].mean(),
                'avg_fbs': level_data['BLOOD_SUGAR_F'].mean(),
                'avg_ppbs': level_data['BLOOD_SUGAR_PP'].mean()
            }
        
        return summary_stats


def main():
    """Main function to execute diabetes severity classification pipeline."""
    
    # Initialize classifier
    diabetic_dataset_path = '/Users/nikitha21sree/Biology/Project/Dataset/Bio_3_f_Diabetic.csv'
    classifier = DiabetesSeverityClassifier(diabetic_dataset_path)
    
    # Step 1: Load dataset
    classifier.load_dataset()
    
    # Step 2: Calculate severity scores
    classifier.calculate_severity_scores()
    
    # Step 3: Assign severity levels with balanced distribution
    classifier.assign_severity_levels_balanced()
    
    # Step 4: Save classified dataset
    output_path = classifier.save_dataset()
    
    # Step 5: Print statistics
    classifier.print_severity_statistics()
    
    # Sample data preview
    print("\nSample Data Preview:")
    display_cols = ['PATIENT_ID', 'AGE', 'BMI', 'BLOOD_SUGAR_F', 'SR_CREATININE', 
                    'ACR', 'SEVERITY_LEVEL']
    
    for level in ['MILD', 'MODERATE', 'SEVERE', 'CRITICAL']:
        level_data = classifier.df[classifier.df['SEVERITY_LEVEL'] == level]
        if len(level_data) > 0:
            print(f"\n{level} Severity - First 3 rows:")
            print(level_data[display_cols].head(3).to_string())
    
    # Summary statistics
    print("\n\nSummary Statistics by Severity Level:")
    summary = classifier.get_severity_summary()
    
    print("\n" + "-"*70)
    print(f"{'Severity':<12} {'Count':<10} {'%':<8} {'Avg Age':<10} {'Avg BMI':<10}")
    print("-"*70)
    
    for level in ['MILD', 'MODERATE', 'SEVERE', 'CRITICAL']:
        stats = summary[level]
        print(f"{level:<12} {stats['count']:<10,} {stats['percentage']:<8.2f} "
              f"{stats['avg_age']:<10.1f} {stats['avg_bmi']:<10.2f}")
    
    print("\n" + "="*70)
    print(f"Output file: diabetic_patients_with_severity.csv")
    print(f"Total records: {len(classifier.df):,}")
    print(f"Total features: {len(classifier.df.columns)}")
    print("="*70)
    
    return classifier


if __name__ == "__main__":
    classifier = main()
