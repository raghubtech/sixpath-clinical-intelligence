"""
Improved FT-Transformer with various accuracy boosts described by user:
- CLS token
- attention pooling
- feature dropout
- mixup augmentation
- label smoothing
- two-stage classifier

Usage similar to Bio_13_fttransformer.py with extra flags.
"""

import argparse
from pathlib import Path
from matplotlib import cm
import pandas as pd
import numpy as np
import random
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, roc_auc_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import json
import os
import warnings
warnings.filterwarnings('ignore')

# Set random seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
DEVICE = torch.device('cuda' if torch.cuda.is_available() else ('mps' if getattr(torch,'has_mps',False) else 'cpu'))


class TabularDataset(Dataset):
    def __init__(self, X_cont, X_cat, y):
        self.X_cont = X_cont.astype(np.float32)
        self.X_cat = X_cat.astype(np.int64) if X_cat is not None else None
        self.y = y.astype(np.int64)
    def __len__(self):
        return len(self.y)
    def __getitem__(self, idx):
        cont = torch.from_numpy(self.X_cont[idx])
        cat = torch.from_numpy(self.X_cat[idx]) if self.X_cat is not None else None
        return cont, cat, int(self.y[idx])


class FTLikeTransformer(nn.Module):
    def __init__(self, n_cont, cat_cardinals, embed_dim=64, n_heads=4, n_layers=4,
                 dropout=0.1, feat_dropout=0.1, use_cls=True, use_attn_pool=True,
                 n_classes=4):
        super().__init__()
        self.n_cont = n_cont
        self.cat_cardinals = cat_cardinals or []
        self.embed_dim = embed_dim
        self.use_cls = use_cls
        self.use_attn_pool = use_attn_pool
        # per-feature projections
        self.cont_projs = nn.ModuleList([nn.Linear(1, embed_dim) for _ in range(n_cont)])
        self.cat_embeds = nn.ModuleList([nn.Embedding(card, embed_dim) for card in self.cat_cardinals])
        n_tokens = n_cont + len(self.cat_cardinals) + (1 if use_cls else 0)
        self.feat_pos = nn.Parameter(torch.randn(n_tokens, embed_dim))
        self.feature_dropout = nn.Dropout(feat_dropout)
        # CLS token
        if use_cls:
            self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim))
        # transformer
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=n_heads,
                                                   dim_feedforward=embed_dim*2,
                                                   dropout=dropout, activation='gelu')
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.norm = nn.LayerNorm(embed_dim)
        # two-stage classifier: first project to embed and then to classes
        self.stage1 = nn.Sequential(nn.Linear(embed_dim, embed_dim), nn.GELU(), nn.Dropout(dropout))
        self.stage2 = nn.Linear(embed_dim, n_classes)
        # attention pooling parameters if used
        if use_attn_pool:
            self.pool_query = nn.Parameter(torch.randn(embed_dim))
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            if isinstance(m, nn.Embedding):
                nn.init.normal_(m.weight, std=0.01)

    def forward(self, x_cont, x_cat=None):
        B = x_cont.size(0)
        cont_tokens = []
        for i, proj in enumerate(self.cont_projs):
            v = x_cont[:, i].unsqueeze(1)
            cont_tokens.append(proj(v))
        cont_stack = torch.stack(cont_tokens, dim=1) if cont_tokens else torch.zeros(B,0,self.embed_dim,device=x_cont.device)
        if self.cat_embeds and x_cat is not None:
            cat_stack = torch.stack([emb(x_cat[:, i]) for i, emb in enumerate(self.cat_embeds)], dim=1)
        else:
            cat_stack = torch.zeros(B,0,self.embed_dim,device=x_cont.device)
        tokens = torch.cat([cont_stack, cat_stack], dim=1)
        if self.use_cls:
            cls = self.cls_token.expand(B, -1, -1)
            tokens = torch.cat([cls, tokens], dim=1)
        tokens = tokens + self.feat_pos.unsqueeze(0)
        tokens = self.feature_dropout(tokens)
        tokens = tokens.transpose(0,1)
        out = self.transformer(tokens)
        out = out.transpose(0,1)  # (B,S,E)
        if self.use_attn_pool:
            # compute attention weights over sequence
            # pool_query: (E,)
            q = self.pool_query.unsqueeze(0).unsqueeze(0)  # (1,1,E)
            # compute dot with each token
            weights = torch.matmul(out, q.transpose(-1,-2)).squeeze(-1)  # (B,S)
            weights = torch.softmax(weights, dim=1).unsqueeze(-1)  # (B,S,1)
            pooled = (out * weights).sum(dim=1)
        else:
            pooled = out.mean(dim=1)
        pooled = self.norm(pooled)
        h = self.stage1(pooled)
        logits = self.stage2(h)
        return logits


class LabelSmoothingLoss(nn.Module):
    def __init__(self, smoothing=0.0):
        super().__init__()
        self.smoothing = smoothing
        self.confidence = 1.0 - smoothing
        self.log_softmax = nn.LogSoftmax(dim=-1)
    def forward(self, x, target):
        logprobs = self.log_softmax(x)
        nll_loss = -logprobs.gather(dim=-1, index=target.unsqueeze(1)).squeeze(1)
        smooth_loss = -logprobs.mean(dim=-1)
        return self.confidence * nll_loss + self.smoothing * smooth_loss


class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0):
        super().__init__()
        self.gamma = gamma
        self.ce = nn.CrossEntropyLoss()
    def forward(self, logits, targets):
        logpt = -self.ce(logits, targets)
        pt = logpt.exp()
        loss = -((1-pt)**self.gamma) * logpt
        return loss.mean()


def load_and_preprocess(path):
    df = pd.read_csv(path)
    target = 'SEVERITY_LEVEL'
    assert target in df.columns
    y = df[target].copy()
    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    exclude = {'PATIENT_ID', target}
    numeric_cols = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]
    cat_cols = [c for c in ['BLOOD_GROUP','RH_TYPING'] if c in df.columns]
    cont_cols = [c for c in numeric_cols if c not in cat_cols]
    X_cont = df[cont_cols].fillna(df[cont_cols].median()).values
    scaler = StandardScaler()
    X_cont = scaler.fit_transform(X_cont)
    if cat_cols:
        X_cat = df[cat_cols].fillna('NA')
        X_cat_enc = np.stack([LabelEncoder().fit_transform(X_cat[c].astype(str)) for c in cat_cols], axis=1)
        cat_cardinals = [int(X_cat[c].nunique()) for c in cat_cols]
    else:
        X_cat_enc = None
        cat_cardinals = []
    return X_cont, X_cat_enc, y_enc, cont_cols, cat_cols, cat_cardinals


def mixup_data(x1, x2, y, alpha=1.0):
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1
    batch_size = x1.size(0)
    index = torch.randperm(batch_size).to(x1.device)
    mixed1 = lam * x1 + (1 - lam) * x1[index, :]
    mixed2 = lam * x2 + (1 - lam) * x2[index, :] if x2 is not None else None
    y_a, y_b = y, y[index]
    return mixed1, mixed2, y_a, y_b, lam


def train_one_epoch(model, loader, opt, loss_fn, mixup_alpha=0.0):
    model.train()
    losses = []
    for cont, cat, y in loader:
        cont = cont.to(DEVICE)
        cat = cat.to(DEVICE) if cat is not None else None
        y = y.to(DEVICE)
        if mixup_alpha > 0:
            cont, cat, y_a, y_b, lam = mixup_data(cont, cat, y, mixup_alpha)
            logits = model(cont, cat)
            loss = lam * loss_fn(logits, y_a) + (1 - lam) * loss_fn(logits, y_b)
        else:
            logits = model(cont, cat)
            loss = loss_fn(logits, y)
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
        opt.step()
        losses.append(loss.item())
    return float(np.mean(losses))


def eval_model(model, loader):
    model.eval()
    ys = []
    preds = []
    with torch.no_grad():
        for cont, cat, y in loader:
            cont = cont.to(DEVICE)
            cat = cat.to(DEVICE) if cat is not None else None
            logits = model(cont, cat)
            p = logits.argmax(dim=1).cpu().numpy()
            preds.append(p)
            ys.append(y.numpy())
    y_true = np.concatenate(ys)
    y_pred = np.concatenate(preds)
    acc = accuracy_score(y_true, y_pred)
    return acc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv', default='/Users/nikitha21sree/Biology/Project/Dataset/Bio_5_f_severity.csv')
    parser.add_argument('--epochs', type=int, default=400)
    parser.add_argument('--batch', type=int, default=256)
    parser.add_argument('--embed_dim', type=int, default=32)
    parser.add_argument('--n_heads', type=int, default=2)
    parser.add_argument('--n_layers', type=int, default=2)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--weight_decay', type=float, default=1e-5)
    parser.add_argument('--optuna', action='store_true')
    parser.add_argument('--out', default='/Users/nikitha21sree/Biology/Project/Outputs/bio13_f', help='output directory for metrics and plots')
    # new enhancements
    parser.add_argument('--feat_dropout', type=float, default=0.2)
    parser.add_argument('--mixup', type=float, default=0.0, help='mixup alpha')
    parser.add_argument('--label_smoothing', type=float, default=0.0)
    parser.add_argument('--use_cls', action='store_true')
    parser.add_argument('--use_attn_pool', action='store_true')
    args = parser.parse_args()

    data_path = Path(args.csv)
    if not data_path.exists():
        print('CSV not found at', data_path)
        return
    X_cont, X_cat, y, cont_cols, cat_cols, cat_cardinals = load_and_preprocess(str(data_path))
    X_train, X_temp, y_train, y_temp = train_test_split(X_cont, y, stratify=y, test_size=0.3, random_state=42)
    if X_cat is not None:
        Xc_train, Xc_temp = train_test_split(X_cat, stratify=y, test_size=0.3, random_state=42)
    else:
        Xc_train = Xc_temp = None
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, stratify=y_temp, test_size=0.5, random_state=42)
    if X_cat is not None:
        Xc_val, Xc_test = train_test_split(Xc_temp, stratify=y_temp, test_size=0.5, random_state=42)
    else:
        Xc_val = Xc_test = None
    X_test_cont = X_test.copy()

    train_ds = TabularDataset(X_train, Xc_train if Xc_train is not None else None, y_train)
    val_ds = TabularDataset(X_val, Xc_val if Xc_val is not None else None, y_val)
    test_ds = TabularDataset(X_test, Xc_test if Xc_test is not None else None, y_test)

    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=args.batch, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=args.batch, shuffle=False, num_workers=0)

    model = FTLikeTransformer(n_cont=len(cont_cols), cat_cardinals=cat_cardinals,
                              embed_dim=args.embed_dim, n_heads=args.n_heads,
                              n_layers=args.n_layers, dropout=0.1,
                              feat_dropout=args.feat_dropout,
                              use_cls=args.use_cls, use_attn_pool=args.use_attn_pool).to(DEVICE)
    if args.label_smoothing>0:
        loss_fn = LabelSmoothingLoss(smoothing=args.label_smoothing)
    else:
        loss_fn = FocalLoss(gamma=2.0)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    print('Device:', DEVICE)
    print('Train size:', len(train_ds), 'Val size:', len(val_ds), 'Test size:', len(test_ds))
    print(f"Enhancements: cls={args.use_cls} attnpool={args.use_attn_pool} featdrop={args.feat_dropout} mixup={args.mixup} smooth={args.label_smoothing}")

    history = {'train_loss': [], 'val_loss': [], 'val_acc': []}
    for epoch in range(1, args.epochs+1):
        tr_loss = train_one_epoch(model, train_loader, opt, loss_fn, args.mixup)
        val_acc = eval_model(model, val_loader)
        history['train_loss'].append(tr_loss)
        history['val_acc'].append(val_acc)
        print(f'Epoch {epoch}/{args.epochs}  train_loss={tr_loss:.4f}  val_acc={val_acc:.4f}')

    # evaluation identical to previous script
    model.eval()
    y_true, y_pred, y_prob = [], [], []
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    with torch.no_grad():
        for cont, cat, yb in test_loader:
            cont = cont.to(DEVICE)
            cat = cat.to(DEVICE) if cat is not None else None
            logits = model(cont, cat)
            probs = torch.softmax(logits, dim=1).cpu().numpy()
            preds = probs.argmax(axis=1)
            y_true.extend(yb.numpy().tolist())
            y_pred.extend(preds.tolist())
            y_prob.extend(probs.tolist())
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    y_prob = np.array(y_prob)
    metrics = {}
    metrics['accuracy'] = float(accuracy_score(y_true, y_pred))
    metrics['precision_macro'] = float(precision_score(y_true, y_pred, average='macro', zero_division=0))
    metrics['recall_macro'] = float(recall_score(y_true, y_pred, average='macro', zero_division=0))
    metrics['f1_macro'] = float(f1_score(y_true, y_pred, average='macro', zero_division=0))
    auc = roc_auc_score(pd.get_dummies(y_true), y_prob, average='macro', multi_class='ovr')
    metrics['roc_auc_macro'] = float(auc) if auc is not None else None
    cm = confusion_matrix(y_true, y_pred).tolist()
    metrics['confusion_matrix'] = cm
    with open(out_dir / 'metrics.json', 'w') as f:
        json.dump(metrics, f, indent=2)
    print(f"\nTest ROC AUC (macro): {metrics['roc_auc_macro']}")
    print("Confusion matrix:\n", np.array(metrics['confusion_matrix']))
    print(f"Accuracy: {metrics['accuracy']:.4f}  Precision: {metrics['precision_macro']:.4f}  Recall: {metrics['recall_macro']:.4f}  F1: {metrics['f1_macro']:.4f}")
    print("Classification report:\n", classification_report(y_true, y_pred))
    # plots as before
    from sklearn.metrics import roc_curve
    plt.figure(figsize=(8,6))
    y_true_bin = pd.get_dummies(y_true).values
    for i in range(y_prob.shape[1]):
        fpr, tpr, _ = roc_curve(y_true_bin[:, i], y_prob[:, i])
        plt.plot(fpr, tpr, label=f"cls{i}")
    plt.plot([0,1],[0,1],'--',color='gray')
    plt.xlabel('FPR'); plt.ylabel('TPR'); plt.title('ROC curves'); plt.legend(); plt.tight_layout()
    plt.savefig(out_dir / 'roc.png', dpi=200); plt.close()
    cm_arr = np.array(cm)
    plt.figure(figsize=(6,6))
    plt.imshow(cm_arr, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion matrix'); plt.colorbar()
    ticks = np.arange(cm_arr.shape[0])
    plt.xticks(ticks, ticks, rotation=45, ha='right'); plt.yticks(ticks, ticks)
    thresh = cm_arr.max()/2.0
    for i in range(cm_arr.shape[0]):
        for j in range(cm_arr.shape[1]):
            plt.text(j,i,format(cm_arr[i,j],'d'),ha='center',va='center',color='white' if cm_arr[i,j]>thresh else 'black')
    plt.ylabel('True'); plt.xlabel('Predicted'); plt.tight_layout(); plt.savefig(out_dir / 'confusion.png', dpi=200); plt.close()
    plt.figure(figsize=(6,4))
    plt.plot(history['train_loss'], label='train'); plt.plot(history['val_acc'], label='val_acc')
    plt.xlabel('Epoch'); plt.ylabel('Loss/Acc'); plt.legend(); plt.tight_layout();
    plt.savefig(out_dir / 'loss.png', dpi=200); plt.close()
    torch.save(model.state_dict(), out_dir / 'model.pt')
    print('Metrics saved to', out_dir / 'metrics.json')


if __name__ == '__main__':
    main()
